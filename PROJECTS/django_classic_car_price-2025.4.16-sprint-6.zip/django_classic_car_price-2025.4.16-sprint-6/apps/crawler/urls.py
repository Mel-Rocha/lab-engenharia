from django.urls import path

from apps.crawler.views import StartProcessFromCrawlerAPIView, CheckStatusCrawler, RecordsList, RecordsDuplicate, \
    RecordsDeactivate, RecordsUpdate, DownloadExcel, BrandModelList, MonthlyAveragePrice, DownloadFinalReport, \
    DashboardGeneralKPI, DashboardGeographicPricingAnalysis, DashboardBrandModelAnalysis, AuxFinalReportReferenceDates, \
    Insights

urlpatterns = [
    path(
        'process/all/<str:machine>/<str:site>/',
        StartProcessFromCrawlerAPIView.as_view(),
        name='run_all_process_crawler_api'),
    path(
        'tasks/status/<str:task_id>/',
        CheckStatusCrawler.as_view(),
        name='check_status_crawler'),
    path(
        'records/list/<str:machine>/',
        RecordsList.as_view(),
        name='records-list'),
    path(
        'records/duplicate/<str:machine>/',
        RecordsDuplicate.as_view(),
        name='records-duplicate'),
    path(
        'records/deactivate/<str:machine>/',
        RecordsDeactivate.as_view(),
        name='records-deactivate'),
    path(
        'records/update/<str:machine>/',
        RecordsUpdate.as_view(
            {
                'put': 'update'}),
        name='records-update'),
    path(
        'download/excel/<str:task_id>/<str:machine>',
        DownloadExcel.as_view(),
        name='download-excel'),
    path(
        'calcs/insights/<str:machine>/<int:year_reference>/<int:month_reference>/',
        Insights.as_view(),
        name='insights'),
    path(
        'brand/model/list/<str:machine>/',
        BrandModelList.as_view(),
        name='brand-model-list'),
    path(
        'average_prices/<str:machine>/<str:code_model>/',
        MonthlyAveragePrice.as_view(),
        name='monthly-average-price'),
    path(
        'download/final_report/<int:year_reference>/<int:month_reference>/',
        DownloadFinalReport.as_view(),
        name='download_final_report'),
    path('aux/final_report/reference_dates/', AuxFinalReportReferenceDates.as_view(), name='final_report_reference_dates'),

    path(
        'dashboard/general_kpi/<str:machine>/<int:year_reference>/<int:month_reference>/',
        DashboardGeneralKPI.as_view(),
        name='dashboard_general_kpi'),
    path(
        'dashboard/geographic_pricing_analysis/<str:machine>/<int:year_reference>/<int:month_reference>/',
        DashboardGeographicPricingAnalysis.as_view(),
        name='dashboard_geographic_pricing_analysis'),
    path(
        'dashboard/brand_model_analysis/<str:machine>/<int:year_reference>/<int:month_reference>/',
        DashboardBrandModelAnalysis.as_view(),
        name='dashboard_brand_model_analysis'),
]
