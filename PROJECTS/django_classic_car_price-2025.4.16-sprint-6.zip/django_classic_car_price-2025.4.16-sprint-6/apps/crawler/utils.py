import time
import base64
import logging

import requests

from config.settings import ENDPOINT_CRAWLER, TOKEN_CRAWLER


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def monitor_task_status(task_id, final_status="SUCCESS", interval=30):
    """
    Objetivo:
    Monitora o status de uma tarefa até atingir o status final especificado.

    Args:
        task_id (str): O ID da tarefa a ser monitorada.
        final_status (str): O status final desejado a ser aguardado (o padrão é "SUCCESS").
        interval (int): O intervalo em segundos entre as verificações de status (o padrão é 30 segundos).

    Returns:
        dict: Um dicionário contendo o status final e o resultado. Se a tarefa retornar um PDF, o resultado
              incluirá o conteúdo do PDF codificado em base64.

    Raises:
        ValueError: Se a resposta da verificação de status for inválida.
    """
    url = f"{ENDPOINT_CRAWLER}/core/tasks/status/{task_id}"
    headers = {"Authorization": f"Bearer {TOKEN_CRAWLER}"}

    while True:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            logger.error(
                f"Erro ao verificar status da tarefa {task_id}. Status code: {response.status_code}")
            time.sleep(interval)
            continue

        try:
            # Verifica se a resposta é um PDF
            if response.headers.get('Content-Type') == 'application/pdf':
                logger.info(f"Tarefa {task_id} retornou um PDF.")
                return {
                    "status": final_status, "result": {
                        "pdf_base64": base64.b64encode(
                            response.content).decode('utf-8')}}

            api_response = response.json()
            logger.info(f"Resposta da API: {api_response}")
            status = api_response.get("status")

            # Quando o status final for atingido, retornar imediatamente ao
            # chamador
            if status == final_status:
                logger.info(
                    f"Tarefa {task_id} atingiu o status {final_status}.")
                return {"status": status, "result": api_response.get("result")}

            # Caso o status indique falha ou revogação, retornar imediatamente
            elif status in ["FAILURE", "REVOKED"]:
                logger.error(
                    f"Tarefa {task_id} falhou ou foi revogada. Status: {status}")
                return {"status": status}

            # Se o status for pendente ou outro, continuar aguardando
            elif status in ["PENDING", "STARTED"]:
                logger.info(
                    f"Tarefa {task_id} ainda não finalizada. Status atual: {status}.")
                time.sleep(interval)

        except ValueError:
            logger.error(
                f"Resposta inválida ao verificar status de {task_id}. Resposta: {response.text}")
            time.sleep(interval)
