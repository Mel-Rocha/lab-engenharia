from io import BytesIO

import requests
from drf_yasg import openapi
from rest_framework.views import APIView
from drf_yasg.utils import swagger_auto_schema
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse, StreamingHttpResponse

from apps.core import gateway
from apps.crawler.models import ManageCrawler
from apps.core.gateway import response_log_user
from config.settings import TOKEN_CRAWLER, ENDPOINT_CRAWLER
from apps.crawler.tasks import run_all_process_from_crawler_api
from apps.core.permissions import IsAdminUser, CanInsights, CanDataVisualization, CanFinalReport


class StartProcessFromCrawlerAPIView(APIView):
    """
    Objetivo: Roda o processo completo por parte da api do crawler

    Parâmetros:
    obrigatórios:
    - machine: str
    - site: str

    Retorno:
    - task_id: str
    """
    permission_classes = (IsAuthenticated, IsAdminUser)

    def post(self, request, machine, site, *args, **kwargs):
        result = run_all_process_from_crawler_api.delay(machine, site)
        task_id = result.id

        return JsonResponse({"task_id": task_id}, status=202)


class CheckStatusCrawler(APIView):
    """
    Objetivo: Verificar o status das tasks do crawler.

    Parâmetros:
    obrigatórios:
    - task_id: uuid

    Retorno: JSON com o status da task, resultado da tarefa.
    """

    def get(self, request, task_id, *args, **kwargs):
        url = f"{ENDPOINT_CRAWLER}/core/tasks/status/{task_id}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            try:
                response_data = response.json()
                return JsonResponse(response_data, status=200)
            except ValueError:
                return JsonResponse(
                    {"error": "Erro ao processar a resposta da API externa."}, status=500)
        else:
            try:
                response_data = response.json()
                message = response_data.get(
                    'detail', 'Erro ao obter o status da task.')
            except ValueError:
                message = 'Erro inesperado ao processar a resposta da API externa.'
            return JsonResponse({"error": message},
                                status=response.status_code)


class RecordsList(APIView):
    """
    Objetivo: Listagem de anúncios.

    access_token: string (Bearer Token)

    Parâmetros obrigatórios de URL:
    - product: int

    Query Parameters (opcionais):
    - page: int (página atual)
    - page_size: int (tamanho da página)
    - code_model: string

    Body:
    - reference_dates: list (lista de dicionários com 'reference_year' e 'reference_month')

    Retorno:
    - JSON contendo o task_id. Caso seja bem sucedido o resultado da tarefa será
    a listagem dos anúncios.
    """

    permission_classes = (IsAuthenticated, IsAdminUser)

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'page',
                openapi.IN_QUERY,
                description="Page number",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'page_size',
                openapi.IN_QUERY,
                description="Number of items per page",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'code_model',
                openapi.IN_QUERY,
                description="Code model",
                type=openapi.TYPE_STRING)],
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'reference_dates': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'reference_year': openapi.Schema(
                                type=openapi.TYPE_INTEGER,
                                description='Reference year'),
                            'reference_month': openapi.Schema(
                                type=openapi.TYPE_INTEGER,
                                description='Reference month')},
                        required=[
                            'reference_year',
                            'reference_month']))},
            required=['reference_dates']))
    def post(self, request, machine, *args, **kwargs):
        if not machine:
            return response_log_user(
                request,
                {"message": "O parâmetro 'machine' é obrigatório."},
                400
            )

        base_url = f"{ENDPOINT_CRAWLER}/records/list/task/{machine}"

        params = {
            "page": request.GET.get("page", 1),
            "page_size": request.GET.get("page_size", 10),
            "code_model": request.GET.get("code_model"),
        }
        params = {k: v for k, v in params.items() if v is not None}

        reference_dates = request.data.get("reference_dates", [])

        if not reference_dates:
            response_data = {
                "detail": "O corpo da requisição deve conter 'reference_dates'."}
            return response_log_user(request, response_data, 400)

        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1",
        }

        body = {
            "reference_dates": reference_dates
        }

        try:
            response = requests.post(
                base_url, headers=headers, json=body, params=params)
        except requests.RequestException as e:
            response_data = {
                "detail": f"Erro ao conectar com o servidor externo: {str(e)}"}
            return response_log_user(request, response_data, 500)

        if response.status_code == 200:
            try:
                response_data = response.json()
                return response_log_user(request, response_data, 200)
            except ValueError:
                response_data = {
                    "detail": "Erro ao processar a resposta da API externa."}
                return response_log_user(request, response_data, 500)
        else:
            try:
                response_data = response.json()
            except ValueError:
                response_data = {
                    "detail": "Erro inesperado ao processar a resposta da API externa."}
            return response_log_user(
                request, response_data, response.status_code)


class RecordsDuplicate(APIView):
    """
    Objetivo: Criar novos anúncios a partir de anúncios já existentes.

    @access_token: string (Bearer Token) fornecer em header

    Parâmetros obrigatórios de URL:
    - machine: str (identificador da máquina/processo)

    Body esperado:
    {
      "records": [
        {
          "record_id": string,
          "data": {
            "year_model": int,
            "price": str,
            "month_reference": int,
            "year_reference": int,
            "description": string
          }
        }
      ]
    }

    Retorno: JSON contendo a resposta da API externa. Em caso de sucesso,
    apresentará o task_id do processo de duplicação e o task_id do processo de cálculo,
    junto com uma mensagem informando que o processamento foi iniciado.
    """

    permission_classes = (IsAuthenticated, IsAdminUser)

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'records': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'record_id': openapi.Schema(type=openapi.TYPE_STRING, format='uuid',
                                                        description='Record ID'),
                            'data': openapi.Schema(
                                type=openapi.TYPE_OBJECT,
                                properties={
                                    'price': openapi.Schema(type=openapi.TYPE_STRING, description='Price'),
                                    'description': openapi.Schema(type=openapi.TYPE_STRING, description='Description'),
                                    'mileage': openapi.Schema(type=openapi.TYPE_INTEGER, description='Mileage'),
                                    'title': openapi.Schema(type=openapi.TYPE_STRING, description='Title')
                                },
                                required=['price', 'description', 'mileage', 'title']
                            )
                        },
                        required=['record_id', 'data']
                    )
                )
            },
            required=['records']
        )
    )
    def post(self, request, machine, *args, **kwargs):
        if not machine:
            return response_log_user(
                request,
                {"message": "O parâmetro 'machine' é obrigatório."},
                400
            )

        url = f"{ENDPOINT_CRAWLER}/records/duplicate/task/{machine}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        response = requests.post(url, headers=headers, json=request.data)

        try:
            api_response = response.json()
        except ValueError:
            # Se não for JSON válido
            api_response = {"message": "Invalid response from server"}

        # Retorna exatamente a resposta e o código da API externa
        return response_log_user(request, api_response, response.status_code)


class RecordsDeactivate(APIView):
    """
    Objetivo: Desativar anúncios.

    @access_token: string (Bearer Token) fornecer em header

    Parâmetros obrigatórios de URL:
    - machine: str (identificador da máquina/processo)

    Body esperado:
    - Lista de IDs dos registros a serem desativados.

    Retorno: JSON contendo a mesma resposta da API externa ou status 204.
    """

    permission_classes = (IsAuthenticated, IsAdminUser)

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(
                type=openapi.TYPE_STRING,
                format='uuid',
                description='Record ID')))
    def delete(self, request, machine, *args, **kwargs):
        if not machine:
            return response_log_user(
                request,
                {"message": "O parâmetro 'machine' é obrigatório."},
                400
            )

        request_data = request.data  # ✅ Correção: Usa DRF para obter JSON corretamente

        if not isinstance(
                request_data,
                list) or not all(
                isinstance(
                item,
                str) for item in request_data):
            return response_log_user(
                request,
                {"detail": "O corpo da requisição deve conter uma lista de IDs (strings)."},
                400
            )

        url = f"{ENDPOINT_CRAWLER}/records/deactivate/task/{machine}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1",
            "Content-Type": "application/json"
        }

        try:
            response = requests.delete(url, headers=headers, json=request_data)
        except requests.RequestException as e:
            return response_log_user(
                request,
                {"detail": f"Erro de conexão: {str(e)}"},
                500
            )

        if response.status_code == 204:
            return response_log_user(
                request,
                {"message": "Os registros foram desativados com sucesso."},
                204
            )
        else:
            try:
                response_data = response.json()
            except ValueError:
                response_data = {
                    "detail": "Erro inesperado ao processar a resposta."}
            return response_log_user(
                request, response_data, response.status_code)


class RecordsUpdate(gateway.Update):
    """
    Objetivo: Atualizar registros de um machine específico.

    access_token: string (Bearer Token)

    Parâmetros obrigatórios de URL:
    product: int

    Body:
    {
      "records": [
        {
          "record_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          "data": {
            "year_model": 0,
            "price": "string",
            "month_reference": 0,
            "year_reference": 0,
            "description": "string",
            "axis": 0,
            "size": 0,
            "unit": "string"
          }
        }
      ]
    }

    Retorno: JSON contendo a resposta da API externa.
    """
    permission_classes = (IsAuthenticated, IsAdminUser)

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'records': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'record_id': openapi.Schema(type=openapi.TYPE_STRING, format='uuid',
                                                        description='Record ID'),
                            'data': openapi.Schema(
                                type=openapi.TYPE_OBJECT,
                                properties={
                                    'price': openapi.Schema(type=openapi.TYPE_STRING, description='Price'),
                                    'description': openapi.Schema(type=openapi.TYPE_STRING, description='Description'),
                                    'mileage': openapi.Schema(type=openapi.TYPE_INTEGER, description='Mileage'),
                                    'title': openapi.Schema(type=openapi.TYPE_STRING, description='Title')
                                },
                                required=['price', 'description', 'mileage', 'title']
                            )
                        },
                        required=['record_id', 'data']
                    )
                )
            },
            required=['records']
        )
    )
    def update(self, request, *args, **kwargs):
        machine = kwargs.get("machine")
        if not machine:
            return response_log_user(
                request,
                {"message": "O parâmetro 'machine' é obrigatório."},
                400
            )

        url = f"{ENDPOINT_CRAWLER}/records/update/{machine}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1",
            "Content-Type": "application/json"
        }

        body = request.data

        response = requests.put(url, headers=headers, json=body)

        try:
            api_response = response.json()
        except ValueError:
            # Se não for JSON válido
            api_response = {"message": "Invalid response from server"}

        # Retorna exatamente a resposta e o código da API externa
        return response_log_user(request, api_response, response.status_code)


class DownloadExcel(APIView):
    """
    Objetivo: Baixar o arquivo Excel gerado pela automação do buscador.

    @access_token: string (Bearer Token) (fornecer em header)

    Parâmetros Obrigatórios:
    - task_id: string (task_id) (fornecer em url)
    - machine: string (Tipo da máquina) (fornecer em url)

    Retorno:
    xlsx.
    """
    permission_classes = (IsAuthenticated, IsAdminUser)

    @swagger_auto_schema(
        responses={
            200: openapi.Response(
                description="Arquivo Excel",
                schema=openapi.Schema(
                    type=openapi.TYPE_FILE,
                    format='binary'
                )
            ),
            400: "Bad Request",
            404: "Not Found"
        }
    )
    def get(self, request, task_id, machine):
        url = f"{ENDPOINT_CRAWLER}/core/download/excel/{task_id}/{machine}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            response_stream = StreamingHttpResponse(
                response.iter_content(chunk_size=8192),
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            response_stream["Content-Disposition"] = "attachment; filename=generated_file.xlsx"
            response_stream["Access-Control-Expose-Headers"] = "Content-Disposition"

            return response_stream
        else:
            return JsonResponse(
                {"error": "Falha ao baixar o arquivo Excel."},
                status=response.status_code
            )

class Insights(APIView):
    """
    Objetivo: Analisar os code_models de um determinado mês e ano de referência.

    @access_token: string (Bearer Token) fornecer em header

    Parâmetros obrigatórios de URL:
    - machine: str (Tipo da máquina)
    - year_reference: int (Ano de referência do anúncio)
    - month_reference: int (Mês de referência do anúncio)

    Retorno:
    - JSON contendo:
      - O code_model com maior valorização de preço.
      - O code_model com maior depreciação de preço.
      - O code_model com preço mais consistente.
      - O code_model com preços mais variados.
    """

    permission_classes = (IsAuthenticated, CanInsights)

    def get(
            self,
            request,
            machine,
            year_reference,
            month_reference,
            *args,
            **kwargs):
        url = f"{ENDPOINT_CRAWLER}/calcs/analyze/insights/market/{machine}/{year_reference}/{month_reference}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        response = requests.get(url, headers=headers)

        try:
            response_data = response.json()
        except ValueError:
            response_data = {
                "detail": "Erro ao processar a resposta da API externa."}

        return response_log_user(
            request,
            response_data,
            response.status_code
        )


class BrandModelList(APIView):
    """
    Objetivo: Listar marcas e modelos de um determinado tipo de máquina.

    Parâmetros obrigatórios de URL:
    - machine: str (Tipo da máquina)

    Parâmetros opcionais de URL:
    - page: int (Número da página)
    - page_size: int (Tamanho da página)
    - brand: str (Marca)
    - model: str (Modelo)

    Retorno:
    - JSON contendo a lista de marcas e modelos.
    """

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'machine',
                openapi.IN_PATH,
                description="Tipo da máquina",
                type=openapi.TYPE_STRING,
                required=True),
            openapi.Parameter(
                'brand',
                openapi.IN_QUERY,
                description="Marca",
                type=openapi.TYPE_STRING),
            openapi.Parameter(
                'model',
                openapi.IN_QUERY,
                description="Modelo",
                type=openapi.TYPE_STRING),
            openapi.Parameter(
                'page',
                openapi.IN_QUERY,
                description="Número da página",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'page_size',
                openapi.IN_QUERY,
                description="Tamanho da página",
                type=openapi.TYPE_INTEGER)])
    def get(self, request, machine, *args, **kwargs):
        url = f"{ENDPOINT_CRAWLER}/core/brand/model/list/{machine}"
        params = {
            "page": request.GET.get("page", 1),
            "page_size": request.GET.get("page_size", 10),
            "brand": request.GET.get("brand"),
            "model": request.GET.get("model"),
        }
        params = {k: v for k, v in params.items() if v is not None}

        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        response = requests.get(url, headers=headers, params=params)

        try:
            response_data = response.json()
        except ValueError:
            response_data = {
                "detail": "Erro ao processar a resposta da API externa."}

        return response_log_user(request, response_data, response.status_code)


class MonthlyAveragePrice(APIView):
    """
    Objetivo: Obter médias mensais de preços de máquinas filtradas por código do modelo, ano/mês de referência e status de atividade.

    Parâmetros obrigatórios de URL:
    - machine: str (Tipo da máquina)
    - code_model: str (Código do modelo da máquina)

    Parâmetros opcionais de URL:
    - year_model: int (Ano do modelo)
    - year_reference: int (Ano de referência do anúncio)
    - month_reference: int (Mês de referência do anúncio)
    - is_active: bool (Status ativo/inativo dos anúncios)
    - page: int (Número da página)
    - size: int (Quantidade de itens por página)

    Retorno:
    - JSON contendo as médias mensais de preços.
    """

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'machine',
                openapi.IN_PATH,
                description="Tipo da máquina",
                type=openapi.TYPE_STRING,
                required=True),
            openapi.Parameter(
                'code_model',
                openapi.IN_PATH,
                description="Código do modelo da máquina",
                type=openapi.TYPE_STRING,
                required=True),
            openapi.Parameter(
                'year_model',
                openapi.IN_QUERY,
                description="Ano do modelo",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'year_reference',
                openapi.IN_QUERY,
                description="Ano de referência do anúncio",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'month_reference',
                openapi.IN_QUERY,
                description="Mês de referência do anúncio",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'is_active',
                openapi.IN_QUERY,
                description="Status ativo/inativo dos anúncios",
                type=openapi.TYPE_BOOLEAN),
            openapi.Parameter(
                'page',
                openapi.IN_QUERY,
                description="Número da página",
                type=openapi.TYPE_INTEGER,
                default=1),
            openapi.Parameter(
                'size',
                openapi.IN_QUERY,
                description="Quantidade de itens por página",
                type=openapi.TYPE_INTEGER,
                default=10)])
    def get(self, request, machine, code_model, *args, **kwargs):
        url = f"{ENDPOINT_CRAWLER}/calcs/average/month/{machine}?code_model={code_model}"
        params = {
            "year_model": request.GET.get("year_model"),
            "year_reference": request.GET.get("year_reference"),
            "month_reference": request.GET.get("month_reference"),
            "is_active": request.GET.get("is_active"),
            "page": request.GET.get("page", 1),
            "size": request.GET.get("size", 10),
        }
        params = {k: v for k, v in params.items() if v is not None}

        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        response = requests.get(url, headers=headers, params=params)

        try:
            response_data = response.json()
        except ValueError:
            response_data = {
                "detail": "Erro ao processar a resposta da API externa."}

        return response_log_user(request, response_data, response.status_code)


class AuxFinalReportReferenceDates(APIView):
    """
    Lista as datas de referência que estão ativas no ManageCrawler.

    Parâmetros:
    - Nenhum

    Retorno:
    - JSON contendo uma lista de datas de referência ativas.
    """
    permission_classes = (IsAuthenticated, CanFinalReport)

    def get(self, request, *args, **kwargs):
        active_dates = ManageCrawler.objects.filter(
            is_active=True).values(
            'year_reference', 'month_reference')
        return response_log_user(request, list(active_dates), 200)


class DownloadFinalReport(APIView):
    """
    Download do relatório final

    @access_token: string (Bearer Token) fornecer em header

    Parâmetros obrigatórios de URL:
    - year_reference: int (Ano de referência)
    - month_reference: int (Mês de referência)

    Retorno:
    - Arquivo binário (relatório final).
    """
    permission_classes = (IsAuthenticated, CanFinalReport)

    def get(self, request, year_reference, month_reference, *args, **kwargs):
        try:
            manage_crawler = ManageCrawler.objects.get(
                year_reference=year_reference,
                month_reference=month_reference,
                is_active=True
            )
        except ManageCrawler.DoesNotExist:
            return response_log_user(
                request,
                {"message": "Aguarde a execução da automação."},
                404
            )

        if manage_crawler.final_report:
            pdf_content = BytesIO(manage_crawler.final_report)

            response = StreamingHttpResponse(
                pdf_content,
                content_type="application/pdf"
            )

            response[
                'Content-Disposition'] = f'attachment; filename="final_report_{year_reference}_{month_reference}.pdf"'
            response['Access-Control-Expose-Headers'] = 'Content-Disposition'

            return response

            # Caso o relatório ainda não esteja disponível
        return JsonResponse(
            {"error": "Relatório final ainda não disponível."},
            status=202
        )


class DashboardGeneralKPI(APIView):
    """
    Retorna os principais KPIs do mercado automotivo para um determinado mês e ano.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo os KPIs gerais do mercado.
    """
    permission_classes = (IsAuthenticated, CanDataVisualization)

    def get(
            self,
            request,
            machine,
            year_reference,
            month_reference,
            *args,
            **kwargs):
        url = f"{ENDPOINT_CRAWLER}/core/general_kpi/{machine}/{year_reference}/{month_reference}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            kpi_data = response.json()
            return response_log_user(request, kpi_data, 200)
        except requests.RequestException as e:
            return response_log_user(request, {"detail": str(e)}, 500)


class DashboardGeographicPricingAnalysis(APIView):
    """
    Retorna uma análise de preços médios por estado e cidade.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo os preços médios agrupados por estado e cidade.
    """
    permission_classes = (IsAuthenticated, CanDataVisualization)

    def get(
            self,
            request,
            machine,
            year_reference,
            month_reference,
            *args,
            **kwargs):
        url = f"{ENDPOINT_CRAWLER}/core/geographic_pricing_analysis/{machine}/{year_reference}/{month_reference}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            analysis_data = response.json()
            return response_log_user(request, analysis_data, 200)
        except requests.RequestException as e:
            return response_log_user(request, {"detail": str(e)}, 500)


class DashboardBrandModelAnalysis(APIView):
    """
    Retorna uma análise comparativa entre marcas e modelos de veículos.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo estatísticas como:
        - Marcas com mais anúncios.
        - Preço médio por marca.
        - Distribuição de preços por marca.
        - Comparação de preços por tipo de câmbio e carroceria.
    """
    permission_classes = (IsAuthenticated, CanDataVisualization)

    def get(
            self,
            request,
            machine,
            year_reference,
            month_reference,
            *args,
            **kwargs):
        url = f"{ENDPOINT_CRAWLER}/core/brand_model_analysis/{machine}/{year_reference}/{month_reference}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            analysis_data = response.json()
            return response_log_user(request, analysis_data, 200)
        except requests.RequestException as e:
            return response_log_user(request, {"detail": str(e)}, 500)
