import uuid

from django.db import models


class ManageCrawler(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    is_active = models.BooleanField(default=True)
    start_process = models.DateTimeField()
    finish_process = models.DateTimeField(
        null=True, blank=True)
    year_reference = models.IntegerField()
    month_reference = models.IntegerField()
    # Armazenar arquivos binários diretamente no banco de dados pode impactar
    # negativamente a performance, pois aumenta o tamanho da base, dificulta
    # o backup e pode sobrecarregar consultas. Uma abordagem melhor seria
    # armazenar o binário em um bucket (como AWS S3, Google Cloud Storage ou MinIO)
    # e salvar apenas a URL do arquivo no banco.
    final_report = models.BinaryField(
        null=True, blank=True)  # Melhor armazenar em um bucket

    class Meta:
        db_table = 'crawler'

    def __str__(self):
        return f"ManageCrawler {self.id} - {self.year_reference}/{self.month_reference}"
