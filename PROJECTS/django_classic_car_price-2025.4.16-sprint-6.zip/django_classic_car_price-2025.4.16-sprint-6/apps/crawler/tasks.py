import os
import base64
import logging
from datetime import datetime

import requests
from celery import shared_task

from apps.crawler.utils import monitor_task_status
from config.settings import ENDPOINT_CRAWLER, TOKEN_CRAWLER


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


PDF_OUTPUT_DIR = os.path.join(
    os.path.dirname(
        os.path.abspath(__file__)),
    '..',
    '..',
    'pdfs')
# Certifique-se de que o diretório existe
os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)


@shared_task
def run_all_process_from_crawler_api(machine, site):
    from apps.crawler.models import ManageCrawler
    from apps.send_email.tasks import send_email_attachment_final_report_task

    try:
        # Chama a API para iniciar o processo
        url = f"{ENDPOINT_CRAWLER}/development/run/all/process/{machine}/{site}"
        headers = {
            "Authorization": f"Bearer {TOKEN_CRAWLER}",
            "User-Agent": "insomnia/8.4.1"
        }
        response = requests.post(url, headers=headers)

        if response.status_code != 202:
            logger.error(
                f"Falha ao iniciar o processo. Status: {response.status_code}")
            return {
                "error": "Falha ao iniciar o processo no crawler",
                "status_code": response.status_code}

        # Pega o primeiro task_id para monitoramento
        api_response = response.json()
        task_id = api_response.get("task_id")
        if not task_id:
            logger.error("Nenhum task_id retornado pela API.")
            return {"error": "Nenhum task_id retornado pela API."}

        logger.info(f"Tarefa inicial iniciada com task_id: {task_id}")

        # Definindo year_reference e month_reference com base na data de início
        now = datetime.utcnow()
        year_reference = now.year
        month_reference = now.month

        # Criação inicial da instância na model ManageCrawler
        ManageCrawler.objects.filter(
            year_reference=year_reference,
            month_reference=month_reference).update(
            is_active=False)

        # Criação inicial da instância na model ManageCrawler
        manage_crawler = ManageCrawler.objects.create(
            start_process=now,
            year_reference=year_reference,
            month_reference=month_reference,
            is_active=True
        )
        logger.info(
            f"Instância de ManageCrawler criada com ID: {manage_crawler.id}")

        # Monitora o primeiro task_id até SUCCESS
        result = monitor_task_status(task_id, final_status="SUCCESS")
        if result.get("status") != "SUCCESS":
            logger.error("Falha ao processar task inicial.")
            return {
                "error": "Falha ao processar task inicial.",
                "result": result}

        # Pega os result_ids da resposta da primeira task
        result_ids = result.get("result", {}).get("result_ids")
        if not result_ids:
            logger.error("Nenhuma lista de task_ids retornada.")
            return {"error": "Nenhuma lista de task_ids retornada."}

        # Monitora o primeiro result_id até PDF_GENERATED
        pdf_task_id = result_ids[0]
        logger.info(
            f"Iniciando monitoramento do task_id do PDF: {pdf_task_id}")
        pdf_result = monitor_task_status(
            pdf_task_id, final_status="PDF_GENERATED")

        # Verifica o status final do segundo task_id
        if pdf_result.get("status") != "PDF_GENERATED":
            logger.error(
                f"Falha ao gerar PDF. Status: {pdf_result.get('status')}")
            return {"error": "Falha ao gerar o PDF.", "result": pdf_result}

        # Decodifica e armazena o PDF diretamente no campo final_report
        pdf_base64 = pdf_result.get("result", {}).get("pdf_base64")
        if not pdf_base64:
            logger.error("Nenhum PDF retornado no resultado.")
            return {"error": "Nenhum PDF retornado no resultado."}

        # Salva o PDF temporariamente no diretório especificado
        pdf_data = base64.b64decode(pdf_base64)
        pdf_filename = os.path.join(PDF_OUTPUT_DIR, f"{manage_crawler.id}.pdf")
        with open(pdf_filename, 'wb') as pdf_file:
            pdf_file.write(pdf_data)
        logger.info(f"PDF salvo temporariamente em {pdf_filename}")

        # Atualiza a instância de ManageCrawler com o PDF e o finish_process
        manage_crawler.finish_process = datetime.utcnow()
        # Armazenando o PDF diretamente no campo
        manage_crawler.final_report = pdf_data
        manage_crawler.save()

        # Remove o PDF do sistema de arquivos
        os.remove(pdf_filename)
        logger.info(f"PDF removido do sistema de arquivos: {pdf_filename}")

        logger.info(f"PDF armazenado com sucesso na model ManageCrawler.")

        # Chama a task de envio de emails
        send_email_attachment_final_report_task.delay()

        return {
            "status": "SUCCESS",
            "manage_crawler_id": str(
                manage_crawler.id)}

    except Exception as e:
        logger.exception(f"Erro durante o processo do crawler: {str(e)}")
        return {"error": str(e)}
