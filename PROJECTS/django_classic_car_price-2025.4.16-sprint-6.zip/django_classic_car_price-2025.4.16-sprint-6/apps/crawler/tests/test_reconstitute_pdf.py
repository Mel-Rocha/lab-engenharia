"""
Teste para reconstituir o pdf resultante da rodada do processo da api do crawler
"""
from datetime import datetime

import pytest
import pytz

from apps.crawler.models import ManageCrawler
import os
import django

# Configura o Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()


@pytest.fixture
def manage_crawler(db):
    timezone = pytz.timezone('UTC')
    return ManageCrawler.objects.create(
        id='66cce0f3-6b1d-4a9e-9ad8-482401a55607',
        start_process=timezone.localize(datetime.now()),
        year_reference=datetime.now().year,
        month_reference=datetime.now().month,
        final_report=b'Some PDF data'
    )


@pytest.mark.django_db
def save_pdf_from_db(manage_crawler_id, output_dir='output_pdfs'):
    manage_crawler = ManageCrawler.objects.get(id=manage_crawler_id)
    pdf_data = manage_crawler.final_report
    if not pdf_data:
        print(f"No PDF found for ManageCrawler ID: {manage_crawler_id}")
        return
    os.makedirs(output_dir, exist_ok=True)
    pdf_filename = os.path.join(output_dir, f"{manage_crawler_id}.pdf")
    with open(pdf_filename, 'wb') as pdf_file:
        pdf_file.write(pdf_data)
    print(f"PDF saved successfully to {pdf_filename}")


@pytest.mark.django_db
def test_save_pdf_from_db(manage_crawler):
    save_pdf_from_db(manage_crawler.id)
