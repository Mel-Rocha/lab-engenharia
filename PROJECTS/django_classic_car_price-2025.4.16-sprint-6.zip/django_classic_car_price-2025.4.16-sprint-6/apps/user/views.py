import json

from rest_framework import viewsets, generics
from rest_framework.exceptions import MethodNotAllowed
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView

from apps.core import gateway
from apps.user.models import User
from apps.core.utils import CustomPagination
from apps.core.permissions import IsAdminOrReadOnly
from apps.user.serializers import UserSerializer, MyTokenObtainPairSerializer
from apps.user.utils import validate_password


class UserViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gerenciar usuários.

    Objetivo:
        - Administradores podem listar, editar e excluir qualquer usuário.
        - Usuários comuns podem visualizar e editar apenas seus próprios dados.

    @access_token: string (Bearer Token) (fornecer em header)

    Métodos:
        - list: Administradores podem listar todos os usuários.
        - retrieve: Usuários podem visualizar seus próprios dados.
        - update/partial_update: Usuários podem editar seus próprios dados.
        - destroy: Apenas administradores podem excluir usuários.

    Retorno:
        - list (GET /users/): Retorna uma lista de usuários (list[dict]).
        - retrieve (GET /users/{id}/): Retorna os detalhes de um usuário (dict).
        - update (PUT /users/{id}/): Atualiza os dados do usuário e retorna os dados modificados (dict).
        - partial_update (PATCH /users/{id}/): Atualiza parcialmente os dados do usuário (dict).
        - destroy (DELETE /users/{id}/): Retorna 204 No Content se a exclusão for bem-sucedida.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsAdminOrReadOnly]
    pagination_class = CustomPagination

    def get_queryset(self):
        """ Administradores veem todos os usuários; usuários comuns veem apenas seus próprios dados """
        if getattr(self.request.user, "is_admin", False):
            return User.objects.all()
        return User.objects.filter(id=self.request.user.id)

    def create(self, request, *args, **kwargs):
        """ Desabilita o método create """
        raise MethodNotAllowed("POST")


class RegisterView(generics.CreateAPIView):
    """
    Endpoint para registro de novos usuários.

    Objetivo:
        - Permite que qualquer pessoa crie uma conta no sistema.

    Parâmetros:
        - username: string (Obrigatório)
        - password: string (Obrigatório)

    Retorno:
        - 201 Created: Retorna os dados do usuário recém-criado (dict).
    """
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = UserSerializer


class MyTokenObtainPairView(TokenObtainPairView):
    """
    Endpoint para obtenção de tokens JWT.

    Objetivo:
        - Gera um par de tokens (access e refresh) para autenticação do usuário.

    Parâmetros:
        - username: string (Obrigatório)
        - password: string (Obrigatório)

    Retorno:
        - 200 OK: Retorna o par de tokens (access e refresh) e os dados do usuário autenticado (dict).
    """
    serializer_class = MyTokenObtainPairSerializer


class UpdatePasswordAccount(gateway.Update):
    """
    Objetivo: Atualizar a senha do usuário autenticado.

    body:
    "new_password": "string"

    Retorno: 200 OK, 400 Bad Request
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = User.objects.filter(is_active=True)
    lookup_field = 'id'

    def update(self, request, *args, **kwargs):
        new_password = request.data.get('new_password')

        if not validate_password(new_password):
            return gateway.response_log_user(
                request, gateway.message_code[400], 400)

        request.user.set_password(new_password)
        request.user.save()

        return gateway.response_log_user(request, gateway.message_code[200])
