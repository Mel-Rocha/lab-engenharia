from django.contrib.auth.models import AbstractUser
from django.db import models

from apps.core.models import Core


class User(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_corporative = models.BooleanField(default=False)
    contract_start = models.DateField(auto_now_add=True)
    contract_end = models.DateField(auto_now_add=False, null=True, blank=True)
    company = models.CharField(max_length=150, null=True, blank=True)
    position = models.CharField(max_length=100, null=True, blank=True)
    can_insights = models.BooleanField(default=False)
    can_final_report = models.BooleanField(default=False)
    can_predict = models.BooleanField(default=False)
    can_data_visualization = models.BooleanField(default=False)
