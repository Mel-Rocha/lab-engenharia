import string
import random


def validate_password(pswrd: str):
    if len(pswrd) < 8:
        return False
    if not any([char in pswrd for char in string.ascii_uppercase]):
        return False
    if not any([symbol in pswrd for symbol in string.punctuation]):
        return False
    return pswrd


def generate_random_password():
    characters = list(string.ascii_letters + string.digits)
    sp_char = list("!@#$%^&*()")
    length = 10
    random.shuffle(characters + sp_char)
    da_password = []
    for i in range(length):
        da_password.append(random.choice(characters + sp_char))
    random.shuffle(da_password)
    return "".join(da_password)
