from django.contrib.auth.hashers import make_password
from rest_framework import serializers
from django.forms.models import model_to_dict
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from apps.user.models import User


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
        extra_kwargs = {'password': {'write_only': True}}

    def validate(self, data):
        """Garante que um usuário seja apenas 'is_admin' ou 'is_corporative', e que 'is_corporative' tenha pelo menos um privilégio ativo."""
        is_admin = data.get("is_admin", False)
        is_corporative = data.get("is_corporative", False)

        if is_admin and is_corporative:
            raise serializers.ValidationError(
                "O usuário não pode ser admin e corporativo ao mesmo tempo.")

        if is_corporative:
            can_insights = data.get("can_insights", False)
            can_final_report = data.get("can_final_report", False)
            can_predict = data.get("can_predict", False)
            can_data_visualization = data.get("can_data_visualization", False)

            if not (
                    can_insights or can_final_report or can_predict or can_data_visualization):
                raise serializers.ValidationError(
                    "Usuários corporativos precisam ter pelo menos um privilégio ativo."
                )

        return data

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['username'] = user.username
        return token

    def validate(self, attrs):
        data = super().validate(attrs)

        user = self.user  # Obtém o usuário autenticado

        # Converte a instância do usuário para um dicionário automaticamente
        user_data = model_to_dict(
            user,
            exclude=[
                'password',
                'groups',
                'user_permissions'])

        # Adicionando os dados do usuário na resposta
        data['user'] = user_data

        return data
