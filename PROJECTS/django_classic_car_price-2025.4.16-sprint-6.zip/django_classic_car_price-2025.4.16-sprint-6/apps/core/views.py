from celery.result import AsyncResult
from django.http import JsonResponse
from rest_framework.views import APIView


class CheckTaskStatusDjango(APIView):
    """
    Objetivo: Verificar o status das tasks do projeto Django.

    Parâmetros:
    obrigatórios:
    - task_id: uuid

    Retorno: JSON com o status da task, resultado da tarefa.
    """

    def get(self, request, task_id, *args, **kwargs):
        # Converte UUID para string
        task_id_str = str(task_id)
        task_result = AsyncResult(task_id_str)
        response_data = {
            "task_id": task_id_str,
            "status": task_result.status,
            "result": task_result.result
        }
        return JsonResponse(response_data)
