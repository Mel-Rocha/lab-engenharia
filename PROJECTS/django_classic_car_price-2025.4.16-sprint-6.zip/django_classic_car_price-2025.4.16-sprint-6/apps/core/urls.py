from django.urls import path
from apps.core.views import CheckTaskStatusDjango

urlpatterns = [
    path(
        'django/check-task-status/<uuid:task_id>/',
        CheckTaskStatusDjango.as_view(),
        name='check_task_status_django'),
]
