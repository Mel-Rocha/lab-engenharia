from symtable import Class

from rest_framework.permissions import BasePermission


class IsAdminUser(BasePermission):
    """
        Permite acesso aos utilizadores Administradores
    """

    def has_permission(self, request, view):
        return request.user and request.user.is_admin


class IsCorporativeUser(BasePermission):
    """
        Permite acesso aos utilizadores Corporativos
    """

    def has_permission(self, request, view):
        return request.user and request.user.is_corporative


class CanPredict(BasePermission):
    """
    Permite acesso aos utilizadores com permissão de predição
    """

    def has_permission(self, request, view):
        return request.user and (
            request.user.is_admin or request.user.can_predict)


class CanInsights(BasePermission):
    """
    Permite acesso aos utilizadores com permissão de insights
    """

    def has_permission(self, request, view):
        return request.user and (
            request.user.is_admin or request.user.can_insights)


class CanFinalReport(BasePermission):
    """
    Permite acesso aos utilizadores com permissão de relatório final
    """

    def has_permission(self, request, view):
        return request.user and (
            request.user.is_admin or request.user.can_final_report)


class CanDataVisualization(BasePermission):
    """
    Permite acesso aos utilizadores com permissão de visualização de dados
    """

    def has_permission(self, request, view):
        return request.user and (
            request.user.is_admin or request.user.can_data_visualization)


class IsAdminOrReadOnly(BasePermission):
    """
    Permite apenas administradores acessar métodos de listagem e exclusão.
    Usuários comuns podem apenas visualizar e editar seus próprios dados.
    """

    def has_permission(self, request, view):
        # Listagem de usuários e exclusão só podem ser feitas por
        # administradores
        if view.action in ['list', 'destroy']:
            return request.user and request.user.is_admin

        # Outras ações (retrieve, update, partial_update) são permitidas
        return True

    def has_object_permission(self, request, view, obj):
        # Administradores podem acessar qualquer objeto
        if request.user.is_admin:
            return True

        # Usuários comuns podem apenas ver e editar seus próprios dados
        return obj == request.user
