import pytest
from django.test import RequestFactory
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.test import force_authenticate

from apps.core.permissions import IsAdminUser, IsCorporativeUser, IsAdminOrReadOnly
from apps.user.models import User


@pytest.fixture
def factory():
    return RequestFactory()


@pytest.fixture
def admin_user(db):
    user = User.objects.create_user(username='admin', password='password123')
    user.is_admin = True
    user.is_corporative = False
    user.save()
    return user


@pytest.fixture
def corporative_user(db):
    user = User.objects.create_user(
        username='corporative',
        password='password123')
    user.is_admin = False
    user.is_corporative = True
    user.save()
    return user


@pytest.fixture
def regular_user(db):
    user = User.objects.create_user(username='regular', password='password123')
    user.is_admin = False
    user.is_corporative = False
    user.save()
    return user


class AdminView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        return Response({"message": "Acesso permitido!"})


class CorporativeView(APIView):
    permission_classes = [IsCorporativeUser]

    def get(self, request):
        return Response({"message": "Acesso permitido!"})


class AdminOrReadOnlyView(APIView):
    permission_classes = [IsAdminOrReadOnly]

    def get(self, request):
        return Response({"message": "Acesso permitido!"})

    def delete(self, request):
        return Response({"message": "Exclusão permitida!"})

# ============ Testes para IsAdminUser ============


@pytest.mark.django_db
def test_admin_user_has_permission(factory, admin_user):
    request = factory.get('/admin-only/')
    force_authenticate(request, user=admin_user)
    view = AdminView.as_view()
    response = view(request)
    assert response.status_code == 200


@pytest.mark.django_db
def test_non_admin_user_no_permission(factory, corporative_user):
    request = factory.get('/admin-only/')
    force_authenticate(request, user=corporative_user)
    view = AdminView.as_view()
    response = view(request)
    assert response.status_code == 403

# ============ Testes para IsCorporativeUser ============


@pytest.mark.django_db
def test_corporative_user_has_permission(factory, corporative_user):
    request = factory.get('/corporative-only/')
    force_authenticate(request, user=corporative_user)
    view = CorporativeView.as_view()
    response = view(request)
    assert response.status_code == 200


@pytest.mark.django_db
def test_non_corporative_user_no_permission(factory, admin_user):
    request = factory.get('/corporative-only/')
    force_authenticate(request, user=admin_user)
    view = CorporativeView.as_view()
    response = view(request)
    assert response.status_code == 403
