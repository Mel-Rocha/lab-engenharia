import requests
from drf_yasg import openapi
from rest_framework.views import APIView
from drf_yasg.utils import swagger_auto_schema
from rest_framework.permissions import IsAuthenticated

from apps.core.permissions import CanPredict
from apps.core.gateway import response_log_user
from config.settings import ENDPOINT_IA, TOKEN_IA


class CarCategoryListView(APIView):
    """
    Objetivo: Listar categorias de carros.

    @access_token: string (Bearer Token) (fornecer em header)

    Parâmetros obrigatórios de URL:
    - category: str (Categoria do carro)

    Parâmetros opcionais de URL:
    - page: int (Número da página)
    - page_size: int (Quantidade de itens por página)

    Retorno:
    - JSON.
    """
    permission_classes = (IsAuthenticated, CanPredict)

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'category',
                openapi.IN_PATH,
                description="Category of the car",
                type=openapi.TYPE_STRING,
                required=True),
            openapi.Parameter(
                'page',
                openapi.IN_QUERY,
                description="Page number",
                type=openapi.TYPE_INTEGER),
            openapi.Parameter(
                'page_size',
                openapi.IN_QUERY,
                description="Number of items per page",
                type=openapi.TYPE_INTEGER)])
    def get(self, request, category):
        page = request.query_params.get('page', 1)
        page_size = request.query_params.get('page_size', 10)
        url = f"{ENDPOINT_IA}/car/list/{category}"
        headers = {
            "Authorization": f"Bearer {TOKEN_IA}"
        }
        params = {
            "page": page,
            "page_size": page_size
        }
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response_log_user(
                request, response.json(), response.status_code)
        except requests.RequestException as e:
            if hasattr(
                    e.response,
                    'text') and hasattr(
                    e.response,
                    'status_code'):
                return response_log_user(
                    request, e.response.text, e.response.status_code)
            return response_log_user(request, str(e), 500)


class CarBrandListView(APIView):
    """
    Objective: Listar as marcas, seus modelos e suas carrocerias.

    @access_token: string (Bearer Token) (fornecer no header)

    Optional URL Parameters:
    - brand: str
    - model: str

    Return:
    - JSON.
    """
    permission_classes = (IsAuthenticated, CanPredict)

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'brand',
                openapi.IN_QUERY,
                description="Specific brand to filter",
                type=openapi.TYPE_STRING
            ),
            openapi.Parameter(
                'model',
                openapi.IN_QUERY,
                description="Specific model to filter",
                type=openapi.TYPE_STRING
            )
        ]
    )
    def get(self, request):
        brand = request.query_params.get('brand', None)
        model = request.query_params.get('model', None)
        url = f"{ENDPOINT_IA}/car/list-brands"
        headers = {
            "Authorization": f"Bearer {TOKEN_IA}"
        }
        params = {}
        if brand:
            params['brand'] = brand
            if model:
                params['model'] = model

        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response_log_user(
                request, response.json(), response.status_code)
        except requests.RequestException as e:
            if hasattr(
                    e.response,
                    'text') and hasattr(
                    e.response,
                    'status_code'):
                return response_log_user(
                    request, e.response.text, e.response.status_code)
            return response_log_user(request, str(e), 500)


class CarStateListView(APIView):
    """
    Objective: List car states.

    @access_token: string (Bearer Token) (provide in header)

    Optional URL Parameters:
    - state: str (Specific state to filter)

    Return:
    - JSON.
    """
    permission_classes = (IsAuthenticated, CanPredict)

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'state',
                openapi.IN_QUERY,
                description="Specific state to filter",
                type=openapi.TYPE_STRING
            )
        ]
    )
    def get(self, request):
        state = request.query_params.get('state', None)
        url = f"{ENDPOINT_IA}/car/list-states"
        headers = {
            "Authorization": f"Bearer {TOKEN_IA}"
        }
        params = {}
        if state:
            params['state'] = state

        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response_log_user(
                request, response.json(), response.status_code)
        except requests.RequestException as e:
            if hasattr(
                    e.response,
                    'text') and hasattr(
                    e.response,
                    'status_code'):
                return response_log_user(
                    request, e.response.text, e.response.status_code)
            return response_log_user(request, str(e), 500)


class CarPricePredictionView(APIView):
    """
    Objetivo: Prever o preço de um carro.

    @access_token: string (Bearer Token) (fornecer em header)

    Retorno:
    - JSON.
    """
    permission_classes = (IsAuthenticated, CanPredict)

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'brand': openapi.Schema(type=openapi.TYPE_STRING, description='Brand of the car'),
                'model': openapi.Schema(type=openapi.TYPE_STRING, description='Model of the car'),
                'year_model': openapi.Schema(type=openapi.TYPE_INTEGER, description='Year model of the car'),
                'mileage': openapi.Schema(type=openapi.TYPE_INTEGER, description='Mileage of the car'),
                'gear': openapi.Schema(type=openapi.TYPE_STRING, description='Gear type of the car'),
                'fuel': openapi.Schema(type=openapi.TYPE_STRING, description='Fuel type of the car'),
                'bodywork': openapi.Schema(type=openapi.TYPE_STRING, description='Bodywork type of the car'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, description='City where the car is located'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, description='State where the car is located')
            },
            required=['brand', 'model', 'year_model', 'mileage', 'gear', 'fuel', 'bodywork', 'city', 'state']
        )
    )
    def post(self, request):
        url = f"{ENDPOINT_IA}/car/predict"
        headers = {
            "Authorization": f"Bearer {TOKEN_IA}",
            "Content-Type": "application/json"
        }
        try:
            response = requests.post(url, headers=headers, json=request.data)
            response.raise_for_status()
            data = response.json()
            return response_log_user(request, data, 200)
        except requests.RequestException as e:
            return response_log_user(request, str(e), 500)


class CarPriceBrandPredictionView(APIView):
    """
    Objetivo: Prever o preço de todos os modelos de uma determinado marca.

    @access_token: string (Bearer Token) (fornecer em header)

    Parâmetros obrigatórios de URL:
    - brand: str (Marca do carro)

     Parâmetros opcionais de URL:
    - page: int (Número da página)
    - page_size: int (Quantidade de itens por página)

    Retorno:
    - JSON.
    """
    permission_classes = (IsAuthenticated, CanPredict)

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'page',
                openapi.IN_QUERY,
                description="Page number",
                type=openapi.TYPE_INTEGER
            ),
            openapi.Parameter(
                'page_size',
                openapi.IN_QUERY,
                description="Number of items per page",
                type=openapi.TYPE_INTEGER
            )
        ]
    )

    def post(self, request, brand):
        page = request.query_params.get('page', None)
        page_size = request.query_params.get('page_size', None)
        url = f"{ENDPOINT_IA}/car/brand_predict/{brand}"
        headers = {
            "Authorization": f"Bearer {TOKEN_IA}",
            "Content-Type": "application/json"
        }

        params = {}
        if page:
            params['page'] = page
        if page_size:
            params['page_size'] = page_size

        try:
            response = requests.post(url, headers=headers, json=request.data, params=params)
            response.raise_for_status()
            data = response.json()
            return response_log_user(request, data, 200)
        except requests.RequestException as e:
            return response_log_user(request, str(e), 500)
