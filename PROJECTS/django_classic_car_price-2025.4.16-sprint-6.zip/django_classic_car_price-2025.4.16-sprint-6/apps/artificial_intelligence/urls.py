from django.urls import path
from apps.artificial_intelligence.views import CarCategoryListView, CarPricePredictionView, CarPriceBrandPredictionView, \
    CarBrandListView, CarStateListView

urlpatterns = [
    path(
        'list/<str:category>/',
        CarCategoryListView.as_view(),
        name='ia-category-list'),
    path(
        'list-brands/',
        CarBrandListView.as_view(),
        name='ia-brand-list'
    ),
    path(
        'list-states/',
        CarStateListView.as_view(),
        name='ia-state-list'
    ),
    path(
        'predict/price/',
        CarPricePredictionView.as_view(),
        name='ia-price-prediction'),
    path(
        'predict/price/brand/<str:brand>/',
        CarPriceBrandPredictionView.as_view(),
        name='ia-price-bulk-prediction'),
]
