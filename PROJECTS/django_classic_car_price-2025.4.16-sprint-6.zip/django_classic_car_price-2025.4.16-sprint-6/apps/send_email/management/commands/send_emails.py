from django.core.management.base import BaseCommand
from apps.send_email.utils import send_email_attachment_final_report


class Command(BaseCommand):
    help = 'Send report emails to all active users'

    def handle(self, *args, **kwargs):
        send_email_attachment_final_report()
        self.stdout.write(self.style.SUCCESS(
            'Successfully sent emails to all active users'))
