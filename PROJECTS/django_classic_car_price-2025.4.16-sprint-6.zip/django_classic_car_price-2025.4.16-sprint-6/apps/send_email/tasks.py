from celery import shared_task

from apps.send_email.utils import send_email_attachment_final_report, send_first_access
from apps.user.models import User


@shared_task
def send_email_attachment_final_report_task():
    send_email_attachment_final_report()


@shared_task
def send_account_info_email_task(
        user_id,
        password,
        start_date,
        end_date,
        privileges):
    user = User.objects.get(id=user_id)
    send_first_access(user, password, start_date, end_date, privileges)
