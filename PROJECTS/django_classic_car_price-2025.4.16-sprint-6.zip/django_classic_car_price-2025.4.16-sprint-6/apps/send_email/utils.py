import logging
import datetime

from django.utils.html import strip_tags
from django.template.loader import render_to_string
from django.core.mail import send_mail, EmailMessage

from apps.user.models import User
from apps.crawler.models import ManageCrawler


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def send_email_attachment_final_report():
    users = User.objects.filter(
        is_active=True,
        is_corporative=True,
        can_final_report=True)
    current_date = datetime.datetime.now()
    year = current_date.year
    month = current_date.strftime('%m')

    for user in users:
        subject = 'Relatório de Preços de Veículos'
        html_message = render_to_string('email_template.html', {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'position': user.position,
            'company': user.company,
            'year': year,
            'month': month,
        })
        plain_message = strip_tags(html_message)
        from_email = 'from@example.com'
        to = user.email

        final_report = None

        try:
            # Busca o ManageCrawler
            manage_crawler = ManageCrawler.objects.get(
                year_reference=year, month_reference=month, is_active=True)
            final_report = manage_crawler.final_report

        except ManageCrawler.DoesNotExist:
            # Log opcional: ManageCrawler não encontrado
            logger.info(f"ManageCrawler para {year}-{month} não encontrado.")

        # Verifica se há um anexo válido
        if final_report:
            email = EmailMessage(
                subject,
                plain_message,
                from_email,
                [to],
            )
            email.attach('final_report.pdf', final_report, 'application/pdf')
            email.send()
        else:
            send_mail(
                subject,
                plain_message,
                from_email,
                [to],
                html_message=html_message)


def send_first_access(user, password, start_date, end_date, privileges):
    subject = 'Informações da Conta'
    html_message = render_to_string(
        'registration/first_access_template.html',
        {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'username': user.username,
            'password': password,
            'start_date': start_date,
            'end_date': end_date,
            'privileges': privileges,
        })
    plain_message = strip_tags(html_message)
    from_email = 'from@example.com'
    to = user.email

    send_mail(
        subject,
        plain_message,
        from_email,
        [to],
        html_message=html_message
    )
