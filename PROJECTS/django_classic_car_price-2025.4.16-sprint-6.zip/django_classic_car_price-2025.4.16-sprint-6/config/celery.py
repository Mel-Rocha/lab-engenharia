from __future__ import absolute_import, unicode_literals
from apps.crawler.tasks import run_all_process_from_crawler_api
import os
import logging

from celery import Celery
from celery.schedules import crontab


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

app = Celery('config')

app.config_from_object('django.conf:settings', namespace='CELERY')

app.autodiscover_tasks()
logger.info(f"Discovered tasks: {app.tasks.keys()}")

app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='America/Sao_Paulo',
    enable_utc=True,
    result_expires=3600,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_time_limit=9900,  # 2 horas e 45 minutos (165 minutos)
    task_soft_time_limit=9880,  # 2 horas, 44 minutos e 40 segundos
    broker_connection_retry_on_startup=True,
    worker_concurrency=4,
    beat_schedule={
        'run-crawler-task-monthly': {
            'task': 'apps.crawler.tasks.run_all_process_from_crawler_api',
            # Executa mensalmente às 3 horas da manhã
            'schedule': crontab(hour=3, minute=0, day_of_month='1'),
            # 'schedule': crontab(minute=28, hour=18, day_of_month=13),  # Executa especificamente 25/12 às 19:55
            'args': ('machine', 'usados_br'),
        }
    }
)
