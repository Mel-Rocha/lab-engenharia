# Rodando o projeto 


1. Prepare o ambiente
```bash
python3 -m venv venv
source venv/bin/activate
```

```bash
pip install -r requirements.txt
```

2. Crie o arquivo .env
3. Rode o projeto
```bash
docker compose up --build
```


# Variáveis de ambiente necessárias 📋

### Geral
- `DEBUG`: Defina como `"True"` para desenvolvimento, `"False"` para produção.
- `SECRET_KEY`: chave secreta.
- `ALLOWED_HOSTS`: lista de hosts permitidos para se conectar.
- `CORS_ALLOWED_ORIGINS`: lista de origens permitidas para fazer requisições cross-origin.
- `CSRF_TRUSTED_ORIGINS`: lista de origens confiáveis para proteção CSRF.
- `SWAGGER_HOST`: Url base para o swagger gerar os endpoints.

### Banco de Dados
- `DATABASE_URL`: A URL de conexão com o banco de dados Postgres.

### Email

- `EMAIL_HOST`: Servidor SMTP. Exemplo: smtp.gmail.com para o Gmail.
- `EMAIL_PORT`: Porta do servidor SMTP. Exemplo: 587 para o Gmail.
- `EMAIL_USE_TLS`:  Define se o Django usará uma conexão segura (TLS) ao enviar e-mails. Para o Gmail, isso deve ser configurado como True.
- `EMAIL_HOST_USER`:  será o remetente dos e-mails enviados pela aplicação.
- `EMAIL_HOST_PASSWORD`: A senha ou chave de acesso associada ao e-mail usado para autenticação no servidor SMTP. No caso do Gmail com 2FA, isso seria a Senha de Aplicativo gerada.
- `DEFAULT_FROM_EMAIL`: O endereço de e-mail padrão que aparecerá no campo "De" de todos os e-mails enviados pela aplicação.

### Redis

- `REDIS_HOST`: Nome do serviço Redis definido no arquivo `docker-compose.yml`.
- `REDIS_PORT`: O número da porta do servidor Redis.
- `REDIS_DB`: O número do banco de dados a ser usado no Redis.

### Crawler

- `ENDPOINT_CRAWLER`: A URL do endpoint para o serviço de busca.
- `TOKEN_CRAWLER`: O token de autenticação para o serviço de busca.

### Inteligência Artificial
- `ENDPOINT_IA`: A URL do endpoint para o serviço de IA.
- `TOKEN_IA`: O token de autenticação para o serviço de IA.

---

# Configuração conta Gmail para enviar os e-mails 📧

- Acesse a sua conta Gmail e clique na sua foto no canto superior direito e selecione a opção "Gerenciar sua Conta Google".
- Após isso vá até o campo "Segurança" e faça o processo para ativar a verificação de duas etapas.

![img.png](img/img.png)

- Após, clique sobre a opção Verificação de duas etapas, você será redirecionado a tela para informar sua senha, informe-a;

![img_1.png](img/img_1.png)

- Então clique em Senha de Apps, crie um novo app, pegue a senha que será informada e defina como valor da 
variável de ambiente `EMAIL_HOST_PASSWORD`.

![img_2.png](img/img_2.png)


---

# Configuração Postgres 🐘
Arquivo de configuração Postgres
```bash
sudo nano /etc/postgresql/15/main/postgresql.conf
```
Permita que o banco de dados escute todas as conexões
```bash
listen_addresses = '*'
```
Arquivo de configuração de acesso
```bash
sudo nano /etc/postgresql/15/main/pg_hba.conf
```
Permita conexões de todos os ips
```bash
host    all             all             0.0.0.0/0               md5
host    all             all             ::/0                    md5
```
Reinicie o postgres para aplicar as mudanças
```bash
sudo systemctl restart postgresql
```

---

## Testes e Segurança 🧪
O coverage executa todos os testes unitários do projeto usando o módulo pytest, e mede a cobertura do código, ou seja, 
ele verifica quais partes do código foram cobertas pelos testes durante a execução.
````bash
coverage run -m pytest
````
Geração de relatório de corbertura de testes.
````bash
coverage report -m
````

---

## Formatadores e Linters 💎
- Para aplicar recursivamente as correções de estilo PEP8 a todos os arquivos no diretório atual:
```bash
autopep8 --in-place --aggressive --aggressive --recursive .
```

---