# Rodando o projeto ⚙️
## Dependências do projeto

```bash
python3 -m venv venv
source venv/bin/activate
```

```bash
pip install -r requirements.txt
```

## Variaveis de ambiente necessárias 📝

### Banco Postgres
- DATABASE_URL: url do banco postgres

### Token
- SECRET_KEY: Chave de segurança
- AUTH_TOKEN: Token fixo

### Chaves de Api
- APIKEY_1
- APIKEY_2

### Redis
- REDIS_HOST: nome do serviço redis no arquivo docker compose
- REDIS_PORT
- REDIS_DB

---

## Configuração Postgres 🐘
Arquivo de configuração Postgres
```bash
sudo nano /etc/postgresql/15/main/postgresql.conf
```
Permita que o banco de dados escute todas as conexões
```bash
listen_addresses = '*'
```
Arquivo de configuração de acesso
```bash
sudo nano /etc/postgresql/15/main/pg_hba.conf
```
Permita conexões de todos os ips
```bash
host    all             all             0.0.0.0/0               md5
host    all             all             ::/0                    md5
```
Reinicie o postgres para aplicar as mudanças
```bash
sudo systemctl restart postgresql
```
## Rodar o projeto Localmente 🏠
- REDIS_HOST: localhost

```bash
 docker pull redis
```

```bash
 docker run -d -p 6379:6379 --name my-redis-crawler-machines redis
```
```bash
docker exec -it my-redis-crawler-machines redis-cli ping
```

```bash
celery -A celery_app worker --loglevel=info
```

```bash
uvicorn main:app --port 3001
```

## Rodar o projeto a partir do Docker 🐳
Executar o comando a seguir na raiz do projeto, construa os 
containers.
- Constrói os containers, inicia os serviços, escala o serviço do chrome para 4 instância e do 
celery_worker também.
```bash
sudo docker compose up --build
```

### Comandos Úteis:
- Desliga e remove os containers em seguida reconstrói e os inicia.
```bash
sudo docker-compose down --remove-orphans && docker-compose up --build -d
```

-  Para todos os containers Docker em execução e os remove.
```bash
sudo docker stop $(docker ps -aq) && docker rm $(docker ps -aq)
```

- desativa e remove containers:
definidos no docker-compose.yml, limpa redes 
e volumes órfãos não utilizados.
```bash
 sudo docker-compose down --remove-orphans
```
- containers em execução
```bash
 sudo docker ps # containers atuais em execução
 sudo docker ps -a # todos os containers, incluindo os que estão parados.
 ```
- Acessar container internamente
```bash
sudo docker exec -it <container_id> bash
```

- Logs dos containers em tempo real
```bash
sudo docker logs -f <container_name>
```


---

## Testes e Segurança 🧪
O coverage executa todos os testes unitários do projeto usando o módulo pytest, e mede a cobertura do código, ou seja, 
ele verifica quais partes do código foram cobertas pelos testes durante a execução.
````bash
coverage run -m pytest
````
Geração de relatório de corbertura de testes.
````bash
coverage report -m
````
## Bibliotecas Vulneráveis
Aferição das bibliotecas vulneráveis no projeto.
````bash
pip-audit 
````
---
## Migrações no banco de dados 🎲
Se o projeto não possuir a pasta migrations ou essa pasta estiver vazia, executar o comando a seguir:
```bash
aerich init -t settings.TORTOISE_ORM
```

```bash
aerich init-db
```

Sempre que um modelo for alterado (campos foram acrescentados, alterados ou removidos), executar os comando a seguir 
para aplicar as mudanças no seu banco de dados.

Comando para gerar os arquivos de migração

```bash
aerich migrate
```

Comando para aplicar as migrações no banco de dados

```bash
aerich upgrade
```
---

## Formatadores e Linters 💎

- Para verificar seu código em busca de problemas de estilo:
```bash
flake8 .
```

- Para formatar automaticamente seu código:
```bash
black .
```

- Para aplicar recursivamente as correções de estilo PEP8 a todos os arquivos no diretório atual:
```bash
autopep8 --in-place --aggressive --aggressive --recursive .
```