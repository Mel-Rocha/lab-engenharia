import os

from dotenv import load_dotenv
from tortoise import expand_db_url

load_dotenv()

DB_URL = os.getenv("DATABASE_URL")

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = os.getenv("REDIS_PORT", 6379)


TORTOISE_ORM = {
    "connections": {
        "default": expand_db_url(DB_URL),
    },
    "apps": {
        "models": {
            "models": ["apps.core.models", "apps.calcs.models", "aerich.models"],
            "default_connection": "default",
        }
    },
}
