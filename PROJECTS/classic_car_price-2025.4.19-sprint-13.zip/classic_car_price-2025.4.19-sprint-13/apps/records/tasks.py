import asyncio
from typing import Optional, List, Dict

from celery import shared_task

from apps.records.utils import fetch_records
from apps.core.db_manager import DatabaseManager
from apps.core.data_validate import ValidateData
from apps.records.db_manager import DatabaseManagerRecord


@shared_task
def fetch_records_task(
    machine: str,
    page: int,
    page_size: int,
    reference_dates: List[Dict[str, int]],
    code_model: Optional[str] = None,
):
    async def async_fetch_records():
        return await fetch_records(
            machine=machine,
            page=page,
            page_size=page_size,
            reference_dates=reference_dates,
            code_model=code_model,
        )

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            result = asyncio.ensure_future(async_fetch_records())
            return loop.run_until_complete(result)
        else:
            result = loop.run_until_complete(async_fetch_records())
    except Exception as e:
        print(f"Error occurred: {e}")
        return {"error": str(e)}

    return result


@shared_task
def duplicate_records_task(machine: str, records_data):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop = asyncio.get_event_loop()

    database_manager = DatabaseManager(machine, loop)
    validator = ValidateData(machine)
    failed_duplicates = []
    successful_duplicates = 0

    for record in records_data:
        combined_data = {
            **record["existing_data"],
            **record["new_data"],
        }  # Combina os dados antigos com os novos

        normalized_data = validator.apply_normalize([combined_data])
        validated_data, invalidated_data = validator.apply_business_rules(
            normalized_data
        )

        if validated_data:
            try:
                database_manager.save_to_database(
                    validated_data
                )  # Salva os dados no banco de dados
                successful_duplicates += 1
            except ValueError as e:
                failed_duplicates.append(
                    {
                        "record_id": str(record["record_id"]),
                        "causes_of_disposal": str(e),
                    }
                )
        else:
            for invalid_data in invalidated_data:
                failed_duplicates.append(
                    {
                        "record_id": str(record["record_id"]),
                        "causes_of_disposal": invalid_data[1],
                    }
                )

    return {
        "successful_duplicates": successful_duplicates,
        "failed_duplicates": failed_duplicates,
    }


@shared_task
def deactivate_records_task(machine: str, record_ids: list):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop = asyncio.get_event_loop()

    database_manager_record = DatabaseManagerRecord(machine, loop)

    async def deactivate(record_id):
        await database_manager_record.deactivate_record(record_id)

    loop = asyncio.get_event_loop()
    tasks = [loop.create_task(deactivate(record_id)) for record_id in record_ids]
    loop.run_until_complete(asyncio.gather(*tasks))

    return {"message": "Todos os anúncios foram desativados com sucesso!"}
