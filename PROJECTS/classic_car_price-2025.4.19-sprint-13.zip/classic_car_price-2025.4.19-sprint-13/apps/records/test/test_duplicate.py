from unittest.mock import patch, MagicMock

import pytest

from apps.records.tasks import duplicate_records_task


@pytest.fixture
def mock_database_manager():
    """Mock para DatabaseManager"""
    with patch("apps.core.db_manager.DatabaseManager") as mock:
        instance = mock.return_value
        instance.save_to_database = MagicMock()
        yield instance


@pytest.fixture
def mock_validator():
    """Mock para ValidateData"""
    with patch("apps.core.data_validate.ValidateData") as mock:
        instance = mock.return_value
        instance.apply_normalize = MagicMock()
        instance.apply_business_rules = MagicMock()
        yield instance


def test_duplicate_records_task_save_error(mock_database_manager, mock_validator):
    """Testa erro ao salvar no banco de dados"""

    mock_validator.apply_normalize.return_value = [{"normalized": "data"}]
    mock_validator.apply_business_rules.return_value = ([{"validated": "data"}], [])

    mock_database_manager.save_to_database.side_effect = ValueError("Erro ao salvar")

    records_data = [
        {
            "record_id": "789",
            "existing_data": {"price": 40000},
            "new_data": {"mileage": 70000},
        }
    ]

    result = duplicate_records_task("car", records_data)

    assert result["successful_duplicates"] == 0
    assert len(result["failed_duplicates"]) == 1
    assert result["failed_duplicates"][0]["record_id"] == "789"
    assert result["failed_duplicates"][0]["causes_of_disposal"] == [
        "price below cutoff value",
        "year_model could not be inferred",
        "missing required fields"
    ]
