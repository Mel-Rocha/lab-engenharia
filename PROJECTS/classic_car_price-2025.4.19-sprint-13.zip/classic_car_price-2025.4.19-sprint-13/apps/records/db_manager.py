import uuid
import logging

from apps.core.models import MachineTable


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManagerRecord:

    def __init__(self, machine, loop):
        self.machine = machine
        self.machine_tables = {
            "machine": MachineTable,
        }
        self.loop = loop

    async def deactivate_record(self, record_id: uuid.UUID):
        table = self.machine_tables.get(self.machine, None)
        if table is not None:
            await table.filter(id=record_id).update(is_active=False)
            return {"message": f"O anúncio {record_id} foi desativado!"}
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def update_record(self, record_id: uuid.UUID, updates: dict):
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"No corresponding table found for machine: {self.machine}"
            )

        allowed_update_fields = {"price", "description", "mileage", "title"}
        update_data = {
            field: value
            for field, value in updates.items()
            if field in allowed_update_fields
        }
        if not update_data:
            raise ValueError("No valid fields to update.")
        record = await table.filter(id=record_id, is_active=True).first()
        if not record:
            raise ValueError(f"O anúncio {record_id} não foi encontrado.")
        await table.filter(id=record_id).update(**update_data)
        return f"O anúncio {record_id} foi atualizado com sucesso!"
