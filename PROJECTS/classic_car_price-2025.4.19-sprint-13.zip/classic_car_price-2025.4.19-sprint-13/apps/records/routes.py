import asyncio
import logging
from uuid import UUID
from typing import Optional, List

from celery import chain
from fastapi import APIRouter, HTTPException, Query

from apps.calcs.tasks import calculate_averages
from apps.core.data_validate import ValidateData
from apps.core.db_manager import DatabaseManager
from apps.calcs.exceptions import InvalidCodeModel
from apps.core.exceptions import InvalidMachineError
from apps.calcs.db_manager import DatabaseManagerAverage
from apps.records.db_manager import DatabaseManagerRecord
from apps.core.schema import RecordsDataRequest, ReferenceDatesRequest
from apps.records.tasks import (
    fetch_records_task,
    duplicate_records_task,
    deactivate_records_task,
)


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()


@router.put("/update/{machine}", response_model=dict)
async def update_records(machine: str, request: RecordsDataRequest):
    """
    Atualiza registros para uma determinada máquina.

    Args:
        machine (str): O identificador da máquina.
        request (RecordsDataRequest): A requisição contendo os dados dos registros a serem atualizados.

    Returns:
        dict: Uma mensagem indicando o status da atualização.

    Raises:
        HTTPException: Se nenhum registro for atualizado ou se alguns registros falharem na atualização.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    database_manager = DatabaseManager(machine, loop)
    validator = ValidateData(machine)
    failed_updates = []
    successful_updates = 0

    database_manager_record = DatabaseManagerRecord(machine, loop)

    for record in request.records:
        existing_record = await database_manager.get_record(record.record_id)
        if not existing_record:
            failed_updates.append(
                {
                    "record_id": str(record.record_id),
                    "causes_of_disposal": "Registro não encontrado no banco de dados.",
                }
            )
            continue

        existing_record_dict = existing_record.__dict__

        combined_data = {**existing_record_dict, **record.data.dict()}

        normalized_data = validator.apply_normalize([combined_data])
        validated_data, invalidated_data = validator.apply_business_rules(
            normalized_data
        )

        if validated_data:
            try:
                await database_manager_record.update_record(
                    record.record_id, validated_data[0]
                )
                successful_updates += 1
            except ValueError:
                failed_updates.append(record.record_id)
        else:
            for invalid_data in invalidated_data:
                failed_updates.append(
                    {
                        "record_id": str(record.record_id),
                        "causes_of_disposal": invalid_data[1],
                    }
                )

    failed_updates = [str(record_id) for record_id in failed_updates]
    if failed_updates and successful_updates > 0:
        raise HTTPException(
            status_code=206,
            detail={
                "message": "Alguns registros não foram atualizados:",
                "failed_updates": failed_updates,
            },
        )

    if successful_updates == 0:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "Nenhum registro foi atualizado.",
                "failed_updates": failed_updates,
            },
        )

    return {"message": "Todos os registros foram atualizados com sucesso."}


@router.post("/list/task/{machine}", status_code=202)
async def fetch_records_and_list(
    machine: str,
    request: ReferenceDatesRequest,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    code_model: Optional[str] = None,
):
    """
    Busca registros e lista-os para uma determinada máquina.

    Args:
        machine (str): O identificador da máquina.
        request (ReferenceDatesRequest): A requisição contendo as datas de referência.
        page (int, opcional): O número da página para paginação. Padrão é 1.
        page_size (int, opcional): O número de registros por página. Padrão é 10.
        code_model (Optional[str], opcional): O filtro de modelo de código. Padrão é None.

    Returns:
        dict: O ID da tarefa para a tarefa de busca de registros.

    Raises:
        HTTPException: Se o modelo de código for inválido ou se ocorrer um erro.
    """
    reference_dates_dicts = request.reference_dates

    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        db_manager_average = DatabaseManagerAverage(machine, loop)

        if code_model:
            valid_code_models = await db_manager_average.get_valid_code_models()
            if code_model not in valid_code_models:
                raise InvalidCodeModel(code_model, machine)

        reference_dates = [date.dict() for date in reference_dates_dicts]

        task = fetch_records_task.delay(
            machine, page, page_size, reference_dates, code_model
        )
        return {"task_id": task.id}

    except InvalidCodeModel as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/duplicate/task/{machine}", response_model=dict)
async def duplicate_record(machine: str, request: RecordsDataRequest):
    """
    Duplica registros para uma determinada máquina.

    Args:
        machine (str): O identificador da máquina.
        request (RecordsDataRequest): A requisição contendo os dados dos registros a serem duplicados.

    Returns:
        dict: Uma mensagem indicando o status da duplicação e o ID da tarefa.

    Raises:
        HTTPException: Se a validação falhar ou se nenhum registro for encontrado para duplicação.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    database_manager = DatabaseManager(machine, loop)
    failed_duplicates = []
    valid_records = []

    for record in request.records:
        existing_record = await database_manager.get_record(record.record_id)
        if not existing_record:
            failed_duplicates.append(
                {
                    "record_id": str(record.record_id),
                    "causes_of_disposal": "Registro não encontrado no banco de dados.",
                }
            )
            continue

        valid_records.append(
            {
                "record_id": record.record_id,
                "existing_data": existing_record.__dict__,
                "new_data": record.data.dict(),
            }
        )

    if failed_duplicates:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "Falhas nas validações.",
                "failed_duplicates": failed_duplicates,
            },
        )

    task = chain(
        duplicate_records_task.s(machine, valid_records), calculate_averages.si(machine)
    ).apply_async()

    return {"task_id": task.id, "message": "A duplicação foi iniciada."}


@router.delete("/deactivate/task/{machine}", status_code=204)
async def deactivate_record(machine: str, record_ids: List[UUID]):
    """
    Desativa registros para uma determinada máquina.

    Args:
        machine (str): O identificador da máquina.
        record_ids (List[UUID]): A lista de IDs dos registros a serem desativados.

    Returns:
        dict: Uma mensagem indicando o status da desativação e o ID da tarefa.

    Raises:
        HTTPException: Se nenhum registro válido for encontrado para desativação ou se alguns IDs não forem encontrados.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    database_manager = DatabaseManager(machine, loop)
    valid_record_ids = []
    not_found_ids = []

    for record_id in record_ids:
        record = await database_manager.get_record(record_id)
        if not record:
            not_found_ids.append(str(record_id))
        else:
            valid_record_ids.append(record_id)

    if not valid_record_ids:
        raise HTTPException(
            status_code=404,
            detail="Nenhum registro válido encontrado para desativação.",
        )

    if not_found_ids:
        raise HTTPException(
            status_code=206,
            detail={
                "message": "Os seguintes IDs não foram encontrados em nossa base de dados:",
                "not_found_ids": not_found_ids,
            },
        )

    # Usando o chain para desativar os registros e calcular as médias
    task = chain(
        deactivate_records_task.s(
            machine, valid_record_ids
        ),  # Passa apenas os IDs válidos
        calculate_averages.si(machine),  # Após a desativação, calcula as médias
    ).apply_async()

    return {
        "message": "A tarefa de desativação e cálculo de médias foi iniciada.",
        "task_id": task.id,
    }
