import asyncio
from typing import Optional, Dict, List

from fastapi import Query, HTTPException

from apps.core.db_manager import DatabaseManager
from apps.calcs.exceptions import InvalidCodeModel
from apps.calcs.db_manager import DatabaseManagerAverage


async def fetch_records(
    machine: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    reference_dates: List[Dict[str, int]] = Query(...),
    code_model: Optional[str] = None,
):
    try:
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        # Inicializa os gerenciadores de banco de dados
        db_manager = DatabaseManager(machine, loop)
        db_manager_average = DatabaseManagerAverage(machine, loop)

        # Verifica se o código do modelo é válido
        valid_code_models = await db_manager_average.get_valid_code_models()

        if code_model and code_model not in valid_code_models:
            raise InvalidCodeModel(code_model, machine)

        # Cálculo de offset para paginação
        offset = (page - 1) * page_size

        # Passa a lista de reference_dates para o método get_records
        records = await db_manager.get_records(
            offset=offset,
            limit=page_size,
            reference_dates=reference_dates,  # Passando a lista de referência de ano e mês
            code_model=code_model,
        )

        return {"records": records}
    except InvalidCodeModel as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
