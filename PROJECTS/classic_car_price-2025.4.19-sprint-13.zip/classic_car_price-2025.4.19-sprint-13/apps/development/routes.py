from datetime import datetime

from fastapi import APIRouter

from apps.calcs.tasks import calculate_averages
from apps.core.exceptions import InvalidMachineError, InvalidSiteError
from apps.core.tasks import (
    assign_code_model_task,
    full_process_orchestration,
    process_crawler,
)


router = APIRouter()


@router.post("/run/all/process/{machine}/{site}", status_code=202)
async def run_all_process(
    machine: str,
    site: str,
):
    """
    Inicia o processo completo de automação do crawler para uma máquina e site específicos.

    O processo inclui as seguintes etapas:
    1. Execução do processo de automação, extração e persistência do crawler para os dados do site.
    2. Atribuição de códigos modelos para os dados obtidos da máquina.
    3. Cálculo das médias associadas aos códigos modelos atribuídos.
    4. Geração do relatório final.

    Parâmetros:
    - machine (str): Identificador da máquina.
    - site (str): Identificador do site de onde os dados serão extraídos.

    Returns:
    - dict: Um dicionário contendo o identificador da task criada.

    Raises:
    - InvalidMachineError: Se a máquina fornecida não for válida.
    - InvalidSiteError: Se o site fornecido não for válido.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(machine, site, valid_machines=list(valid_machines))

    valid_sites = InvalidSiteError.VALID_SITES
    if site not in valid_sites:
        raise InvalidSiteError(site)

    now = datetime.now()
    year_reference = now.year
    month_reference = now.month

    task = full_process_orchestration.delay(
        machine, site, year_reference, month_reference
    )

    return {"task_id": task.id}


@router.post("/run/crawler/{machine}/{site}", status_code=202)
async def run_crawler(
    machine: str,
    site: str,
):
    """
    Inicia o processo completo de automação do crawler.

    Este endpoint executa todas as etapas relacionadas ao processo de automação para a máquina e site especificados,
    incluindo:
    - Execução do crawler para coletar os dados do site.
    - Extração, sanitização e validação das informações relevantes.
    - Persistência dos dados extraídos no banco de dados.

    Parâmetros:
    - machine (str): Identificador da máquina.
    - site (str): Identificador do site de onde os dados serão extraídos.

    Returns:
    - dict: Um dicionário contendo o identificador da tarefa criada (`task_id`).

    Raises:
    - InvalidMachineError: Se a máquina fornecida não for válida.
    - InvalidSiteError: Se o site fornecido não for válido.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(machine, site, valid_machines=list(valid_machines))

    valid_sites = InvalidSiteError.VALID_SITES
    if site not in valid_sites:
        raise InvalidSiteError(site)

    task = process_crawler.delay(machine, site)

    return {"task_id": task.id}


@router.post("/assign/code_model/{machine}")
async def assign_code_model_route(machine: str):
    """
    Inicia a tarefa de atribuição de códigos modelos para uma máquina específica.

    Parâmetros:
    - machine (str): O identificador da máquina.

    Retorna:
    - dict: Um dicionário contendo o status da tarefa e o ID da tarefa criada.

    Lança:
    - InvalidMachineError: Se a máquina não for válida.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    task = assign_code_model_task.delay(machine)

    return {"status": "Task submitted", "task_id": task.id}


@router.post("/calculate/averages/{machine}")
async def calculate_averages_route(machine: str):
    """
    Inicia a tarefa de cálculo das médias para uma máquina específica.

    As médias são calculadas com base nos códigos modelos atribuídos.

    Parâmetros:
    - machine (str): O identificador da máquina.

    Retorna:
    - dict: Um dicionário contendo o status da tarefa e o ID da tarefa criada.

    Lança:
    - InvalidMachineError: Se a máquina não for válida.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    result = calculate_averages.delay(machine)
    return {"status": "Task received", "task_id": result.id}
