REPORT_INFO = {
    "general_objective": "Fornecer uma visão descritiva e estratégica do comportamento do mercado automotivo no mês e ano de referência, com base em dados reais de anúncios, preços e volume por marca, a fim de apoiar decisões de precificação e inteligência competitiva.",
    "specific_objectives": [
        "1 - Analisar a representatividade de marcas no mercado, evidenciando aquelas com maior presença no período observado;",
        "2 - Aferir como os preços estão distribuídos entre as marcas mais relevantes, destacando variações internas e o posicionamento de cada marca por faixa de preço;",
        "3 - Identificar padrões de preço e variabilidade no mercado, com foco em oportunidades e tendências relevantes para o setor automotivo;",
        "4 - Auxiliar na compreensão da dinâmica de mercado, destacando padrões e características que possam ser úteis na tomada de decisões táticas e estratégicas."
    ],
    "graphs": {
        "top_10_brands_ads_distribution": {
            "description": "Visualização das marcas que dominam o mercado no determinado período. Ofertando insights sobre a competitividade do mercado e a relevância de cada marca, essencial para ajustar estratégias comerciais e observar tendências de oferta.",
            "data_application": [
                "Identificar marcas dominantes e ajustar estratégias de marketing.",
                "Avaliar como as marcas líderes do setor se posicionam em relação umas às outras em termos de presença no mercado.",
                "Observar o alcance comercial das marcas no setor automotivo por meio de sua participação na oferta de veículos."
            ]
        },
        "price_distribution_boxplot": {
            "description": "Evidência a variação de preços de veículos de cada marca, destacando a mediana, os quartis e os preços extremos. Isso ajuda a entender a faixa de preços e a competitividade de cada marca, auxiliando nas decisões de precificação e identificação de oportunidades de investimento.",
            "data_application": [
                "Definir estratégias de precificação baseadas na distribuição dos preços.",
                "Observar segmentação do mercado conforme a variação de preços e as margens de lucro esperadas.",
                "Identificar oportunidades de compra com preços abaixo da mediana ou verificar saturação de preços elevados."
            ]
        }
    }
}
