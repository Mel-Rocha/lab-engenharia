from typing import List

from pydantic import BaseModel


class AnnualAverageSchema(BaseModel):
    reference_year: int
    code_model: str
    year_model: int
    annual_average: float

    model_config = {"from_attributes": True}


class MonthlyAverageSchema(BaseModel):
    reference_year: int
    reference_month: int
    code_model: str
    year_model: int
    average_price: float
    ad_count: int
    is_active: bool

    model_config = {"from_attributes": True}


class PaginatedAnnualAveragesResponse(BaseModel):
    message: str
    page: int
    size: int
    pages: int
    total: int
    items: List[AnnualAverageSchema]

    model_config = {"from_attributes": True}
