import logging
from collections import defaultdict
from decimal import Decimal
from typing import List, Optional
from statistics import stdev, mean

import numpy as np
from tortoise.transactions import in_transaction

from apps.calcs.format import format_price
from apps.core.models import MachineTable
from apps.calcs.models import MachineTableAverage, MachineTableAverageAdLink


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManagerAverage:

    def __init__(self, machine, loop):
        self.machine = machine
        self.machine_tables = {
            "machine": MachineTable,
        }

        self.average_tables = {
            "machine": MachineTableAverage,
        }

        self.link_tables = {
            "machine": MachineTableAverageAdLink,
        }
        self.loop = loop

    def get_machine_average(self):
        return self.loop.run_until_complete(self.get_machine_average_async())

    def get_annual_average(self):
        return self.loop.run_until_complete(self.get_annual_average_async())

    async def has_required_data_for_calcs_averages(self):
        """
        Grouping the dataset to calculate averages uses the 4 pieces of information:

        code_model
        year_model
        month_reference
        year_reference.

        This method aims to validate whether the given advertisement table has at least one record capable
        of performing the average calculation functionality.
        """
        table = self.machine_tables.get(self.machine, None)

        if table is None:
            raise ValueError(
                f"A tabela correspondente para a máquina '{self.machine}' não foi encontrada."
            )

        query = f"""
            SELECT EXISTS (
                SELECT 1
                FROM {table._meta.db_table}
                WHERE code_model IS NOT NULL
                AND year_model IS NOT NULL
                AND year_reference IS NOT NULL
                AND month_reference IS NOT NULL
                LIMIT 1
            ) AS has_data;
        """
        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query)
        return result[0]["has_data"]

    async def get_machine_average_async(self):
        table = self.machine_tables.get(self.machine, None)
        average_table = self.average_tables.get(self.machine, None)
        link_table = self.link_tables.get(self.machine, None)

        if not await self.has_required_data_for_calcs_averages():
            return (
                f"Nenhum registro da tabela de anúncios para a máquina '{self.machine}' possui código modelo "
                f"e ano modelo, portanto não será possível calcular as médias.")

        if table is not None and average_table is not None and link_table is not None:
            query = f"""
                SELECT
                    year_reference AS reference_year,
                    month_reference AS reference_month,
                    code_model,
                    year_model,
                    ARRAY_AGG(ROW(price, id)) AS records_list,
                    AVG(price) AS average_price,
                    COUNT(*) AS ad_count
                FROM
                    {table._meta.db_table}
                WHERE
                    code_model IS NOT NULL
                    AND year_model IS NOT NULL
                    AND year_reference IS NOT NULL
                    AND month_reference IS NOT NULL
                GROUP BY
                    year_reference,
                    month_reference,
                    code_model,
                    year_model
                ORDER BY
                    year_reference,
                    month_reference,
                    code_model,
                    year_model;
            """

            async with in_transaction() as connection:
                result = await connection.execute_query_dict(query)

            for row in result:
                await average_table.filter(
                    reference_year=row["reference_year"],
                    reference_month=row["reference_month"],
                    code_model=row["code_model"],
                    year_model=row["year_model"],
                    is_active=True,
                ).update(is_active=False)

                new_average = await average_table.create(
                    reference_year=row["reference_year"],
                    reference_month=row["reference_month"],
                    code_model=row["code_model"],
                    year_model=row["year_model"],
                    average=row["average_price"],
                    ad_count=row["ad_count"],
                    is_active=True,
                )

                for ad in row["records_list"]:
                    """
                    If the ad ID already exists in the associative table, we deactivate the existing record,
                    as this way we maintain consistency between active media records and media and ad associations.
                    """
                    ad_price, ad_id = ad
                    await link_table.filter(core_table=ad_id, is_active=True).update(
                        is_active=False
                    )
                    await link_table.create(
                        core_table_id=ad_id, core_table_average_id=new_average.id
                    )
            return {
                "monthly_averages": result,
            }
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def get_annual_average_async(self):
        average_table = self.average_tables.get(self.machine, None)
        if average_table is not None:
            query = f"""
                SELECT
                    reference_year,
                    code_model,
                    year_model,
                    ROUND(AVG(average), 2) AS annual_average
                FROM
                    {average_table._meta.db_table}
                WHERE
                    is_active = TRUE
                    AND code_model IS NOT NULL
                    AND year_model IS NOT NULL
                    AND reference_year IS NOT NULL
                    AND reference_month IS NOT NULL
                GROUP BY
                    reference_year,
                    code_model,
                    year_model
                ORDER BY
                    reference_year,
                    code_model,
                    year_model;
                """

            async with in_transaction() as connection:
                result = await connection.execute_query_dict(query)

            return result
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def get_filtered_averages_async(
        self, code_model, year_model=None, is_active=None, year_reference=None, month_reference=None
    ):
        # Recupera a tabela associada à máquina
        average_table = self.average_tables.get(self.machine, None)
        if not average_table:
            raise ValueError(
                f"Não há tabelas correspondentes para a máquina: {self.machine}"
            )

        # Construção dinâmica da query SQL
        query = f"""
                    SELECT
                        reference_year,
                        reference_month,
                        code_model,
                        year_model,
                        ROUND(AVG(average), 2) AS average_price,
                        COUNT(*) AS ad_count,
                        is_active
                    FROM
                        {average_table._meta.db_table}
                    WHERE
                        code_model = $1
                """

        # Lista de parâmetros
        params = [code_model]

        # Adiciona condições opcionais
        if year_model is not None:
            query += f" AND year_model = ${len(params) + 1}"
            params.append(year_model)

        if is_active is not None:
            query += f" AND is_active = ${len(params) + 1}"
            params.append(is_active)

        if year_reference is not None:
            query += f" AND reference_year = ${len(params) + 1}"
            params.append(year_reference)

        if month_reference is not None:
            query += f" AND reference_month = ${len(params) + 1}"
            params.append(month_reference)

        # Adiciona agrupamento e ordenação
        query += """
                    GROUP BY
                        reference_year,
                        reference_month,
                        code_model,
                        year_model,
                        is_active
                    ORDER BY
                        reference_year,
                        reference_month;
                """

        # Executa a query
        try:
            async with in_transaction() as connection:
                return await connection.execute_query_dict(query, params)
        except Exception as e:
            raise RuntimeError(
                f"Erro ao executar a consulta no banco de dados: {str(e)}"
            )

    async def get_valid_code_models(self):
        average_table = self.average_tables.get(self.machine, None)

        if average_table is not None:
            query = f"""
                SELECT DISTINCT code_model
                FROM {average_table._meta.db_table}
                WHERE is_active = TRUE;
            """

            logger.info(f"Executing query: {query}")
            async with in_transaction() as connection:
                result = await connection.execute_query_dict(query)

            return [row["code_model"] for row in result]

    async def get_valid_year_models_by_code_model_and_reference_date(
        self,
        code_model: str,
        reference_year_start: int,
        reference_year_end: int,
        reference_month_start: int,
        reference_month_end: int,
    ) -> List[int]:
        """
        Obtains all model years (year_model) of a given model code (code_model), within a reference month and year range
        (reference_year, reference_month)
        """
        average_table = self.average_tables.get(self.machine, None)

        if average_table is None:
            raise ValueError(
                f"Não existem tabelas correspondentes para esta máquina: {self.machine}"
            )

        query = f"""
            SELECT DISTINCT year_model
            FROM {self.average_tables[self.machine]._meta.db_table}
            WHERE is_active = TRUE
            AND code_model = $1
            AND (reference_year, reference_month) IN (
                SELECT reference_year, reference_month
                FROM {self.average_tables[self.machine]._meta.db_table}
                WHERE reference_year BETWEEN $2 AND $3
                AND reference_month BETWEEN $4 AND $5
            );
        """

        params = [
            code_model,
            reference_year_start,
            reference_year_end,
            reference_month_start,
            reference_month_end,
        ]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        existing_year_models = [record["year_model"] for record in result]

        logger.info(f"Valid year_models found: {existing_year_models}")

        return existing_year_models

    async def get_ads_per_code_model(
        self, code_model: Optional[str] = None, filter_max: Optional[bool] = None
    ):
        table = self.average_tables.get(self.machine, None)

        if table is not None:
            # Consulta básica para contar anúncios por modelo
            query = f"""
                        SELECT
                            code_model,
                            COUNT(*) AS ad_count
                        FROM
                            {self.average_tables[self.machine]._meta.db_table}
                        WHERE
                            is_active = TRUE
                    """

            # Filtra por code_model se fornecido
            if code_model:
                query += " AND code_model = $1"
                params = [code_model]
            else:
                params = []

            # Agrupa por code_model
            query += """
                        GROUP BY
                            code_model
                    """

            # Ordena e aplica o filtro para o modelo com mais ou menos anúncios
            if filter_max is not None:
                if filter_max:
                    query += " ORDER BY ad_count DESC"  # Mais anúncios
                else:
                    query += " ORDER BY ad_count ASC"  # Menos anúncios
                query += " LIMIT 1"  # Limita o resultado a 1 modelo

            try:
                async with in_transaction() as connection:
                    result = await connection.execute_query_dict(query, params)

                return result
            except Exception as e:
                raise RuntimeError(
                    f"Erro ao executar a consulta no banco de dados: {str(e)}"
                )
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def get_code_models_with_year_models_by_reference_date(
        self, year_reference: int, month_reference: int
    ):
        average_table = self.average_tables.get(self.machine, None)

        if average_table is None:
            raise ValueError(
                f"Não existem tabelas correspondentes para esta máquina: {self.machine}"
            )

        query = f"""
            SELECT code_model, year_model, ROUND(AVG(average), 2) AS average_price, COUNT(*) AS ad_count, is_active
            FROM {average_table._meta.db_table}
            WHERE reference_year = $1 AND reference_month = $2
            GROUP BY code_model, year_model, is_active
            ORDER BY code_model, year_model;
        """

        params = [year_reference, month_reference]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        code_models_dict = {}
        for row in result:
            code_model = row["code_model"]
            year_model_data = {
                "year_model": row["year_model"],
                "average_price": row["average_price"],
                "ad_count": row["ad_count"],
            }
            if code_model not in code_models_dict:
                code_models_dict[code_model] = []
            code_models_dict[code_model].append(year_model_data)

        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "code_models": code_models_dict,
        }

    async def describe_market_by_reference_date(
            self, year_reference: int, month_reference: int
    ):
        table = self.machine_tables.get(self.machine, None)

        if table is None:
            raise ValueError(f"Não existem tabelas correspondentes para esta máquina: {self.machine}")

        query = f"""
            SELECT core.brand, core.price
            FROM {table._meta.db_table} AS core
            WHERE core.year_reference = $1
                  AND core.month_reference = $2
                  AND is_active = TRUE;
        """

        params = [year_reference, month_reference]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        if not result:
            return {"message": f"Nenhum dado disponível para o ano {year_reference} e mês {month_reference}."}

        # Organizando os dados por marca
        brand_prices = {}
        for row in result:
            brand = row["brand"]
            price = row["price"]
            if price is not None:
                if brand not in brand_prices:
                    brand_prices[brand] = []
                brand_prices[brand].append(price)

        # Função para calcular as estatísticas descritivas
        def calculate_statistics(values):
            if not values:
                return None
            float_values = [float(value) for value in values]
            return {
                "count": len(float_values),
                "mean": round(np.mean(float_values), 2),
                "std": round(np.std(float_values), 2),
                "min": round(np.min(float_values), 2),
                "25%": round(np.percentile(float_values, 25), 2),
                "50%": round(np.percentile(float_values, 50), 2),
                "75%": round(np.percentile(float_values, 75), 2),
                "max": round(np.max(float_values), 2),
            }

        # Calcular estatísticas gerais de preço para todas as marcas
        market_price_stats = calculate_statistics([price for prices in brand_prices.values() for price in prices])

        # Preparando o response com as estatísticas de cada marca
        describe_by_brand = {}
        for brand, prices in brand_prices.items():
            brand_stats = calculate_statistics(prices)
            describe_by_brand[brand] = brand_stats

        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "describe": {
                "market": market_price_stats,  # Estatísticas gerais do mercado
                "brands": describe_by_brand,  # Estatísticas por marca
            },
        }

    async def market_insights_by_reference_date(self, year_reference: int, month_reference: int):
        table = self.machine_tables.get(self.machine, None)

        if table is None:
            raise ValueError(f"Não existem tabelas correspondentes para esta máquina: {self.machine}")

        query = f"""
            SELECT core.brand, core.price, core.mileage
            FROM {table._meta.db_table} AS core
            WHERE core.year_reference = $1
                  AND core.month_reference = $2
                  AND is_active = TRUE;
        """

        params = [year_reference, month_reference]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        if not result:
            return {"year_reference": year_reference, "month_reference": month_reference,
                    "insights": ["Nenhum dado disponível para o ano {year_reference} e mês {month_reference}."]}

        # Organizando os dados por marca
        brand_prices = {}
        brand_mileage = {}

        for row in result:
            brand = row["brand"]
            price = row["price"]
            mileage = row["mileage"]

            if price is not None:
                if brand not in brand_prices:
                    brand_prices[brand] = []
                brand_prices[brand].append(price)

            if mileage is not None:
                if brand not in brand_mileage:
                    brand_mileage[brand] = []
                brand_mileage[brand].append(float(mileage))

        # Função para calcular as estatísticas descritivas
        def calculate_statistics(values):
            if not values:
                return None
            float_values = [float(value) for value in values]
            return {
                "mean": round(np.mean(float_values), 2),
                "std": round(np.std(float_values), 2),
                "min": round(np.min(float_values), 2),
                "max": round(np.max(float_values), 2),
            }

        insights = []

        # Insight de preço mais baixo
        lowest_price_brand = min(brand_prices, key=lambda brand: np.min(brand_prices[brand]))
        insights.append(
            f"A marca {lowest_price_brand} apresenta o preço médio mais baixo, o que pode indicar uma boa oportunidade de investimento, especialmente em tempos de busca por preços mais acessíveis.")

        # Insight de preço mais alto
        highest_price_brand = max(brand_prices, key=lambda brand: np.max(brand_prices[brand]))
        insights.append(
            f"A marca {highest_price_brand} tem os preços mais altos, o que pode indicar uma percepção de valor superior ou um segmento premium de mercado.")

        # Insight de maior variabilidade de preço
        highest_price_std_brand = max(brand_prices.items(), key=lambda x: np.std(x[1]))
        insights.append(
            f"A marca {highest_price_std_brand[0]} tem uma alta variabilidade nos preços, o que pode indicar uma grande diversidade de modelos ou uma oferta de preços mais dinâmica.")

        # Insight de total de anúncios
        total_ads = sum([len(prices) for prices in brand_prices.values()])
        insights.append(
            f"Um total de {total_ads} anúncios foram encontrados no mercado, mostrando que o interesse pelo mercado continua crescente.")

        # Insight de marcas com maior e menor número de anúncios
        max_ads_brand = max(brand_prices.items(), key=lambda x: len(x[1]))
        min_ads_brand = min(brand_prices.items(), key=lambda x: len(x[1]))

        insights.append(
            f"A marca {max_ads_brand[0]} tem o maior número de anúncios, o que pode indicar uma forte presença e competitividade no mercado.")
        insights.append(
            f"A marca {min_ads_brand[0]} tem o menor número de anúncios, o que pode sugerir uma marca menos ativa ou com um público mais restrito.")

        # Insight sobre a média de preços do mercado
        market_price_stats = calculate_statistics([price for prices in brand_prices.values() for price in prices])
        insights.append(
            f"O preço médio no mercado é de {format_price(market_price_stats['mean'])}. O que pode indicar uma tendência de preços estáveis ou um mercado saturado.")

        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "insights": insights,
        }

    async def describe_price_stats_models_by_brand(
            self, brand, year_reference, month_reference):
        """
        Objetivo: Esta funcionalidade fornece uma análise detalhada de preços para todos os anúncios ativos
        de uma determinada marca, considerando um mês e ano de referência específicos. Além disso,
        calcula estatísticas descritivas para cada modelo dessa marca, incluindo medidas como
        contagem, média, desvio padrão, valores mínimo, máximo e percentis. A mesma foi baseada no describe
        do pandas que retonra estatísticas descritivas para um DataFrame.
        """

        ads = await self.machine_tables[self.machine].filter(
            brand=brand,
            is_active=True,
            year_reference=year_reference,
            month_reference=month_reference
        ).values('model', 'code_model', 'price')

        # Agora vamos agrupar os dados por modelo e calcular as médias e contagens
        model_data = {}
        all_prices = []

        for ad in ads:
            model = ad['model']
            price = ad['price']

            # Adicionando o preço ao total geral
            all_prices.append(price)

            # Criando uma entrada para cada modelo
            if model not in model_data:
                model_data[model] = {
                    'prices': [],
                }

            model_data[model]['prices'].append(price)

        # Função para calcular estatísticas detalhadas
        def calculate_statistics(values):
            if not values:
                return None

            # Convertendo valores para float
            float_values = [float(value) for value in values]

            return {
                "count": len(float_values),
                "mean": round(np.mean(float_values), 2),
                "std": round(np.std(float_values), 2),
                "min": round(np.min(float_values), 2),
                "25%": round(np.percentile(float_values, 25), 2),
                "50%": round(np.percentile(float_values, 50), 2),
                "75%": round(np.percentile(float_values, 75), 2),
                "max": round(np.max(float_values), 2),
            }

        # Estatísticas gerais para a marca
        brand_price_stats = calculate_statistics(all_prices)

        result = []

        # Estatísticas detalhadas por modelo
        for model, data in model_data.items():
            price_stats = calculate_statistics(data['prices'])

            result.append({
                'model': model,
                'model_stats_price': price_stats,
            })

        # Formatar a resposta com os detalhes de year_reference, month_reference e brand
        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "brand": brand,
            "describe": {
                "brand_stats_price": brand_price_stats,  # Estatísticas gerais da marca
                "models": result  # Estatísticas detalhadas por modelo
            }
        }

    async def get_top_10_brands_prices(self, year_reference: int, month_reference: int):
        """
        Recupera as 10 marcas com mais anúncios e retorna os preços de todos os anúncios dessas marcas
        para um ano e mês específicos.
        """
        table = self.machine_tables.get(self.machine, None)

        if table is None:
            raise ValueError(f"Não existem tabelas correspondentes para esta máquina: {self.machine}")

        # Query para contar as 10 marcas com mais anúncios e pegar os preços
        query = f"""
            WITH top_brands AS (
                SELECT core.brand, COUNT(core.id) AS brand_count
                FROM {table._meta.db_table} AS core
                WHERE core.year_reference = $1
                      AND core.month_reference = $2
                GROUP BY core.brand
                ORDER BY brand_count DESC
                LIMIT 10
            )
            SELECT core.brand, core.price
            FROM {table._meta.db_table} AS core
            INNER JOIN top_brands AS tb ON core.brand = tb.brand
            WHERE core.year_reference = $1
                  AND core.month_reference = $2;
        """

        params = [year_reference, month_reference]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        if not result:
            return {
                "year_reference": year_reference,
                "month_reference": month_reference,
                "insights": ["Nenhum dado disponível para o ano {year_reference} e mês {month_reference}."]
            }

        # Organizando os resultados por marca
        brand_prices = {}
        for row in result:
            brand = row['brand']
            price = row['price']
            if brand not in brand_prices:
                brand_prices[brand] = []
            brand_prices[brand].append(price)

        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "brand_prices": brand_prices
        }

    async def generate_conclusion_by_reference_date(self, year_reference: int, month_reference: int):
        table = self.machine_tables.get(self.machine, None)

        if table is None:
            raise ValueError(f"Não existem tabelas correspondentes para esta máquina: {self.machine}")

        query = f"""
                WITH top_brands AS (
                    SELECT core.brand, COUNT(core.id) AS brand_count
                    FROM {table._meta.db_table} AS core
                    WHERE core.year_reference = $1
                          AND core.month_reference = $2
                          AND is_active = TRUE
                    GROUP BY core.brand
                    ORDER BY brand_count DESC
                    LIMIT 10
                )
                SELECT core.brand, core.price
                FROM {table._meta.db_table} AS core
                INNER JOIN top_brands AS tb ON core.brand = tb.brand
                WHERE core.year_reference = $1
                      AND core.month_reference = $2
                      AND is_active = TRUE;
            """

        params = [year_reference, month_reference]

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query, params)

        if not result:
            return {
                "year_reference": year_reference,
                "month_reference": month_reference,
                "conclusion": "Nenhum dado disponível para o período analisado."
            }

        brand_prices = {}

        for row in result:
            brand = row["brand"]
            price = row["price"]

            if price is not None:
                brand_prices.setdefault(brand, []).append(float(price))

        total_ads = sum(len(prices) for prices in brand_prices.values())

        # Marcas com maior representatividade
        sorted_by_volume = sorted(brand_prices.items(), key=lambda x: len(x[1]), reverse=True)
        most_relevant_brands = [b for b, _ in sorted_by_volume[:3]]

        # Estatísticas de dispersão e variação
        dispersions = {
            brand: np.percentile(prices, 75) - np.percentile(prices, 25)
            for brand, prices in brand_prices.items()
            if len(prices) >= 2
        }

        variations = {
            brand: max(prices) - min(prices)
            for brand, prices in brand_prices.items()
            if len(prices) >= 2
        }

        brand_with_highest_dispersion = max(dispersions.items(), key=lambda x: x[1], default=(None, None))[0]
        brand_with_highest_variation = max(variations.items(), key=lambda x: x[1], default=(None, None))[0]
        brand_with_lowest_variation = min(variations.items(), key=lambda x: x[1], default=(None, None))[0]

        # Tendência geral de preços
        all_prices = [price for prices in brand_prices.values() for price in prices]
        avg_price = round(np.mean(all_prices), 2)
        std_price = round(np.std(all_prices), 2)

        # Construção do texto da conclusão
        conclusion_parts = []

        if most_relevant_brands:
            brands_text = ", ".join(most_relevant_brands[:-1]) + f" e {most_relevant_brands[-1]}" if len(
                most_relevant_brands) > 1 else most_relevant_brands[0]
            conclusion_parts.append(
                f"No período analisado, destacaram-se pela sua representatividade no mercado as marcas {brands_text}, evidenciando uma forte presença e um volume significativo de anúncios."
            )

        if brand_with_highest_dispersion:
            conclusion_parts.append(
                f"A marca {brand_with_highest_dispersion} por sua vez, apresentou a maior dispersão de preços, refletindo uma ampla distribuição dos valores praticados."
            )

        if brand_with_highest_variation:
            conclusion_parts.append(
                f"Além disso, a marca {brand_with_highest_variation}, teve a maior variação de preços, sugerindo uma grande diversidade de modelos ou perfis de oferta."
            )

        if brand_with_lowest_variation:
            conclusion_parts.append(
                f"Em contrapartida, a marca {brand_with_lowest_variation} manteve uma faixa de valores estável, demonstrando menor variação no período"
            )

        conclusion_parts.append(
            f"A média geral de preços foi de {format_price(avg_price)}, com uma dispersão padrão de {format_price(std_price)}, oferecendo um panorama consistente do mercado no período."
        )

        conclusion_parts.append(
            f"No presente relatório, um total de {total_ads} anúncios foram analisados, reforçando a base robusta de dados utilizada nesta avaliação."
        )

        return {
            "year_reference": year_reference,
            "month_reference": month_reference,
            "conclusion": " ".join(conclusion_parts)
        }


