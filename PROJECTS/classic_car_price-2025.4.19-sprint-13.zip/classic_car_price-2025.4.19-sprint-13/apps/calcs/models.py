from tortoise import fields

from apps.core.models import Core


"""
Objective: Persist the MM, (market averages) for a given code_model and a given year_model.
"""


class CoreTableAverage(Core):
    code_model = fields.CharField(max_length=50)
    year_model = fields.IntField()
    average = fields.DecimalField(max_digits=18, decimal_places=2)
    reference_year = fields.IntField()
    reference_month = fields.IntField()
    ad_count = fields.IntField()

    class Meta:
        abstract = True


class MachineTableAverage(CoreTableAverage):
    pass


"""
Objective: Associate all ads used to calculate each record in tables that inherit from CoreTableAverage
"""


class MachineTableAverageAdLink(Core):
    core_table_average = fields.ForeignKeyField(
        "models.MachineTableAverage", related_name="ads_used"
    )
    core_table = fields.ForeignKeyField(
        "models.MachineTable", related_name="average_calculations"
    )

    class Meta:
        table = "machine_table_average_ad_link"
