import asyncio
import traceback
from typing import Optional

from fastapi.params import Query
from fastapi_pagination import add_pagination
from fastapi.responses import StreamingResponse
from fastapi import APIRouter, HTTPException, Path

from apps.calcs.tasks import generate_report_task
from apps.calcs.graph_generator import GraphGenerator
from apps.calcs.db_manager import DatabaseManagerAverage
from apps.calcs.schemas import PaginatedAnnualAveragesResponse
from apps.calcs.exceptions import InvalidMachineAverage, InvalidCodeModel
from apps.calcs.utils import get_annual_averages, get_filtered_averages, clean_string


router = APIRouter()


@router.get("/average/annual/{machine}", response_model=PaginatedAnnualAveragesResponse)
async def get_machine_average(
    machine: str, page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=50)
):
    """
    Obtém as médias anuais paginadas de preços de uma máquina específica.

    Args:
        machine (str): O identificador da máquina.
        page (int, opcional): O número da página para paginação. Padrão é 1.
        size (int, opcional): A quantidade de itens por página. Padrão é 10.

    Returns:
        PaginatedAnnualAveragesResponse: As médias anuais paginadas de preços da máquina.

    Raises:
        InvalidMachineAverage: Se a máquina não for válida.
    """
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise InvalidMachineAverage(machine)
    return await get_annual_averages(machine, page, size)


add_pagination(router)


@router.get("/average/month/{machine}", response_model=PaginatedAnnualAveragesResponse)
async def get_filtered_machine_average(
    machine: str,
    code_model: str,
    year_model: Optional[int] = Query(None, description="Ano do modelo"),

    year_reference: Optional[int] = Query(
        None, description="Ano de referência do anúncio"
    ),
    month_reference: Optional[int] = Query(
        None, description="Mês de referência do anúncio"
    ),
    is_active: Optional[bool] = Query(None, description="Filtrar por anúncios ativos"),
    page: int = Query(1, ge=1, description="Número da página (mínimo 1)"),
    size: int = Query(
        10, ge=1, le=100, description="Quantidade de itens por página (entre 1 e 100)"
    ),
):
    """
    Endpoint para obter médias mensais de preços de máquinas filtradas por código do modelo,
    ano/mês de referência e status de atividade.

    - **machine**: Tipo da máquina (ex.: 'carro', 'moto').
    - **code_model**: Código do modelo da máquina.
    - **year_model**: Ano do modelo da máquina (opcional).
    - **year_reference**: Ano de referência do anúncio (opcional).
    - **month_reference**: Mês de referência do anúncio (opcional).
    - **is_active**: Status ativo/inativo dos anúncios (opcional).
    - **page**: Número da página para paginação (padrão: 1).
    - **size**: Quantidade de itens por página (padrão: 10).
    """
    # Validar se a máquina é válida
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    # Limpar o código do modelo
    code_model = clean_string(code_model)

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        db_manager_average = DatabaseManagerAverage(machine, loop)

        if code_model:
            valid_code_models = await db_manager_average.get_valid_code_models()
            if code_model not in valid_code_models:
                raise InvalidCodeModel(code_model, machine)
    except InvalidCodeModel as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Obter médias filtradas
    return await get_filtered_averages(
        machine=machine,
        code_model=code_model,
        year_model=year_model,
        year_reference=year_reference,
        month_reference=month_reference,
        is_active=is_active,
        page=page,
        size=size,
    )


add_pagination(router)


@router.get("/ads/per/code_model/{machine}")
async def get_ads_per_code_model(
    machine: str = Path(..., description="Nome da máquina"),
    code_model: Optional[str] = None,  # Parâmetro opcional para 'code_model'
    filter_max: Optional[
        bool
    ] = None,  # Filtro booleano para retornar o modelo com mais ou menos anúncios
):
    """
    Retorna a quantidade de anúncios por code_model ativo para uma máquina específica.

    Parâmetros:
    - machine: Nome da máquina.
    - code_model (opcional): Código do modelo de veículo.
    - filter_max (opcional): Se True, retorna o modelo com mais anúncios; se False, o modelo com menos anúncios.
    """
    try:
        # Valida a máquina
        if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
            raise HTTPException(
                status_code=400,
                detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
            )

        # Criar ou obter o loop de eventos
        loop = (
            asyncio.get_event_loop()
            if asyncio.get_event_loop() is not None
            else asyncio.new_event_loop()
        )
        asyncio.set_event_loop(loop)

        # Inicializar o gerenciador de banco de dados
        db_manager_average = DatabaseManagerAverage(machine, loop)

        # Verificar se a tabela de médias possui dados usando `get_valid_code_models`
        valid_code_models = await db_manager_average.get_valid_code_models()
        if not valid_code_models:
            raise HTTPException(
                status_code=400,
                detail="A tabela de médias está vazia. Não é possível executar esta rota no momento.",
            )

        # Limpar o código do modelo
        if code_model:
            code_model = clean_string(code_model)

            # Verificar se o código do modelo é válido
            if code_model not in valid_code_models:
                raise InvalidCodeModel(code_model, machine)

        # Obter a quantidade de anúncios por código de modelo
        result = await db_manager_average.get_ads_per_code_model(code_model, filter_max)
        if not result:
            raise HTTPException(
                status_code=400,
                detail="Nenhum modelo encontrado ou sem anúncios ativos.",
            )

        return result

    except InvalidCodeModel as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException as e:
        raise e  # Não encapsular exceções já do tipo HTTPException
    except Exception as e:
        # Captura apenas erros inesperados e retorna 500
        raise HTTPException(
            status_code=500, detail=f"Erro interno no servidor: {str(e)}"
        )


@router.get("/all/code_models/{machine}/{year_reference}/{month_reference}")
async def get_code_models_with_year_models_by_reference_date(
    machine: str, year_reference: int, month_reference: int
):
    """
    Retorna um dicionário onde as chaves são os code_models e os valores são listas de year_models correspondentes
    para um determinado mês e ano de referência.

    Parâmetros:
    - machine: Tipo da máquina (ex.: 'machine').
    - year_reference: Ano de referência do anúncio.
    - month_reference: Mês de referência do anúncio.
    """
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    db_manager_average = DatabaseManagerAverage(machine, loop)

    result = (
        await db_manager_average.get_code_models_with_year_models_by_reference_date(
            year_reference, month_reference
        )
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Nenhum modelo encontrado para a data de referência fornecida.",
        )

    return result


@router.get("/analyze/describe/market/{machine}/{year_reference}/{month_reference}")
async def describe_market(
        machine: str,
        year_reference: int,
        month_reference: int):
    """
    Objetivo:
    - Descrever estatísticamente o mercado e as marcas.

    Parâmetros Obrigatórios:
    - machine (str);
    - year_reference (int);
    - month_reference (int).

    Retorno:
    - Json
    """
    # Verificando se a máquina fornecida é válida
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    try:
        # Inicializando o loop de eventos
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        db_manager_average = DatabaseManagerAverage(machine, loop)

        # Chamando o método de análise e retornando a resposta
        response = await db_manager_average.describe_market_by_reference_date(
            year_reference, month_reference
        )
        return response

    except Exception as e:
        # Capturando o traceback e formatando o erro
        error_message = f"Erro detectado: {type(e).__name__} - {e}"
        traceback_str = traceback.format_exc()
        return {"error": error_message, "traceback": traceback_str}


@router.get("/analyze/insights/market/{machine}/{year_reference}/{month_reference}")
async def insights_market(
        machine: str,
        year_reference: int,
        month_reference: int):
    """
    Objetivo:
    - Gerar insights do mercado.

    Parâmetros Obrigatórios:
    - machine (str);
    - year_reference (int);
    - month_reference (int).

    Retorno:
    - Json
    """
    # Verificando se a máquina fornecida é válida
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    try:
        # Inicializando o loop de eventos
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        db_manager_average = DatabaseManagerAverage(machine, loop)

        # Chamando o método de análise e retornando a resposta
        response = await db_manager_average.market_insights_by_reference_date(
            year_reference, month_reference
        )
        return response

    except Exception as e:
        # Capturando o traceback e formatando o erro
        error_message = f"Erro detectado: {type(e).__name__} - {e}"
        traceback_str = traceback.format_exc()
        return {"error": error_message, "traceback": traceback_str}



@router.get("/report/insights/task/{machine}/{year_reference}/{month_reference}")
async def get_report_and_insights_task(
    machine: str, year_reference: int, month_reference: int
):
    """
    Inicia uma tarefa para gerar um relatório e insights para uma máquina específica em um determinado mês e ano
    de referência.

    Args:
        machine (str): O identificador da máquina.
        year_reference (int): O ano de referência dos anúncios.
        month_reference (int): O mês de referência dos anúncios.

    Returns:
        dict: Um dicionário contendo o ID da tarefa.

    Raises:
        HTTPException: Se a máquina não for válida.
    """
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    task = generate_report_task.apply_async(
        args=[machine, year_reference, month_reference]
    )
    return {"task_id": task.id}


@router.get(
    "/analyze/describe-price-stats/{machine}/{brand}/{year_reference}/{month_reference}")
async def describe_models_by_brand(
        machine: str,
        brand: str,
        year_reference: int,
        month_reference: int):
    """
    Objetivo:
    - Calcula estatísticas descritivas de preço para uma marca e seus modelos.

    Parâmetros Obrigatórios:
    - machine (str);
    - brand (str);
    - year_reference (int);
    - month_reference (int).

    Retorno:
    - Json
    """
    if machine not in InvalidMachineAverage.VALID_MACHINES_AVERAGE:
        raise HTTPException(
            status_code=400,
            detail=f"Máquina '{machine}' não é válida. Escolha entre: {InvalidMachineAverage.VALID_MACHINES_AVERAGE}",
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    db_manager_average = DatabaseManagerAverage(machine, loop)

    try:
        response = await db_manager_average.describe_price_stats_models_by_brand(brand, year_reference, month_reference)
        return response

    except Exception as e:
        error_message = f"Erro detectado: {type(e).__name__} - {e}"
        traceback_str = traceback.format_exc()
        return {"error": error_message, "traceback": traceback_str}
