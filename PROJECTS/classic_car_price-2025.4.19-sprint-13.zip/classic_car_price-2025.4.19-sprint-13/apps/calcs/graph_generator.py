import io

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


class GraphGenerator:
    def __init__(self, data_manager):
        self.data_manager = data_manager

    async def plot_top_brands_ads_distribution(self, year_reference: int, month_reference: int, top_n: int = 10):
        # Pegando as top marcas baseado na contagem real de anúncios com preços (dados já filtrados)
        data = await self.data_manager.get_top_10_brands_prices(year_reference, month_reference)
        brand_prices = data["brand_prices"]

        # Ordenar marcas por quantidade de anúncios (tamanho da lista de preços)
        sorted_brands = sorted(brand_prices.items(), key=lambda x: len(x[1]), reverse=True)[:top_n]

        labels = [brand for brand, _ in sorted_brands]
        values = [len(prices) for _, prices in sorted_brands]

        # Criar gráfico de barras
        plt.figure(figsize=(12, 8))
        plt.bar(labels, values, color="#ef44a1")
        plt.xlabel("Marcas", fontsize=16)
        plt.ylabel("Anúncios (unidades)", fontsize=16)
        plt.title(f"Marcas mais anúnciadas - Ano/Mês: {year_reference}/{month_reference}", fontsize=22)
        plt.xticks(rotation=45, ha="right", fontsize=16)
        plt.yticks(fontsize=16)
        ax = plt.gca()
        ax.set_axisbelow(True)
        plt.grid(True)
        plt.tight_layout()

        # Salvar o gráfico em um buffer
        buffer = io.BytesIO()
        plt.savefig(buffer, format="png")
        buffer.seek(0)
        plt.close()

        return buffer

    async def plot_price_distribution_boxplot(self, year_reference: int, month_reference: int, top_n: int = 10):
        # Usar o novo método get_top_10_brands_prices para pegar as 10 marcas com mais anúncios e seus preços
        data = await self.data_manager.get_top_10_brands_prices(year_reference, month_reference)

        # Checar se há dados disponíveis
        if not data.get('brand_prices'):
            return {"error": "Nenhum dado disponível para o ano/mês especificado."}

        # Obter as marcas e seus respectivos preços
        brand_prices = data["brand_prices"]

        sorted_brands = sorted(brand_prices.items(), key=lambda x: len(x[1]), reverse=True)

        # Preparar os dados para o boxplot
        boxplot_data = []
        labels = []
        for brand, prices in sorted_brands:
            # Converter valores de Decimal para float
            prices = [float(price) for price in prices]

            # Verificar se a marca tem variabilidade de preços (evita boxplots monolíticos)
            if len(prices) > 1:  # Se houver mais de um preço, podemos calcular o boxplot
                boxplot_data.append(prices)
                labels.append(brand)

        # Verificar se existem dados suficientes para o boxplot
        if not boxplot_data:
            return {"error": "Não há dados suficientes para gerar o boxplot."}

        # Criar o boxplot
        plt.figure(figsize=(12, 8))
        box = plt.boxplot(boxplot_data, vert=True, patch_artist=True, labels=labels)

        # Customizar a cor dos boxplots
        for patch in box['boxes']:
            patch.set_facecolor("#ef44a1")

        for median in box['medians']:
            median.set(color='black', linewidth=2)

        for i, median in enumerate(box['medians']):
            y = median.get_ydata()[0]
            plt.plot(i + 1, y, 'o', color='black', markersize=6)

        plt.xlabel("Marcas", fontsize=16)  # Aumenta o tamanho da legenda do eixo X
        plt.ylabel("Preço (R$)", fontsize=16)  # Aumenta o tamanho da legenda do eixo Y
        plt.title(f"Distribuição de Preços por Marca - Ano/Mês: {year_reference}/{month_reference}",
                  fontsize=22)  # Aumenta o título
        plt.xticks(rotation=45, ha="right", fontsize=16)  # Aumenta o tamanho das legendas no eixo X
        plt.yticks(fontsize=16)  # Aumenta o tamanho das legendas no eixo Y
        plt.grid(True)

        # Formatando o eixo Y para exibir como moeda
        ax = plt.gca()
        ax.yaxis.set_major_formatter(
        ticker.FuncFormatter(lambda x, _: f'R${x:,.2f}'.replace(",", "X").replace(".", ",").replace("X", ".")))

        plt.tight_layout()

        # Salvar o gráfico em um buffer
        buffer = io.BytesIO()
        plt.savefig(buffer, format="png")
        buffer.seek(0)
        plt.close()

        return buffer