def format_price(price):
    """
    Formata o valor previsto no estilo monetário brasileiro.
    Converte para string com separadores de milhar e duas casas decimais.
    """
    formatted_price = f"{price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {formatted_price}"
