from fastapi import HTTPException


class InvalidMachineAverage(HTTPException):
    VALID_MACHINES_AVERAGE = [
        "machine",
    ]

    def __init__(self, machine):
        self.machine = machine
        detail = (
            f"Máquina inválida para está funcionalidade e cálculo de médias: {machine}. Indique "
            f"uma das seguintes máquinas: {', '.join(self.VALID_MACHINES_AVERAGE)}")
        super().__init__(status_code=400, detail=detail)


class InvalidCodeModel(HTTPException):
    def __init__(self, code_model: str, machine: str):
        detail = f"O Código Modelo: '{code_model}' não existe para a máquina {machine}."
        super().__init__(status_code=400, detail=detail)
