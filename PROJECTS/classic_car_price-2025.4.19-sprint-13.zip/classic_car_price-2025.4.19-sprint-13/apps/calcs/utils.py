import io
import asyncio
import tempfile

from reportlab.lib import colors
from fastapi import HTTPException
from reportlab.pdfgen import canvas
from fastapi.responses import JSONResponse
from reportlab.lib.pagesizes import letter
from fastapi.encoders import jsonable_encoder

from apps.calcs.graph_generator import GraphGenerator
from apps.calcs.db_manager import DatabaseManagerAverage
from apps.calcs.schemas import AnnualAverageSchema, MonthlyAverageSchema
from apps.calcs.templates.final_report import REPORT_INFO


def clean_string(value: str) -> str:
    return value.strip().upper()


async def get_annual_averages(
    machine: str, page: int = 1, size: int = 10
) -> JSONResponse:
    try:

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        db_manager = DatabaseManagerAverage(machine, loop)
        query = await db_manager.get_annual_average_async()

        total = len(query)

        if not total:
            return JSONResponse(
                content={
                    "message": "Não há médias anuais para a máquina especificada.",
                    "data": {},
                },
                status_code=400,
            )

        start = (page - 1) * size
        end = start + size
        paginated_query = query[start:end]

        annual_averages_schema = [
            jsonable_encoder(
                AnnualAverageSchema.model_validate(
                    {
                        "reference_year": avg["reference_year"],
                        "code_model": avg["code_model"],
                        "year_model": avg["year_model"],
                        "annual_average": avg["annual_average"],
                    }
                ).model_dump()
            )
            for avg in paginated_query
        ]

        content = {
            "message": "Dados encontrados com sucesso!",
            "items": annual_averages_schema,
            "page": page,
            "size": size,
            "total": total,
            "pages": (total // size) + (1 if total % size > 0 else 0),
        }

        return JSONResponse(content=content, status_code=200)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


async def get_filtered_averages(
    machine: str,
    code_model: str,
    year_model: int,
    year_reference: int = None,
    month_reference: int = None,
    is_active: bool = None,
    page: int = 1,
    size: int = 10,
) -> JSONResponse:
    try:

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        db_manager = DatabaseManagerAverage(machine, loop)
        monthly_query = await db_manager.get_filtered_averages_async(
            code_model=code_model,
            year_model=year_model,
            year_reference=year_reference,
            month_reference=month_reference,
            is_active=is_active,
        )

        # Verificar se há resultados
        total = len(monthly_query)
        if total == 0:
            return JSONResponse(
                content={
                    "message": "Não há resultados para os parâmetros especificados.",
                    "data": [],
                },
                status_code=404,
            )

        # Paginação
        start = (page - 1) * size
        end = start + size
        paginated_query = monthly_query[start:end]

        # Processar dados em esquema
        monthly_averages_schema = [
            jsonable_encoder(
                MonthlyAverageSchema.model_validate(
                    {
                        "reference_year": avg["reference_year"],
                        "reference_month": avg["reference_month"],
                        "code_model": avg["code_model"],
                        "year_model": avg["year_model"],
                        "average_price": avg["average_price"],
                        "ad_count": avg["ad_count"],
                        "is_active": avg["is_active"],
                    }
                ).model_dump()
            )
            for avg in paginated_query
        ]

        content = {
            "message": "Dados encontrados com sucesso!",
            "monthly_averages": monthly_averages_schema,
            "page": page,
            "size": size,
            "total": total,
            "pages": (total // size) + (1 if total % size > 0 else 0),
        }

        return JSONResponse(content=content, status_code=200)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


async def generate_report_and_insights(
    machine: str, year_reference: int, month_reference: int
):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    db_manager = DatabaseManagerAverage(machine, loop)
    graph_generator = GraphGenerator(db_manager)

    # Generate the top_code_models graph
    ads_top_code_models_buffer = await graph_generator.plot_top_brands_ads_distribution(
        year_reference, month_reference
    )
    if ads_top_code_models_buffer is None:
        raise HTTPException(
            status_code=500, detail="Falha ao gerar o gráfico de top 10 cód. modelos"
        )

    # Generate the price distribution histogram
    price_distribution_buffer = await graph_generator.plot_price_distribution_boxplot(
        year_reference, month_reference
    )
    if price_distribution_buffer is None:
        raise HTTPException(
            status_code=500,
            detail="Falha ao gerar o histograma de distribuição de preços",
        )

    # Get the analysis conclusion
    conclusion_result = await db_manager.generate_conclusion_by_reference_date(
        year_reference, month_reference
    )

    if not conclusion_result["conclusion"]:
        raise HTTPException(
            status_code=404,
            detail="Nenhuma conclusão encontrada para a data de referência fornecida",
        )

    # Create the PDF report
    pdf_buffer = io.BytesIO()
    c = canvas.Canvas(pdf_buffer, pagesize=letter)
    width, height = letter

    # Add the title
    title = f"Relatório Final Ano/Mês Referência: {year_reference}/{month_reference}"
    c.setFont("Helvetica-Bold", 16)
    title_width = c.stringWidth(title, "Helvetica-Bold", 16)
    c.drawString((width - title_width) / 2, height - 50, title)

    # Add the general objective
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 80, "Objetivo Geral:")
    c.setFont("Helvetica", 10)
    y_position = draw_wrapped_text(c, REPORT_INFO["general_objective"], 50, height - 100, 500, 12)

    # Add the specific objectives
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y_position - 20, "Objetivos Específicos:")
    c.setFont("Helvetica", 10)
    y_position -= 40
    for obj in REPORT_INFO["specific_objectives"]:
        y_position = draw_wrapped_text(c, obj, 50, y_position, 500, 12)
        y_position -= 12

    # Save the graph images to temporary files
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file1, tempfile.NamedTemporaryFile(delete=False) as tmp_file2:
        tmp_file1.write(ads_top_code_models_buffer.getvalue())
        tmp_file2.write(price_distribution_buffer.getvalue())

        tmp_file1.close()
        tmp_file2.close()

        # Adjust y_position to avoid overlapping with the graphs
        y_position -= 50

        # Add the "Marcas mais anúnciadas" graph to the PDF
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Gráfico: Marcas mais anúnciadas")
        y_position -= 20
        c.drawImage(tmp_file1.name, 50, y_position - 250, width=500, height=250)
        y_position -= 250  # Adjust y_position after the image

        # Add the "Descrição" for "Marcas mais anúnciadas"
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Descrição:")
        y_position -= 20
        c.setFont("Helvetica", 10)
        y_position = draw_wrapped_text(c, REPORT_INFO["graphs"]["top_10_brands_ads_distribution"]["description"], 50,
                                       y_position, 500, 12)
        y_position -= 20

        # Add the "Aplicação dos Dados" for "Marcas mais anúnciadas"
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Aplicação dos Dados:")
        y_position -= 20
        c.setFont("Helvetica", 10)
        for value in REPORT_INFO["graphs"]["top_10_brands_ads_distribution"]["data_application"]:
            y_position = draw_wrapped_text(c, value, 50, y_position, 500, 12)
            y_position -= 12

        # Check if we need to add another page for the Box Plot graph
        if y_position < 150:
            c.showPage()
            y_position = height - 50  # Reset y_position for new page

        # Add the "Distribuição de Preços por Marca" graph to the PDF (on a new page if necessary)
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Gráfico: Distribuição de Preços por Marca")
        y_position -= 20
        c.drawImage(tmp_file2.name, 50, y_position - 250, width=500, height=250)
        y_position -= 250  # Adjust y_position after the image

        # Add the "Descrição" for "Distribuição de Preços por Marca"
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Descrição:")
        y_position -= 20
        c.setFont("Helvetica", 10)
        y_position = draw_wrapped_text(c, REPORT_INFO["graphs"]["price_distribution_boxplot"]["description"], 50,
                                       y_position, 500, 12)
        y_position -= 20

        # Add the "Aplicação dos Dados" for "Distribuição de Preços por Marca"
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "Aplicação dos Dados:")
        y_position -= 20
        c.setFont("Helvetica", 10)
        for value in REPORT_INFO["graphs"]["price_distribution_boxplot"]["data_application"]:
            y_position = draw_wrapped_text(c, value, 50, y_position, 500, 12)
            y_position -= 12

        # Check if we need to add another page for insights
        if y_position < 100:
            c.showPage()
            y_position = height - 50  # Reset y_position for new page

        # Add the insights to the PDF
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position - 20, "Conclusão:")

        c.setFont("Helvetica", 8)
        c.setFillColor(colors.black)
        y_position -= 40
        line_height = 12
        max_width = 500

        conclusion_text = conclusion_result["conclusion"]

        y_position = draw_wrapped_text(c, conclusion_text, 50, y_position, max_width, line_height)
        y_position -= line_height

        c.showPage()
        c.save()

        pdf_buffer.seek(0)
        return pdf_buffer


def draw_wrapped_text(canvas, text, x, y, max_width, line_height, font="Helvetica", font_size=10, height=50):
    """
    Objetivo: Faz com que o escrito do relatório não ultrapasse a margem.
    """
    words = text.split()
    line = ""
    canvas.setFont(font, font_size)
    for word in words:
        # Verifica o comprimento do texto atual e o comprimento da palavra a ser adicionada
        if canvas.stringWidth(line + word, font, font_size) < max_width:
            line += word + " "
        else:
            # Desenha o texto na linha atual
            canvas.drawString(x, y, line.strip())
            y -= line_height
            line = word + " "

            # Se a linha do texto ultrapassar a margem, reinicia a linha
            if y <= 50:  # Ajuste o valor para garantir que o texto não ultrapasse o limite inferior
                canvas.showPage()  # Nova página
                y = height - 50  # Reinicia o y para a próxima página

    if line:
        canvas.drawString(x, y, line.strip())
    return y
