import json
from unittest.mock import AsyncMock, patch

import pytest
from fastapi import HTTPException
from fastapi.responses import JSONResponse

from apps.calcs.db_manager import DatabaseManagerAverage
from apps.calcs.utils import get_filtered_averages


@pytest.mark.asyncio
@patch.object(DatabaseManagerAverage,
              "get_filtered_averages_async",
              new_callable=AsyncMock)
async def test_get_filtered_averages_success(mock_get_filtered_averages_async):
    """Testa se a função retorna os dados corretamente quando há resultados."""

    mock_get_filtered_averages_async.return_value = [
        {
            "reference_year": 2025,
            "reference_month": 1,
            "code_model": "valid_model",
            "year_model": 2022,
            "average_price": 50000,
            "ad_count": 10,
            "is_active": True,
        }
    ]

    response = await get_filtered_averages(
        machine="car",
        code_model="valid_model",
        year_reference=2025,
        month_reference=1,
        is_active=True,
        page=1,
        size=10
    )

    assert isinstance(response, JSONResponse)
    assert response.status_code == 200

    json_data = json.loads(response.body)  # Correção aqui

    assert json_data["message"] == "Dados encontrados com sucesso!"
    assert json_data["total"] == 1
    assert json_data["monthly_averages"][0]["average_price"] == 50000

    mock_get_filtered_averages_async.assert_awaited_once()


@pytest.mark.asyncio
@patch.object(DatabaseManagerAverage, "get_filtered_averages_async",
              new_callable=AsyncMock, return_value=[])
async def test_get_filtered_averages_no_results(mock_get_filtered_averages_async):
    """Testa se a função retorna corretamente quando não há resultados."""

    response = await get_filtered_averages(
        machine="car",
        code_model="valid_model",
        year_reference=2025,
        month_reference=1,
        is_active=True,
        page=1,
        size=10
    )

    assert isinstance(response, JSONResponse)
    assert response.status_code == 404

    json_data = json.loads(response.body)  # Correção aqui

    assert json_data["message"] == "Não há resultados para os parâmetros especificados."
    assert json_data["data"] == []

    mock_get_filtered_averages_async.assert_awaited_once()


@pytest.mark.asyncio
@patch.object(DatabaseManagerAverage, "get_filtered_averages_async",
              new_callable=AsyncMock, side_effect=Exception("DB error"))
async def test_get_filtered_averages_internal_error(mock_get_filtered_averages_async):
    """Testa se a função lida corretamente com erros internos."""

    with pytest.raises(HTTPException) as exc:
        await get_filtered_averages(
            machine="car",
            code_model="valid_model",
            year_reference=2025,
            month_reference=1,
            is_active=True,
            page=1,
            size=10
        )

    assert exc.value.status_code == 500
    assert "Erro interno: DB error" in exc.value.detail
    mock_get_filtered_averages_async.assert_awaited_once()
