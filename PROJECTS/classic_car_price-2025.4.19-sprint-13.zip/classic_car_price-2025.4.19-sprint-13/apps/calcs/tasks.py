import asyncio
import base64
import logging

from celery import shared_task

from apps.calcs.db_manager import DatabaseManagerAverage
from apps.calcs.utils import generate_report_and_insights

logging.basicConfig(level=logging.INFO)


@shared_task
def calculate_averages(machine: str):
    loop = asyncio.get_event_loop()

    # Se o loop não estiver presente, cria um novo loop (embora isso não
    # devesse acontecer)
    if loop is None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    db_manager_average = DatabaseManagerAverage(machine, loop)
    averages = db_manager_average.get_machine_average()
    logging.info(f"AVERAGES: {averages}")
    return averages


@shared_task
def generate_report_task(machine: str, year_reference: int, month_reference: int):
    try:
        # Obtendo ou criando um event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        # Chamada assíncrona para geração do relatório
        pdf_buffer = loop.run_until_complete(
            generate_report_and_insights(machine, year_reference, month_reference)
        )

        # Transformar o buffer do PDF em Base64
        pdf_base64 = base64.b64encode(pdf_buffer.getvalue()).decode("utf-8")

        logging.info("Relatório gerado com sucesso e codificado em Base64.")
        return {
            "status": "PDF_GENERATED",
            "pdf_base64": pdf_base64,
        }

    except Exception as e:
        logging.error(f"Erro ao gerar o relatório: {e}")
        raise
