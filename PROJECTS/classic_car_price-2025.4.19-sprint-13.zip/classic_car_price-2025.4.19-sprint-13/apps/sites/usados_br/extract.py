from apps.core.base_extract import BaseExtract


class UsadosBRExtract(BaseExtract):

    def __init__(self, machine, machine_urls):
        self.extract_methods = {
            "description": {
                "extract_method": "selenium",
                "xpath": '//*[@id="description-title"]/div',
                "fail_key": "description_extract",
            },
            "year_model": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div/div[1]/span[2]',
                "fail_key": "year_extract",
            },
            "price": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div[1]/span',
                "fail_key": "price_extract",
            },
            "brand": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[1]/div[2]/h1',
                "fail_key": "brand_extract",
            },
            "title": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[1]/div[2]/h1',
                "fail_key": "title_extract",
            },
            "model": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[1]/div[2]/h1',
                "fail_key": "model_extract",
            },
            "mileage": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div[1]/div[2]/span[2]',
                "fail_key": "mileage_extract",
            },
            "city": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div/div[8]/span[2]',
                "fail_key": "city_extract",
            },
            "state": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div/div[8]/span[2]',
                "fail_key": "state_extract",
            },
            "fuel": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div[1]/div[3]/span[2]',
                "fail_key": "fuel_extract",
            },
            "gear": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div[1]/div[4]/span[2]',
                "fail_key": "gear_extract",
            },
            "bodywork": {
                "extract_method": "selenium",
                "xpath": '//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div[1]/div[5]/span[2]',
                "fail_key": "bodywork_extract",
            },
        }
        super().__init__(machine=machine, machine_urls=machine_urls)

    def brand_extract(self, **kwargs):
        try:
            # Use the existing selenium_extract method
            brand_text = self.selenium_extract(
                xpath='//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[1]/div[2]/h1',
                fail_key="brand_extract",
            )
            if brand_text:
                # Process the text to get the first word
                brand = brand_text.split()[0]
                return brand
            # Log failure if text is empty
            self.fail_machine.setdefault(self.current_url, []).append("brand_extract")
            return None
        except Exception:
            # Log failure in case of any exception
            self.fail_machine.setdefault(self.current_url, []).append("brand_extract")
            return None

    def model_extract(self, **kwargs):
        try:
            # Use the existing selenium_extract method
            model_text = self.selenium_extract(
                xpath='//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[1]/div[2]/h1',
                fail_key="model_extract",
            )
            if model_text:
                # Process the text to remove the first word
                model_parts = model_text.split()
                if len(model_parts) > 1:
                    model = " ".join(model_parts[1:])
                    return model
            # Log failure if text is empty
            self.fail_machine.setdefault(self.current_url, []).append("model_extract")
            return None
        except Exception:
            # Log failure in case of any exception
            self.fail_machine.setdefault(self.current_url, []).append("model_extract")
            return None

    def state_extract(self, **kwargs):
        try:
            # Use o método existente selenium_extract para buscar o texto
            state_text = self.selenium_extract(
                xpath='//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div/div[8]/span[2]',
                fail_key="state_extract",
            )
            if state_text:
                # Extraia o estado (últimos caracteres após o hífen)
                state_parts = state_text.split("-")
                if len(state_parts) > 1:
                    state = state_parts[-1].strip()
                    return state
            # Log de falha se o texto estiver vazio
            self.fail_machine.setdefault(self.current_url, []).append("state_extract")
            return None
        except Exception:
            # Log de falha em caso de qualquer exceção
            self.fail_machine.setdefault(self.current_url, []).append("state_extract")
            return None

    def city_extract(self, **kwargs):
        try:
            # Use o método existente selenium_extract para buscar o texto
            city_text = self.selenium_extract(
                xpath='//*[@id="__next"]/div/div[3]/div[2]/div[2]/div[1]/div[1]/section[2]/div/div[8]/span[2]',
                fail_key="city_extract",
            )
            if city_text:
                # Extraia a cidade (tudo antes do hífen)
                city_parts = city_text.split("-")
                if len(city_parts) > 0:
                    city = city_parts[0].strip()
                    return city
            # Log de falha se o texto estiver vazio
            self.fail_machine.setdefault(self.current_url, []).append("city_extract")
            return None
        except Exception:
            # Log de falha em caso de qualquer exceção
            self.fail_machine.setdefault(self.current_url, []).append("city_extract")
            return None

    def extract(self, extract_methods=None):
        if extract_methods is None:
            extract_methods = self.extract_methods
        return super().extract(extract_methods)


if __name__ == "__main__":
    urls = [
        "https://www.usadosbr.com/carros-e-utilitarios/chevrolet/s10/2-8-ls-16v-turbo/2022-branco-sao-luis-maranhao-1233"
    ]
    e = UsadosBRExtract(machine="machine", machine_urls=urls)
    extract = e.extract()
    print(extract)
