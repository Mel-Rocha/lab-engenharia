import time
import logging
from random import uniform

from lxml import etree
from bs4 import BeautifulSoup
from tenacity import retry, stop_after_attempt
from selenium.common import TimeoutException, NoSuchElementException

from apps.core.base_automation import BaseAutomation

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class UsadosBRAutomation(BaseAutomation):
    def __init__(self, machine):
        machine_urls = {
            "machine": "https://www.usadosbr.com/carros/br",
        }
        base_url = "https://www.usadosbr.com/"
        super().__init__(
            machine,
            machine_urls,
            "p-2 bg-white rounded-2xl flex flex-col w-full " "shadow-sm relative null",
            "div",
            base_url,
        )

    @retry(stop=stop_after_attempt(3))
    def machine_url_all(self, unique_page=False, page_name_param=None, page_number=0):
        current_url_all = []

        try:
            while True:
                url_page_list = self.machine_urls.get(self.machine, "")
                if page_name_param is not None:
                    url_page_list += f"?{page_name_param}={page_number}"
                (logging.info(f"Acessando URL: {url_page_list}"))
                if page_number == 49:
                    break
                self.driver.get(url_page_list)

                html_content = self.driver.page_source
                soup = BeautifulSoup(html_content, "html.parser")

                if self.xpath:
                    # Converte para lxml e faz a busca com XPath
                    dom = etree.HTML(str(soup))
                    all_elements = dom.xpath(self.xpath)
                elif self.css_selector:
                    # Busca usando o seletor CSS
                    all_elements = soup.select(self.css_selector)
                else:
                    # Busca usando find_all com tag e classe
                    all_elements = soup.find_all(
                        self.element_type_tag, class_=self.all_elements_class
                    )

                num_all_elements = len(all_elements)

                if not all_elements:
                    break

                self.old_len = len(current_url_all)

                for element in all_elements:
                    try:
                        if self.element_type_tag == "a":
                            a_tag = element
                        else:
                            a_tag = element.find("a")

                        if a_tag and "href" in a_tag.attrs:
                            url = (
                                a_tag["href"]
                                if self.base_url is None
                                else f"{self.base_url}{a_tag['href']}"
                            )
                            current_url_all.append(url)
                            logging.info(f"URL extraída: {url}")
                        else:
                            logging.error(
                                "Tag <a> não encontrada ou sem atributo href."
                            )
                            continue
                    except TimeoutException as e:
                        print(f"Erro ao clicar na imagem: Tempo de execução limite {e}")
                        logging.error(
                            "O elemento foi encontrado, mas não se tornou visível dentro do tempo limite."
                        )
                        continue
                    except NoSuchElementException as e:
                        print(f"Erro ao clicar na imagem: Imagem não encontrada {e}.")
                        logging.error("O elemento não foi encontrado.")
                        continue

                    self.driver.back()
                    time.sleep(uniform(1.8, 2.5))

                metrics = self.automation_validation(
                    page_number, num_all_elements, current_url_all, self.old_len
                )
                self.metrics.append(metrics)

                if unique_page:
                    break
                page_number += 1

        finally:
            super().stop_driver()

            print(self.metrics)
            return current_url_all, self.metrics


if __name__ == "__main__":
    a = UsadosBRAutomation("machine")
    url_all = a.machine_url_all(page_name_param="pagina", page_number=1)
