from apps.core.base_extract import BaseExtract


class OlxExtract(BaseExtract):

    def __init__(self, machine, machine_urls):
        self.extract_methods = {
            "description": {
                "extract_method": "selenium",
                "xpath": '//*[@id="description-title"]/div',
                "fail_key": "description_extract",
            },
            "year_model": {
                "extract_method": "selenium",
                "xpath": '//*[@id="details"]/div/div[1]/div[5]/div[2]/a',
                "fail_key": "year_extract",
            },
            "price": {
                "extract_method": "selenium",
                "xpath": '//*[@id="price-box-container"]/div[1]/div[1]/span[2]',
                "fail_key": "price_extract",
            },
            "brand": {
                "extract_method": "selenium",
                "xpath": '//*[@id="details"]/div/div[1]/div[3]/div[2]/a',
                "fail_key": "brand_extract",
            },
            "title": {
                "extract_method": "selenium",
                "xpath": '//*[@id="description-title"]/div/span',
                "fail_key": "title_extract",
            },
            "model": {
                "extract_method": "selenium",
                "xpath": '//*[@id="details"]/div/div[1]/div[2]/div[2]/a',
                "fail_key": "model_extract",
            },
        }
        super().__init__(machine=machine, machine_urls=machine_urls)

    def extract(self, extract_methods=None):
        if extract_methods is None:
            extract_methods = self.extract_methods
        return super().extract(extract_methods)


if __name__ == "__main__":
    urls = [
        "https://pe.olx.com.br/grande-recife/autos-e-pecas/carros-vans-e-utilitarios/audi-q5-q5-s-line-2-0-tfsi"
        "-quattro-s-tronic-2021-f-8198576-6247-1350495188"]
    e = OlxExtract(machine="machine", machine_urls=urls)
    extract = e.extract()
    print(extract)
