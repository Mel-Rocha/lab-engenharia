from apps.core.base_extract import BaseExtract


class MercadoLivreExtract(BaseExtract):

    def __init__(self, machine, machine_urls):
        self.extract_methods = {
            "description": {
                "extract_method": "selenium",
                "xpath": "//p[@class='ui-pdp-description__content']",
                "fail_key": "description_extract",
            },
            "year_model": {
                "extract_method": "selenium",
                "xpath": '//*[@id="header"]/div/div[1]/span',
                "fail_key": "year_extract",
            },
            "price": {
                "extract_method": "selenium",
                "xpath": "//span[@class='andes-money-amount__fraction']",
                "fail_key": "price_extract",
            },
            "brand": {
                "extract_method": "selenium",
                "xpath": "//th[div[text()='Marca']]/following-sibling::td/span",
                "fail_key": "brand_extract",
            },
            "title": {
                "extract_method": "selenium",
                "xpath": "//h1[@class='ui-pdp-title']",
                "fail_key": "title_extract",
            },
            "model": {
                "extract_method": "selenium",
                "xpath": "//th[div[text()='Modelo']]/following-sibling::td/span",
                "fail_key": "model_extract",
            },
        }
        super().__init__(machine=machine, machine_urls=machine_urls)

    def extract(self, extract_methods=None):
        if extract_methods is None:
            extract_methods = self.extract_methods
        return super().extract(extract_methods)


if __name__ == "__main__":
    urls = [
        "https://carro.mercadolivre.com.br/MLB-5144610172-porsche-911-carrera-s-_JM#position%3D2%26search_"
        "layout%3Dgrid%26type%3Ditem%26tracking_id%3Daf299d5e-8b95-42d6-9d65-3f7627be21c6"]
    e = MercadoLivreExtract(machine="machine", machine_urls=urls)
    extract = e.extract()
    print(extract)
