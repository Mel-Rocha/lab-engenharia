import time
import logging
from random import uniform

from bs4 import BeautifulSoup
from tenacity import stop_after_attempt, retry
from selenium.common import NoSuchElementException
from selenium.common.exceptions import TimeoutException

from apps.core.base_automation import BaseAutomation

logging.basicConfig(level=logging.INFO)


class MercadoLivreAutomation(BaseAutomation):
    def __init__(self, machine):
        machine_urls = {
            "machine": "https://lista.mercadolivre.com.br/veiculos/carros-caminhonetes/carros-esportivos_NoIndex_True",
        }
        super().__init__(machine, machine_urls, "ui-search-layout__item", "li")

    @retry(stop=stop_after_attempt(3))
    def machine_url_all(self, unique_page=False, page_name_param=None, page_number=1):
        current_url_all = []
        logging.info(f"Iniciando o processo com unique_page: {unique_page}")
        try:
            while True:
                if page_number == 1:
                    page_all_offers = self.machine_urls.get(self.machine, "")
                else:
                    page_all_offers = (
                        f"{self.machine_urls.get(self.machine, '')}_Desde_{page_number}"
                    )

                self.driver.get(page_all_offers)
                logging.info(f"ACESSANDO A PÁGINA {self.driver.current_url}")

                html_content = self.driver.page_source
                soup = BeautifulSoup(html_content, "html.parser")
                all_elements = soup.find_all(
                    self.element_type_tag, class_=self.all_elements_class
                )
                num_all_elements = len(all_elements)

                logging.info(
                    f"Número de elementos na página {page_number}: {num_all_elements}"
                )

                if not all_elements:
                    logging.info("Nenhum elemento encontrado, finalizando o loop.")
                    break

                self.old_len = len(current_url_all)

                for element in all_elements:
                    try:
                        if self.element_type_tag == "a":
                            a_tag = element
                        else:
                            a_tag = element.find("a")

                        if a_tag and "href" in a_tag.attrs:
                            url = (
                                a_tag["href"]
                                if self.base_url is None
                                else f"{self.base_url}{a_tag['href']}"
                            )
                            current_url_all.append(url)
                            logging.info(f"URL extraída: {url}")
                        else:
                            logging.error(
                                "Tag <a> não encontrada ou sem atributo href."
                            )
                            continue
                    except TimeoutException as e:
                        print(f"Erro ao clicar na imagem: Tempo de execução limite {e}")
                        logging.error(
                            "O elemento foi encontrado, mas não se tornou visível dentro do tempo limite."
                        )
                        continue
                    except NoSuchElementException as e:
                        print(f"Erro ao clicar na imagem: Imagem não encontrada {e}.")
                        logging.error("O elemento não foi encontrado.")
                        continue

                    self.driver.back()
                    time.sleep(uniform(1.8, 2.5))

                metrics = self.automation_validation(
                    page_number, num_all_elements, current_url_all, self.old_len
                )
                self.metrics.append(metrics)

                if unique_page:
                    break

                logging.info(f"Indo para a próxima página: {page_number + 48}")
                page_number += 48  # Atualizando o número da página para a próxima
        except Exception as e:
            logging.error(f"Erro durante o processo: {e}")

        finally:
            super().stop_driver()

            print(self.metrics)
            return current_url_all, self.metrics


if __name__ == "__main__":
    a = MercadoLivreAutomation("machine")
    url_all = a.machine_url_all()
