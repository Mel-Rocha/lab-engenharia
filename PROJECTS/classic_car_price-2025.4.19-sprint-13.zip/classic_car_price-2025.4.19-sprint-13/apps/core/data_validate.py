import logging

from apps.core.data_processing import NormalizeData, BusinessRules


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ValidateData:
    def __init__(self, machine):
        self.machine = machine
        self.normalizer = NormalizeData()
        self.required_keys = [
            "crawl_date",
            "model",
            "url",
            "price",
            "brand",
            "year_model",
            "description",
            "code_model",
            "title",
            "year_fabrication",
            "mileage",
            "city",
            "state",
            "fuel",
            "gear",
            "bodywork",
            "year_reference",
            "month_reference",
        ]

    def apply_normalize(self, raw_data_list: list) -> list:
        """
        Cleans and normalizes a list of raw data.

        :param raw_data_list: List of machine raw data.
        :return: List of cleaned and normalized data.
        """
        validated_data = []

        logger.info(f"Raw data list: {raw_data_list}")
        for raw_data in raw_data_list:
            logger.info(f"Raw data: {raw_data}")

            #  Normalizers
            if "price" in raw_data and raw_data["price"] is not None:
                raw_data["price"] = self.normalizer.normalize_price(
                    str(raw_data["price"])
                )

            if "year_model" in raw_data and raw_data["year_model"] is not None:
                raw_data["year_model"] = self.normalizer.normalize_year(
                    str(raw_data["year_model"])
                )

            if (
                "year_fabrication" in raw_data
                and raw_data["year_fabrication"] is not None
            ):
                raw_data["year_fabrication"] = self.normalizer.normalize_year(
                    str(raw_data["year_fabrication"])
                )

            if "mileage" in raw_data and raw_data["mileage"] is not None:
                raw_data["mileage"] = self.normalizer.normalize_mileage(
                    str(raw_data["mileage"])
                )

            cleaned_data = self.normalizer.util_clean_data_all(raw_data)

            #  Truncations
            if "title" in cleaned_data and cleaned_data["title"] is not None:
                cleaned_data["title"] = self.normalizer.truncate_title(
                    cleaned_data["title"]
                )
            if (
                "description" in cleaned_data
                and cleaned_data["description"] is not None
            ):
                cleaned_data["description"] = self.normalizer.truncate_description(
                    cleaned_data["description"]
                )
            if "model" in cleaned_data and cleaned_data["model"] is not None:
                cleaned_data["model"] = self.normalizer.truncate_model(
                    cleaned_data["model"]
                )
            if "brand" in cleaned_data and cleaned_data["brand"] is not None:
                cleaned_data["brand"] = self.normalizer.truncate_brand(
                    cleaned_data["brand"]
                )

            if "city" in cleaned_data and cleaned_data["city"] is not None:
                cleaned_data["city"] = self.normalizer.truncate_city(
                    cleaned_data["city"]
                )

            if "state" in cleaned_data and cleaned_data["state"] is not None:
                cleaned_data["state"] = self.normalizer.truncate_state(
                    cleaned_data["state"])

            if "fuel" in cleaned_data and cleaned_data["fuel"] is not None:
                cleaned_data["fuel"] = self.normalizer.truncate_fuel(
                    cleaned_data["fuel"])

            if "gear" in cleaned_data and cleaned_data["gear"] is not None:
                cleaned_data["gear"] = self.normalizer.truncate_gear(
                    cleaned_data["gear"])

            if "bodywork" in cleaned_data and cleaned_data["bodywork"] is not None:
                cleaned_data["bodywork"] = self.normalizer.truncate_bodywork(
                    cleaned_data["bodywork"])

            for key in self.required_keys:
                if key not in cleaned_data:
                    cleaned_data[key] = None

            validated_data.append(cleaned_data)
            logger.info(f"Data normalized: {cleaned_data}")

        return validated_data

    def apply_business_rules(self, normalized_data_list: list) -> (list, list):
        """
        Applies business rules to already sanitized data.

        :param normalized_data_list: List of normalized machine data.
        :return: List of validated data or empty list if they are invalid according to business rules.
        """
        validated_data = []
        invalidated_data = []

        for normalized_data in normalized_data_list:
            causes_of_disposal = []

            # Infer missing model if not provided
            model = normalized_data.get("model")
            title = normalized_data.get("title")
            model = BusinessRules.infer_missing_model(model, title)
            normalized_data["model"] = model

            price = normalized_data.get("price")
            if price is None:
                price = BusinessRules.infer_missing_price(
                    price, normalized_data.get("description")
                )
                normalized_data["price"] = price
                if price is None:
                    causes_of_disposal.append("price could not be inferred")

            # Apply price cutoff value rule
            if price is not None:
                price = BusinessRules.price_cutoff_value(price)
                normalized_data["price"] = price
                if price is None:
                    causes_of_disposal.append("price below cutoff value")

            # Infer missing year if not provided
            year_model = normalized_data.get("year_model")
            if year_model is None:
                year_model = BusinessRules.infer_missing_year(
                    year_model,
                    normalized_data.get("title"),
                    normalized_data.get("description"),
                )
                normalized_data["year_model"] = year_model
                if year_model is None:
                    causes_of_disposal.append("year_model could not be inferred")

            # Apply should_discard rule
            if BusinessRules.should_discard(
                normalized_data["price"],
                normalized_data["model"],
                normalized_data["year_model"],
            ):
                causes_of_disposal.append("missing required fields")

            fuel = normalized_data.get("fuel")
            if fuel is not None:
                fuel = BusinessRules.standardize_fuel(fuel)
                normalized_data["fuel"] = fuel

            gear = normalized_data.get("gear")
            if gear is not None:
                gear = BusinessRules.standardize_gear(gear)
                normalized_data["gear"] = gear

            bodywork = normalized_data.get("bodywork")
            if bodywork is not None:
                bodywork = BusinessRules.standardize_bodywork(bodywork)
                normalized_data["bodywork"] = bodywork

            if causes_of_disposal:
                invalidated_data.append((normalized_data, causes_of_disposal))
            else:
                validated_data.append(normalized_data)

        logger.info(f"Data validated: {validated_data}")
        logger.info(f"Data invalidated: {invalidated_data}")
        return validated_data, invalidated_data


if __name__ == "__main__":
    # Dados de teste com valores que podem causar descartes
    raw_data = {
        "year_model": None,  # Caso o ano seja descartado
        "model": "MACAN",
        "brand": "PORSCHE",
        "price": 5001,  # Mantido como valor numérico
        "month_reference": 12,
        "year_reference": 2022,
        "description": "A gasolina, automático, SUV, cor preta, ano 2027, R$ 5001",
        "title": "PORSCHE MACAN 2.0 16V",
        "state": "Sp",
        "city": "são paulo",
        "fuel": "Gasolina",  # Combustível validado
        "gear": "Automático",  # Câmbio validado
        "mileage": 1234567,
        "bodywork": "SuV",  # Tipo de carroceria validado
    }

    machine = "porsche"
    validator = ValidateData(machine)

    try:
        normalized_data = validator.apply_normalize([raw_data])  # Chamada em uma lista
        if (
            normalized_data
        ):  # Verifica se a lista não está vazia antes de acessar o índice 0
            normalized_data = normalized_data[
                0
            ]  # Extraindo o primeiro item como no código
            valid_data, invalid_data = validator.apply_business_rules([normalized_data])

            if valid_data:
                print("Dados prontos para serem salvos:", valid_data)
            else:
                print("Todos os dados foram descartados.")

            if invalid_data:
                print("Dados não validados:", invalid_data)
        else:
            print("Nenhum dado foi normalizado. Verifique as condições de descarte.")
    except IndexError as e:
        print("Erro de índice:", e)
