import io
import asyncio
import base64
import logging

from fastapi.responses import StreamingResponse
from fastapi import APIRouter, Query, HTTPException

from celery_app import celery_app
from apps.core.db_manager import DatabaseManager
from apps.core.exceptions import InvalidMachineError
from apps.core.utils import fetch_filtered_data, generate_xlsx_from


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/tasks/status/{task_id}")
def get_task_status(task_id: str):
    """
    Obtém o status de uma tarefa Celery.

    Este endpoint verifica o estado atual de uma tarefa identificada pelo `task_id`.
    Dependendo do estado, ele pode fornecer detalhes adicionais ou, em casos específicos de sucesso, retornar um arquivo PDF para download.

    Estados da tarefa:
    - PENDING: A tarefa está aguardando para ser executada.
    - PROGRESS: A tarefa está em execução e pode incluir detalhes sobre o progresso.
    - SUCCESS: A tarefa foi concluída com sucesso. Geralmente retorna um dicionário com o resultado da tarefa. Em casos específicos, pode retornar um arquivo PDF.
    - FAILURE: A tarefa falhou e detalhes do erro serão retornados.

    Parâmetros:
    - task_id (str): O identificador único da tarefa.

    Returns:
    - dict: Um dicionário contendo o status e, quando aplicável, informações detalhadas ou o resultado da tarefa.
    - StreamingResponse: Caso a tarefa seja concluída com sucesso e um arquivo PDF tenha sido gerado, retorna o PDF como resposta para download.
    """
    task_result = celery_app.AsyncResult(task_id)
    if task_result.state == "PENDING":
        return {"status": "PENDING"}
    elif task_result.state == "PROGRESS":
        return {
            "status": "PROGRESS",
            "step": task_result.info.get("step", "Unknown step"),
            "details": task_result.info.get("details", "No details available"),
        }

        # Status de sucesso
    elif task_result.state == "SUCCESS":
        result = task_result.result
        if isinstance(result, dict) and "pdf_base64" in result:
            # Decodifique o PDF
            pdf_content = base64.b64decode(result["pdf_base64"])
            pdf_stream = io.BytesIO(pdf_content)

            # Retorne o PDF como resposta
            return StreamingResponse(
                pdf_stream,
                media_type="application/pdf",
                headers={"Content-Disposition": "attachment; filename=report.pdf"},
            )
        return {"status": "SUCCESS", "result": result}

        # Status de falha
    elif task_result.state == "FAILURE":
        return {
            "status": "FAILURE",
            "result": str(task_result.info),  # Detalhes do erro
        }

        # Outros estados (opcional)
    else:
        return {
            "status": task_result.state,
            "details": "Unknown or custom state.",
        }


@router.get("/download/excel/{task_id}/{machine}")
async def generate_excel(task_id: str, machine: str):
    """
    Gera e retorna um arquivo Excel baseado nos resultados de uma tarefa Celery.

    Este endpoint permite o download de um arquivo Excel gerado com base nos resultados
    de uma tarefa de listagem concluída, identificada pelo `task_id`. O parâmetro `machine`
    é utilizado para validar e determinar o contexto associado à tarefa.

    Parâmetros:
    - task_id (str): O identificador único da tarefa Celery cujos resultados serão usados
      para gerar o arquivo Excel.
    - machine (str): O nome da máquina.

    Returns:
    - StreamingResponse: Um arquivo Excel para download, com o conteúdo baseado no resultado
      da tarefa de listagem concluída.

    Raise:
    - InvalidMachineError: Caso o parâmetro `machine` não corresponda a uma máquina válida.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    return generate_xlsx_from(task_id, machine)


@router.get("/brand/model/list/{machine}")
async def get_filtered_brands(
    machine: str,
    brand: str = Query(None),
    model: str = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1),
):
    """
    Retorna uma lista filtrada de marcas e modelos de uma máquina específica, com suporte a paginação.

    Este endpoint permite filtrar registros com base em marca e modelo, opcionalmente, para uma máquina
    específica validada. Os resultados são paginados com base nos parâmetros fornecidos.

    Parâmetros:
    - machine (str): Identificador da máquina.
    - brand (str, opcional): Nome da marca a ser filtrada.
    - model (str, opcional): Nome do modelo a ser filtrado.
    - page (int, opcional): Número da página para paginação (padrão: 1). Deve ser maior ou igual a 1.
    - page_size (int, opcional): Quantidade de itens por página para paginação (padrão: 10). Deve ser maior ou igual a 1.

    Returns:
    - dict: Um dicionário contendo os dados filtrados.

    Raise:
    - InvalidMachineError: Se a máquina fornecida não for válida.
    """
    valid_machines = set()
    for machines in InvalidMachineError.MACHINES_VALIDATED_BY_SITE.values():
        valid_machines.update(machines)

    if machine not in valid_machines:
        raise InvalidMachineError(
            machine, "os sites existentes", valid_machines=list(valid_machines)
        )

    brand = brand.upper() if brand else None
    model = model.upper() if model else None

    data = await fetch_filtered_data(machine, brand, model, page, page_size)

    return {"data": data}


@router.get("/general_kpi/{machine}/{year_reference}/{month_reference}")
async def get_general_kpi(machine: str, year_reference: int, month_reference: int):
    """
    Retorna os principais KPIs do mercado automotivo para um determinado mês e ano.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo os KPIs gerais do mercado.

    Exceções:
    - 400 Bad Request: Se a máquina fornecida for inválida.
    - 500 Internal Server Error: Se ocorrer um erro interno no servidor.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        db_manager = DatabaseManager(machine, loop)
        kpi_data = await db_manager.general_kpi(year_reference, month_reference)
        return kpi_data
    except InvalidMachineError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/geographic_pricing_analysis/{machine}/{year_reference}/{month_reference}")
async def get_geographic_pricing_analysis(
        machine: str,
        year_reference: int,
        month_reference: int):
    """
    Retorna uma análise de preços médios por estado e cidade.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo os preços médios agrupados por estado e cidade.

    Exceções:
    - 400 Bad Request: Se a máquina fornecida for inválida.
    - 500 Internal Server Error: Se ocorrer um erro interno no servidor.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        db_manager = DatabaseManager(machine, loop)
        analysis_data = await db_manager.geographic_pricing_analysis(year_reference, month_reference)
        return analysis_data
    except InvalidMachineError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/brand_model_analysis/{machine}/{year_reference}/{month_reference}")
async def get_brand_model_analysis(
        machine: str,
        year_reference: int,
        month_reference: int):
    """
    Retorna uma análise comparativa entre marcas e modelos de veículos.

    Parâmetros:
    - machine (str): Identificador da máquina que armazena os dados.
    - year_reference (int): Ano de referência para a análise.
    - month_reference (int): Mês de referência para a análise.

    Retorno:
    - dict: Dicionário contendo estatísticas como:
        - Marcas com mais anúncios.
        - Preço médio por marca.
        - Distribuição de preços por marca.
        - Comparação de preços por tipo de câmbio e carroceria.

    Exceções:
    - 400 Bad Request: Se a máquina fornecida for inválida.
    - 500 Internal Server Error: Se ocorrer um erro interno no servidor.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        db_manager = DatabaseManager(machine, loop)
        analysis_data = await db_manager.brand_model_analysis(year_reference, month_reference)
        return analysis_data
    except InvalidMachineError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")
