import pytz
from io import BytesIO

import openpyxl
import pandas as pd
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from starlette.responses import StreamingResponse
from openpyxl.worksheet.table import Table, TableStyleInfo


class ExcelGenerator:
    def __init__(self, machine):
        self.machine = machine

    MACHINE_MAPPING = {
        "machine": "MACHINE",
    }

    def get_machine_name(self):
        return self.MACHINE_MAPPING.get(self.machine, "dataframe")

    @staticmethod
    def remove_illegal_chars(text):
        if isinstance(text, str):
            return "".join(char for char in text if ord(char) >= 32)
        return text

    def generate(self, data):
        df = pd.DataFrame(data)

        datetime_columns = ['crawl_date', 'updated_at', 'created_at']
        timezone_sp = pytz.timezone('America/Sao_Paulo')

        for column in datetime_columns:
            df[column] = pd.to_datetime(df[column])
            if df[column].dt.tz is None:
                df[column] = df[column].dt.tz_localize('UTC')
            df[column] = df[column].dt.tz_convert(timezone_sp).dt.strftime('%d/%m/%Y %H:%M:%S')

        df.sort_values(by='crawl_date', ascending=False, inplace=True)

        df.rename(
            columns={
                "model": "MODELO",
                "year_model": "ANO MODELO",
                "price": "PRECO",
                "brand": "MARCA",
                "url": "URL",
                "id": "ID",
                "crawl_date": "DATA DA BUSCA",
                "description": "DESCRICAO",
                "code_model": "COD. MODELO",
                "created_at": "CRIADO EM",
                "updated_at": "ATUALIZADO EM",
                "year_fabrication": "ANO FABRICACAO",
                "title": "TITULO",
                "mileage": "QUILOMETRAGEM",
                "city": "CIDADE",
                "state": "ESTADO",
                "fuel": "COMBUSTIVEL",
                "gear": "CAMBIO",
                "bodywork": "CARROCERIA",
            },
            inplace=True,
        )

        df = df.applymap(ExcelGenerator.remove_illegal_chars)
        final_column_order = [
            "DATA DA BUSCA",
            "PRECO",
            "MARCA",
            "MODELO",
            "ANO MODELO",
            "TITULO",
            "DESCRICAO",
            "QUILOMETRAGEM",
            "COMBUSTIVEL",  # Tipo de combustível
            "CAMBIO",  # Tipo de câmbio
            "CARROCERIA",
            "ESTADO",
            "CIDADE",
            "URL",
            "ANO FABRICACAO",
            "COD. MODELO",
            "CRIADO EM",
            "ATUALIZADO EM",
            "ID",
        ]
        df = df[final_column_order]

        buffer = BytesIO()

        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)

        buffer.seek(0)

        book = openpyxl.load_workbook(buffer)
        sheet = book.active

        sheet.freeze_panes = "A2"
        sheet.sheet_view.showGridLines = False

        for column in sheet.columns:
            max_length = 0
            column = [cell for cell in column]
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except BaseException:
                    pass
            adjusted_width = max_length + 2
            sheet.column_dimensions[get_column_letter(column[0].column)].width = (
                adjusted_width
            )

        fill_pink = PatternFill(
            start_color="ffcfe9", end_color="ffcfe9", fill_type="solid"
        )
        fill_white = PatternFill(
            start_color="FFFFFF", end_color="FFFFFF", fill_type="solid"
        )

        for i, row in enumerate(sheet.iter_rows(min_row=2), start=2):
            fill = fill_pink if i % 2 == 0 else fill_white
            for cell in row:
                cell.fill = fill

        tab = Table(displayName="Table1", ref=sheet.dimensions)

        style = TableStyleInfo(
            name="TableStyleMedium9",
            showFirstColumn=False,
            showLastColumn=False,
            showRowStripes=True,
            showColumnStripes=True,
        )
        tab.tableStyleInfo = style

        sheet.add_table(tab)

        buffer = BytesIO()
        book.save(buffer)
        buffer.seek(0)

        filename = f"{self.get_machine_name()}.xlsx"
        return StreamingResponse(
            buffer,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"'},
        )
