from fastapi import HTTPException


class InvalidMachineError(HTTPException):
    MACHINES_VALIDATED_BY_SITE = {
        "mercado_livre": ["machine"],
        "usados_br": ["machine"],
        "olx": ["machine"],
    }

    def __init__(self, machine, site, valid_machines=None):
        self.machine = machine
        self.site = site
        if valid_machines is None:
            valid_machines = self.MACHINES_VALIDATED_BY_SITE.get(site, [])
        if machine not in valid_machines:
            detail = (
                f"Máquina inválida: {machine} para o site {site}. "
                f"Indique uma das seguintes máquinas válidas para este site: {', '.join(valid_machines)}")
            super().__init__(status_code=400, detail=detail)
        else:
            super().__init__(status_code=400, detail="Unknown error")


class InvalidSiteError(HTTPException):
    VALID_SITES = [
        "mercado_livre",
        "usados_br",
        "olx",
    ]

    def __init__(self, site):
        self.site = site
        detail = f"Site inválido: {site}. Indique um dos seguintes sites: {', '.join(self.VALID_SITES)}"
        super().__init__(status_code=400, detail=detail)
