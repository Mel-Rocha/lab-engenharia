import logging
from abc import ABC
from datetime import datetime

from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.common import NoSuchElementException
from tenacity import retry, stop_after_attempt, RetryError

from apps.core.data_validate import ValidateData
from apps.core.base_automation import CoreAutomation


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BaseExtract(CoreAutomation, ABC):
    """
    Objective: Based on the list of specific URLs for each ad, extract the relevant information.

    Mandatory Provide: List of URLs.

    Return: tuple containing:
        1. machine_list: List of dictionaries with information extracted from each advertisement.
        2. extract_failure_analysis: List of extract failure analyses.
        3. ads_dicard: List of urls to be discarded according to our business rules.
    """

    def __init__(self, machine, machine_urls):
        super().__init__()
        self.machine = machine
        self.click_required = None
        self.machine_urls = machine_urls
        self.current_url = None
        self.fail_machine = {}
        self.extract_failure_analysis = []
        self.validator = ValidateData(machine=self.machine)

    def set_machine(self, machine):
        self.machine = machine

    @retry(stop=stop_after_attempt(3))
    def fetch_page(self, url):
        self.driver.get(url)
        html_content = self.driver.page_source
        self.soup = BeautifulSoup(html_content, "html.parser")
        self.fail_machine = {url: []}

    def selenium_extract(self, xpath, fail_key, _=None):
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            text = element.text.strip()
            if not text:
                self.fail_machine.setdefault(self.current_url, []).append(fail_key)
                return None
            return text
        except NoSuchElementException:
            self.fail_machine.setdefault(self.current_url, []).append(fail_key)
            return None

    def bs4_select_one_extract(self, css_selector, fail_key, _=None):
        element = self.soup.select_one(css_selector)
        if element is None:
            self.fail_machine[self.current_url].append(fail_key)
            return None
        text = element.text.strip()
        return text

    def bs4_find_extract(self, tag_name, class_name, fail_key):
        element = self.soup.find(tag_name, class_=class_name)
        if element is None:
            self.fail_machine[self.current_url].append(fail_key)
            return None
        text = element.text.strip()
        return text

    def choice_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key=None,
    ):
        if extract_method == "selenium":
            return self.selenium_extract(xpath, fail_key)
        elif extract_method == "bs4_select_one":
            return self.bs4_select_one_extract(css_selector, fail_key)
        elif extract_method == "bs4_find":
            return self.bs4_find_extract(tag_name, class_name, fail_key)
        else:
            raise ValueError("Invalid extract method specified.")

    @staticmethod
    def crawl_date_extract():
        now = datetime.now()
        return now.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def year_reference_extract(crawl_date):
        return crawl_date.year

    @staticmethod
    def month_reference_extract(crawl_date):
        return crawl_date.month

    def url_extract(self):
        return self.current_url

    def model_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="model_extract",
    ):
        model_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return model_text if model_text else None

    def brand_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="brand_extract",
    ):
        model_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return model_text if model_text else None

    def year_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="year_extract",
    ):
        year_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return year_text if year_text else None

    def year_fabrication_extract(
        self,
        extract_method=None,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="year_fabrication_extract",
    ):
        year_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return year_text if year_text else None

    def price_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="price_extract",
    ):
        price_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return price_text if price_text else None

    def description_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="description_extract",
    ):
        description_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return description_text if description_text else None

    def title_extract(
        self,
        extract_method,
        xpath=None,
        css_selector=None,
        tag_name=None,
        class_name=None,
        fail_key="title_extract",
    ):
        title_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return title_text if title_text else None

    def mileage_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="mileage_extract",
    ):
        mileage_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return mileage_text if mileage_text else None

    def city_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="city_extract",
    ):
        city_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return city_text if city_text else None

    def state_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="state_extract",
    ):
        state_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return state_text if state_text else None

    def fuel_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="fuel_extract",
    ):
        fuel_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return fuel_text if fuel_text else None

    def gear_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="gear_extract",
    ):
        gear_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return gear_text if gear_text else None

    def bodywork_extract(
            self,
            extract_method,
            xpath=None,
            css_selector=None,
            tag_name=None,
            class_name=None,
            fail_key="bodywork_extract",
    ):
        bodywork_text = self.choice_extract(
            extract_method, xpath, css_selector, tag_name, class_name, fail_key
        )
        return bodywork_text if bodywork_text else None

    def extract(self, extract_methods):

        crawl_date = datetime.now()
        machine_list = []
        extract_failure_analysis = []
        ads_discarded = []

        for url in self.machine_urls:
            self.current_url = url
            try:
                self.fetch_page(url)
                self.click_required = True
            except RetryError as e:
                return {"error": "RetryError", "message": str(e)}, [], []

            raw_data = {
                "price": self.price_extract(**extract_methods["price"]),
                "brand": (
                    self.brand_extract(**extract_methods["brand"])
                    if "brand" in extract_methods
                    else None
                ),
                "year_model": (
                    self.year_extract(**extract_methods["year_model"])
                    if "year_model" in extract_methods
                    else None
                ),
                "title": self.title_extract(**extract_methods["title"]),
                "description": self.description_extract(
                    **extract_methods["description"]
                ),
                "model": self.model_extract(**extract_methods["model"]),
                "year_fabrication": (
                    self.year_fabrication_extract(**extract_methods["year_fabrication"])
                    if "year_fabrication" in extract_methods
                    else None
                ),
                "mileage": (
                    self.mileage_extract(**extract_methods["mileage"])
                    if "mileage" in extract_methods
                    else None
                ),
                "city": (
                    self.city_extract(**extract_methods["city"])
                    if "city" in extract_methods
                    else None
                ),
                "state": (
                    self.state_extract(**extract_methods["state"])
                    if "state" in extract_methods
                    else None
                ),
                "fuel": (
                    self.fuel_extract(**extract_methods["fuel"])
                    if "fuel" in extract_methods
                    else None
                ),
                "gear": (
                    self.gear_extract(**extract_methods["gear"])
                    if "gear" in extract_methods
                    else None
                ),
                "bodywork": (
                    self.bodywork_extract(**extract_methods["bodywork"])
                    if "bodywork" in extract_methods
                    else None
                ),
                "url": self.url_extract(),
                "crawl_date": self.crawl_date_extract(),
                "year_reference": self.year_reference_extract(crawl_date),
                "month_reference": self.month_reference_extract(crawl_date),
            }
            logging.info(f"Raw data extracted: {raw_data}")

            try:

                # The apply_normalize method returns an empty list (without the raw_data dict) in case the ad was
                # discarded at the beginning by the sanitization methods that discard ads that do not have
                # required fields.

                normalized_data = self.validator.apply_normalize([raw_data])
                if normalized_data:
                    normalized_data = normalized_data[0]
                    valid_data, invalid_data = self.validator.apply_business_rules(
                        [normalized_data]
                    )

                    if valid_data:
                        logger.info(
                            f"BASE EXTRACT: Dados prontos para serem salvos: {valid_data}"
                        )
                        machine_list.append(valid_data[0])
                    else:
                        logger.info("BASE EXTRACT Todos os dados foram descartados.")

                    if invalid_data:
                        logger.info(f"BASE EXTRACT Dados não validados: {invalid_data}")
                        ads_discarded.append(invalid_data[0])

                else:
                    print(
                        "Nenhum dado foi normalizado. Verifique as condições de descarte."
                    )
            except IndexError as e:
                return {"error": "RetryError", "message": str(e)}, [], []
            # Cleaning, sanitizing and processing data to be validated according to
            # business rules

            # normalized_data = self.validator.apply_normalize([raw_data])[0]
            # valid_data, invalid_data = self.validator.apply_business_rules([normalized_data])

        self.driver.quit()
        logging.info(f"Extraction completed.")
        logging.info(f"Total extracted ads: {len(machine_list)}")
        logging.info(f"Extraction failures: {len(extract_failure_analysis)}")
        logging.info(f"Discarded ads: {len(ads_discarded)}")

        return machine_list, extract_failure_analysis, ads_discarded
