import asyncio
import logging

from celery.result import AsyncResult

from fastapi import HTTPException

from apps.core.db_manager import DatabaseManager
from apps.core.excel_generator import ExcelGenerator


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def _run_async_task(db_manager):
    try:
        result = await db_manager.assign_code_model()
        return f"Code models assigned successfully. Result: {result}"
    except Exception as e:
        return f"Error while assigning code models: {str(e)}"


async def fetch_filtered_data(machine, brand=None, model=None, page=1, page_size=10):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    db_manager = DatabaseManager(machine, loop)
    data = await db_manager.get_filtered_data(
        brand=brand, model=model, page=page, page_size=page_size
    )
    return data


def generate_xlsx_from(task_id: str, machine: str):
    task_result = AsyncResult(task_id)

    if task_result.state != "SUCCESS":
        raise HTTPException(
            status_code=400, detail="A tarefa ainda não foi concluída ou falhou."
        )

    data = task_result.result.get("records", [])

    if not data:
        raise HTTPException(
            status_code=404,
            detail="Nenhum dado retornado na consulta, portanto não será possível gerar o Excel.",
        )

    excel_generator = ExcelGenerator(machine=machine)
    response = excel_generator.generate(data)

    return response
