from uuid import UUID
from typing import List

from pydantic import BaseModel, validator


class RecordData(BaseModel):
    price: str
    description: str
    mileage: float
    title: str

    @validator('price')
    def price_must_be_digits(cls, value):
        if not value.isdigit():
            raise ValueError('O preço deve conter apenas digitos, sem pontuações ou '
                             'outros caractéres')
        return value


class RecordRequest(BaseModel):
    record_id: UUID
    data: RecordData


class RecordsDataRequest(BaseModel):
    records: List[RecordRequest]


class ReferenceDate(BaseModel):
    reference_year: int
    reference_month: int


class ReferenceDatesRequest(BaseModel):
    reference_dates: List[ReferenceDate]
