import json
import uuid
import logging
from typing import List, Dict, Any

from pytz import timezone
from tortoise.expressions import Q
from tortoise.transactions import in_transaction

from apps.core.models import MachineTable


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManager:

    def __init__(self, machine, loop):
        self.machine = machine
        self.machine_tables = {
            "machine": MachineTable,
        }
        self.loop = loop

    def get_current_record_count(self):
        table = self.machine_tables.get(self.machine, None)
        if table is not None:
            return self.loop.run_until_complete(table.all().count())
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    def save_to_database(self, data):
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

        # Criar um conjunto de URLs que precisam ser verificadas
        urls = [item["url"] for item in data]

        # Consultar itens existentes de uma vez
        existing_items = self.loop.run_until_complete(table.filter(url__in=urls).all())

        # Criar um dicionário de URLs existentes para consulta rápida
        existing_urls = {item.url: item for item in existing_items}

        # Preparar os itens a serem criados
        items_to_create = []
        for item in data:
            existing_item = existing_urls.get(item["url"])
            if not existing_item or existing_item.price != item["price"]:
                items_to_create.append(self.create_new_instance(item))

        # Inserir os itens criados
        if items_to_create:
            self.loop.run_until_complete(table.bulk_create(items_to_create))

    def create_new_instance(self, item):
        table = self.machine_tables.get(self.machine, None)
        logger.info(f"MÈTODO CREATE NEW INSTANCE Item: {item}")
        if table is not None:
            return table(
                crawl_date=item["crawl_date"],
                model=item["model"],
                url=item["url"],
                price=item["price"],
                brand=item["brand"],
                year_model=item["year_model"],
                description=item["description"],
                title=item.get("title"),
                year_fabrication=item.get("year_fabrication"),
                mileage=item.get("mileage"),
                city=item.get("city"),
                state=item.get("state"),
                fuel=item.get("fuel"),
                gear=item.get("gear"),
                bodywork=item.get("bodywork"),
                code_model=item.get("code_model"),
                year_reference=item.get("year_reference"),
                month_reference=item.get("month_reference"),
            )
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    def save_data_and_get_new_record_count(self, data):
        initial_count = self.get_current_record_count()
        self.save_to_database(data)
        final_count = self.get_current_record_count()
        return final_count - initial_count

    def count_records_with_null_model_code(self):
        table = self.machine_tables.get(self.machine, None)
        if table is not None:
            records_with_null_model_code = self.loop.run_until_complete(
                table.filter(code_model=None).count()
            )
            return records_with_null_model_code
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def get_all_data(self):
        table = self.machine_tables.get(self.machine, None)
        if table is not None:
            machines = await table.all().values()
            for machine in machines:
                fields = ["crawl_date", "created_at", "updated_at"]
                machine["crawl_date"], machine["created_at"], machine["updated_at"] = (
                    map(
                        lambda field: machine[field]
                        .astimezone(timezone("America/Sao_Paulo"))
                        .replace(tzinfo=None),
                        fields,
                    )
                )

            return machines
        else:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

    async def assign_code_model(self):
        # Obtém a tabela correspondente com base no atributo `machine`
        table = self.machine_tables.get(self.machine)
        if not table:
            raise ValueError(f"No corresponding table for the machine: {self.machine}")

        def get_machine_prefix(machine):
            prefixes = {
                "machine": "MC",
            }
            return prefixes.get(machine, "XX")

        # Define o prefixo da `machine`
        prefix = get_machine_prefix(self.machine)

        # Query para atribuir o code_model
        query = f"""
            WITH group_records AS (
    SELECT
        model,
        COUNT(*) AS record_count
    FROM {table._meta.db_table}
    WHERE is_active = TRUE
    GROUP BY model
),
existing_code_models AS (
    SELECT
        model,
        MIN(code_model) AS existing_code_model
    FROM {table._meta.db_table}
    WHERE is_active = TRUE AND code_model IS NOT NULL
    GROUP BY model
),
max_code_model AS (
    SELECT
        COALESCE(MAX(CAST(SUBSTRING(code_model, {len(prefix) + 1}) AS INTEGER)), 0) AS max_code_number
    FROM {table._meta.db_table}
    WHERE code_model LIKE '{prefix}%'
),
new_code_models AS (
    SELECT
        gr.model,
        COALESCE(ecm.existing_code_model,
                 '{prefix}' || LPAD((max_code_model.max_code_number + ROW_NUMBER() OVER (ORDER BY gr.model))::TEXT, 5, '0')
        ) AS code_model
    FROM group_records gr
    LEFT JOIN existing_code_models ecm
        ON gr.model = ecm.model
    CROSS JOIN max_code_model
)
SELECT
    pt.id,
    pt.model,
    ncm.code_model
FROM {table._meta.db_table} pt
JOIN new_code_models ncm
    ON pt.model = ncm.model
WHERE pt.is_active = TRUE;

        """

        # Executa a query e atualiza o code_model dos registros
        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query)

            # Atualiza cada registro com o code_model atribuído
            for record in result:
                await table.filter(id=record["id"]).update(
                    code_model=record["code_model"]
                )

        return result

    async def get_records(
        self,
        offset: int,
        limit: int,
        reference_dates: List[Dict[str, int]],
        code_model: str = None,
    ):
        if not all(
            isinstance(date, dict)
            and "reference_month" in date
            and "reference_year" in date
            for date in reference_dates
        ):
            raise ValueError(f"Invalid format for reference_dates: {reference_dates}")

        filter_conditions = "WHERE is_active = TRUE"

        date_conditions = []
        for date_params in reference_dates:
            reference_year = date_params["reference_year"]
            reference_month = date_params["reference_month"]
            date_conditions.append(
                f"(year_reference = {reference_year} AND month_reference = {reference_month})"
            )

        filter_conditions += " AND (" + " OR ".join(date_conditions) + ")"

        if code_model:
            filter_conditions += f" AND code_model = '{code_model}'"

        query = f"""
            SELECT *
            FROM {self.machine_tables[self.machine]._meta.db_table}
            {filter_conditions}
            LIMIT {limit} OFFSET {offset};
        """

        logger.info(f"Executing query: {query}")

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query)

        logger.info(f"Query result: {result}")
        return result

    async def get_record(self, record_id: uuid.UUID):
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"No corresponding table found for machine: {self.machine}"
            )
        record = await table.filter(id=record_id, is_active=True).first()
        return record

    async def save_to_database_async(self, data):
        table = self.machine_tables.get(self.machine)
        if table is None:
            raise ValueError(f"No table found for machine: {self.machine}")

        items_to_create = []
        logger.info("MÉTODO SAVE TO DATABASE ASYNC")
        logger.info(f"Data: {data}")
        for item in data:
            existing_item = await table.filter(url=item["url"]).first()
            if existing_item:
                if existing_item.price != item["price"]:
                    logger.info("MÈTODO SALVAR ASYNC")
                    logger.info(f"Item existente: {existing_item}")
                    items_to_create.append(self.create_new_instance(item))
            else:
                items_to_create.append(self.create_new_instance(item))

        if items_to_create:
            await table.bulk_create(items_to_create)

    async def get_filtered_data(self, brand=None, model=None, page=1, page_size=10):
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}"
            )

        offset = (page - 1) * page_size

        # Filtros iniciais
        filters = Q(is_active=True)

        if brand:
            filters &= Q(brand=brand.upper())
        if model:
            filters &= Q(model=model.upper())

        if not model and not brand:
            query = (
                await table.filter(filters)
                .distinct()
                .offset(offset)
                .limit(page_size)
                .order_by("brand")
                .values("brand")
            )
        elif brand and not model:
            query = (
                await table.filter(filters)
                .distinct()
                .offset(offset)
                .limit(page_size)
                .order_by("model")
                .values("model")
            )
        elif brand and model:
            query = (
                await table.filter(filters)
                .distinct()
                .offset(offset)
                .limit(page_size)
                .order_by("year_model", "code_model")
                .values("year_model", "code_model")
            )

        return query

    async def general_kpi(self, year_reference: int,
                          month_reference: int) -> Dict[str, float]:
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}")

        query = f"""
                WITH price_freq AS (
    SELECT price, COUNT(*) as freq
    FROM {table._meta.db_table}
    WHERE year_reference = {year_reference} 
      AND month_reference = {month_reference} 
      AND is_active = TRUE
    GROUP BY price
    ORDER BY freq DESC
    LIMIT 10
),
year_model_freq AS (
    SELECT year_model, COUNT(*) as freq
    FROM {table._meta.db_table}
    WHERE year_reference = {year_reference} 
      AND month_reference = {month_reference} 
      AND is_active = TRUE
    GROUP BY year_model
    ORDER BY freq DESC
    LIMIT 10
)
SELECT
    COUNT(*) AS total_ads,
    (SELECT year_model FROM year_model_freq LIMIT 1) AS most_frequent_year_model,
    COALESCE(AVG(price), 0) AS total_average_price,
    (SELECT JSONB_AGG(jsonb_build_object('price', price, 'frequency', freq) ORDER BY freq DESC) FROM price_freq) AS top_10_price_distribution,
    (SELECT JSONB_AGG(jsonb_build_object('year_model', year_model, 'frequency', freq) ORDER BY freq DESC) FROM year_model_freq) AS top_10_year_model_distribution
FROM {table._meta.db_table}
WHERE year_reference = {year_reference} 
  AND month_reference = {month_reference} 
  AND is_active = TRUE;

            """

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query)

        if result:
            return {
                "total_ads": result[0]["total_ads"],
                "most_frequent_year_model": int(result[0]["most_frequent_year_model"]) if result[0][
                                                                                              "most_frequent_year_model"] is not None else 0,
                "total_average_price": round(result[0]["total_average_price"], 2) if result[0][
                                                                                         "total_average_price"] is not None else 0.0,
                "top_10_price_distribution": json.loads(result[0]["top_10_price_distribution"]) if result[0][
                    "top_10_price_distribution"] else {},
                "top_10_year_model_distribution": json.loads(result[0]["top_10_year_model_distribution"]) if result[0][
                    "top_10_year_model_distribution"] else {}
            }
        else:
            return {
                "total_ads": 0,
                "most_frequent_year_model": 0,
                "total_average_price": 0.0,
                "top_10_price_distribution": {},
                "top_10_year_model_distribution": {}
            }

    async def geographic_pricing_analysis(
            self, year_reference: int, month_reference: int) -> Dict[str, Any]:
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}")

        query = f"""
                SELECT state, COUNT(*) AS total_ads, ROUND(AVG(price), 2) AS average_price
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY state
                ORDER BY total_ads DESC
                LIMIT 10;
            """

        async with in_transaction() as connection:
            result = await connection.execute_query_dict(query)

        return {
            "top_10_states": [
                {
                    "state": row["state"],
                    "total_ads": row["total_ads"],
                    "average_price": row["average_price"]
                }
                for row in result
            ]
        }

    async def brand_model_analysis(
            self, year_reference: int, month_reference: int) -> Dict[str, Any]:
        table = self.machine_tables.get(self.machine, None)
        if table is None:
            raise ValueError(
                f"There are no corresponding tables for this machine: {self.machine}")

        queries = {
            "brands_with_most_ads": f"""
                SELECT brand, COUNT(*) AS total_ads
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY brand
                ORDER BY total_ads DESC;
            """,
            "average_price_by_brand": f"""
                SELECT brand, ROUND(AVG(price), 2) AS average_price
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY brand
                ORDER BY average_price DESC;
            """,
            "price_distribution_by_gear_bodywork": f"""
                SELECT gear, bodywork, COUNT(*) AS total_ads, ROUND(AVG(price), 2) AS average_price
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY gear, bodywork
                ORDER BY total_ads DESC;
            """,
            "price_by_car_age": f"""
                SELECT (year_reference - year_model) AS car_age, COUNT(*) AS total_ads, ROUND(AVG(price), 2) AS average_price
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY car_age
                ORDER BY car_age ASC;
            """,
            "price_by_car_age_fuel": f"""
                SELECT (year_reference - year_model) AS car_age, fuel, COUNT(*) AS total_ads, ROUND(AVG(price), 2) AS average_price
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE
                GROUP BY car_age, fuel
                ORDER BY car_age ASC;
            """,
            "correlation_matrix": f"""
                SELECT CORR(price, mileage) AS price_mileage_corr,
                       CORR(price, (year_reference - year_model)) AS price_age_corr
                FROM {table._meta.db_table}
                WHERE year_reference = {year_reference}
                  AND month_reference = {month_reference}
                  AND is_active = TRUE;
            """
        }

        async with in_transaction() as connection:
            results = {}
            for key, query in queries.items():
                results[key] = await connection.execute_query_dict(query)

        return results
