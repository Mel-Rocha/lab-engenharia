import uuid

from tortoise import fields, Model


class Core(Model):
    id = fields.UUIDField(pk=True, default=uuid.uuid4)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)
    is_active = fields.BooleanField(default=True)

    class Meta:
        abstract = True


class CoreTable(Core):
    price = fields.DecimalField(max_digits=18, decimal_places=2, null=True)
    brand = fields.CharField(max_length=255, null=True)
    url = fields.CharField(max_length=255, index=True)
    crawl_date = fields.DatetimeField(auto_now=True)
    year_reference = fields.IntField(null=True)
    month_reference = fields.IntField(null=True)
    description = fields.CharField(max_length=600, null=True)
    code_model = fields.CharField(max_length=50, null=True)
    model = fields.CharField(max_length=255, null=True)
    year_fabrication = fields.IntField(null=True)
    year_model = fields.IntField(null=True)
    title = fields.CharField(max_length=255, null=True)
    mileage = fields.DecimalField(max_digits=18, decimal_places=3, null=True)
    city = fields.CharField(max_length=50, null=True)
    state = fields.CharField(max_length=6, null=True)
    fuel = fields.CharField(max_length=50, null=True)
    gear = fields.CharField(max_length=50, null=True)
    bodywork = fields.CharField(max_length=50, null=True)

    class Meta:
        abstract = True


class MachineTable(CoreTable):
    pass
