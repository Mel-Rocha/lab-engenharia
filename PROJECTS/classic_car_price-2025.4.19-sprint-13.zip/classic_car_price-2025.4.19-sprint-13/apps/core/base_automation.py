import time
import logging
from abc import ABC
from random import uniform

from lxml import etree
from bs4 import BeautifulSoup
from tenacity import stop_after_attempt, retry
from selenium.common import NoSuchElementException
from selenium.common.exceptions import TimeoutException

from apps.core.core_automation import CoreAutomation

logging.basicConfig(level=logging.INFO)


class BaseAutomation(CoreAutomation, ABC):
    def __init__(
        self,
        machine,
        machine_urls,
        all_elements_class=None,
        element_type_tag=None,
        base_url=None,
        css_selector=None,
        xpath=None,
    ):

        super().__init__()
        self.old_len = 0
        self.metrics = []
        self.machine = machine
        self.machine_urls = machine_urls
        self.all_elements_class = all_elements_class
        self.element_type_tag = element_type_tag
        self.base_url = base_url
        self.xpath = xpath
        self.css_selector = css_selector

    @staticmethod
    def automation_validation(page_number, num_all_elements, current_url_all, old_len):
        num_urls_extracted = len(current_url_all) - old_len
        print(f"Número da Página: {page_number}")
        print(f"Quantidade de Veículos: {num_all_elements}")
        print(f"Quantidade de URLs extraídas: {num_urls_extracted}")

        validation_dict = {
            "page_number": page_number,
            "ads_found": num_all_elements,
            "extracted_urls": num_urls_extracted,
        }

        return validation_dict

    @retry(stop=stop_after_attempt(3))
    def access_url(self):
        self.driver.get(self.machine_urls.get(self.machine, ""))

    @retry(stop=stop_after_attempt(3))
    def machine_url_all(self, unique_page=False, page_name_param=None, page_number=0):
        current_url_all = []

        try:
            while True:
                url_page_list = self.machine_urls.get(self.machine, "")
                if page_name_param is not None:
                    url_page_list += f"?{page_name_param}={page_number}"
                (logging.info(f"Acessando URL: {url_page_list}"))
                self.driver.get(url_page_list)

                html_content = self.driver.page_source
                soup = BeautifulSoup(html_content, "html.parser")

                if self.xpath:
                    # Converte para lxml e faz a busca com XPath
                    dom = etree.HTML(str(soup))
                    all_elements = dom.xpath(self.xpath)
                elif self.css_selector:
                    # Busca usando o seletor CSS
                    all_elements = soup.select(self.css_selector)
                else:
                    # Busca usando find_all com tag e classe
                    all_elements = soup.find_all(
                        self.element_type_tag, class_=self.all_elements_class
                    )

                num_all_elements = len(all_elements)

                if not all_elements:
                    break

                self.old_len = len(current_url_all)

                for element in all_elements:
                    try:
                        if self.element_type_tag == "a":
                            a_tag = element
                        else:
                            a_tag = element.find("a")

                        if a_tag and "href" in a_tag.attrs:
                            url = (
                                a_tag["href"]
                                if self.base_url is None
                                else f"{self.base_url}{a_tag['href']}"
                            )
                            current_url_all.append(url)
                            logging.info(f"URL extraída: {url}")
                        else:
                            logging.error(
                                "Tag <a> não encontrada ou sem atributo href."
                            )
                            continue
                    except TimeoutException as e:
                        print(f"Erro ao clicar na imagem: Tempo de execução limite {e}")
                        logging.error(
                            "O elemento foi encontrado, mas não se tornou visível dentro do tempo limite."
                        )
                        continue
                    except NoSuchElementException as e:
                        print(f"Erro ao clicar na imagem: Imagem não encontrada {e}.")
                        logging.error("O elemento não foi encontrado.")
                        continue

                    self.driver.back()
                    time.sleep(uniform(1.8, 2.5))

                metrics = self.automation_validation(
                    page_number, num_all_elements, current_url_all, self.old_len
                )
                self.metrics.append(metrics)

                if unique_page:
                    break
                page_number += 1

        finally:
            super().stop_driver()

            print(self.metrics)
            return current_url_all, self.metrics
