from unittest.mock import MagicMock

import pytest

from apps.core.data_validate import ValidateData
from apps.core.data_processing import NormalizeData, BusinessRules


@pytest.fixture
def validate_data():
    """Cria uma instância de ValidateData com dependências mockadas."""
    machine_mock = MagicMock()  # Mock da máquina de crawling
    validator = ValidateData(machine_mock)
    validator.normalizer = MagicMock(spec=NormalizeData)  # Mock do normalizador
    return validator


def test_apply_normalize(validate_data):
    """Testa se apply_normalize normaliza corretamente os dados."""
    raw_data = [
        {
            "price": "R$ 50.000,00",
            "year_model": "2022",
            "mileage": "50.000 km",
            "title": "Carro super novo!",
            "description": "Ótimo estado, baixa quilometragem!",
        }
    ]

    validate_data.normalizer.normalize_price.return_value = 50000
    validate_data.normalizer.normalize_year.return_value = 2022
    validate_data.normalizer.normalize_mileage.return_value = 50000
    validate_data.normalizer.util_clean_data_all.return_value = raw_data[0]
    validate_data.normalizer.truncate_title.return_value = "Carro super novo!"
    validate_data.normalizer.truncate_description.return_value = "Ótimo estado"

    result = validate_data.apply_normalize(raw_data)

    assert result[0]["price"] == 50000
    assert result[0]["year_model"] == 2022
    assert result[0]["mileage"] == 50000
    assert result[0]["description"] == "Ótimo estado"


def test_apply_business_rules(validate_data):
    """Testa a aplicação das regras de negócio."""
    normalized_data = [
        {
            "price": 50000,
            "year_model": 2022,
            "model": None,
            "title": "Carro XYZ",
            "description": "Ótimo carro, modelo 2022!",
        }
    ]

    BusinessRules.infer_missing_model = MagicMock(return_value="Carro XYZ")
    BusinessRules.price_cutoff_value = MagicMock(return_value=50000)
    BusinessRules.should_discard = MagicMock(return_value=False)

    validated, invalidated = validate_data.apply_business_rules(normalized_data)

    assert len(validated) == 1
    assert validated[0]["model"] == "Carro XYZ"


def test_apply_business_rules_invalid(validate_data):
    """Testa se dados inválidos são descartados corretamente."""
    normalized_data = [
        {
            "price": None,  # Falha proposital
            "year_model": None,
            "model": None,
            "title": "Carro XYZ",
            "description": "Ótimo carro, modelo 2022!",
        }
    ]

    BusinessRules.infer_missing_model = MagicMock(return_value=None)
    BusinessRules.price_cutoff_value = MagicMock(return_value=None)
    BusinessRules.should_discard = MagicMock(return_value=True)

    validated, invalidated = validate_data.apply_business_rules(normalized_data)

    assert len(validated) == 0
    assert len(invalidated) == 1
