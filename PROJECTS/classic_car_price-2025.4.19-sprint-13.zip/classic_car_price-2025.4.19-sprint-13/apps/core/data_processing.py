import re
import unicodedata
from decimal import Decimal
from datetime import datetime


class NormalizeData:
    """
    Responsável pelo processamento e preparação dos dados para persistência.  Esta classe assegura que os dados
    sejam devidamente tratados,  incluindo a limpeza, formatação, sanitização, normalização e truncamento.
    O objetivo é garantir que todas as informações estejam no formato, tipo e tamanho adequado, atendendo aos
    requisitos do banco de dados, para que possam ser armazenadas de forma consistente e segura.
    """

    @staticmethod
    def truncate(text, max_length):
        """
        Ajusta o tamanho do dado para que não ultrapasse o tamanho limite estabelecido na
        tabela do banco, evitando assim problemas na etapa de persistência de dados

        :param text: Texto a ser ajustado
        :param max_length: Comprimento máximo estabelecido na model
        :return: Texto ajustado
        """
        if len(text) > max_length:
            return text[:max_length]
        return text

    def truncate_description(self, description):
        return self.truncate(description, max_length=550)

    def truncate_model(self, model):
        return self.truncate(model, max_length=220)

    def truncate_brand(self, brand):
        return self.truncate(brand, max_length=220)

    def truncate_title(self, title):
        return self.truncate(title, max_length=220)

    def truncate_city(self, city):
        return self.truncate(city, max_length=45)

    def truncate_state(self, state):
        return self.truncate(state, max_length=5)

    def truncate_fuel(self, fuel):
        return self.truncate(fuel, max_length=45)

    def truncate_gear(self, gear):
        return self.truncate(gear, max_length=45)

    def truncate_bodywork(self, bodywork):
        return self.truncate(bodywork, max_length=45)

    @staticmethod
    def normalize_price(price_text, divider=1):
        price_text = price_text.lower()
        # Remove any occurrences of "ano" or "ano-modelo" followed by a 4-digit number
        price_text = re.sub(r"\b(ano|ano de|ano-modelo)\b.*?\d{4}", "", price_text)
        # Find all digit sequences in the remaining text
        price_digits = "".join(re.findall(r"\d", price_text))
        if not price_digits or len(price_digits) > 15:
            return None
        if re.search(r",\d{2}\b", price_text):
            divider = 100
        price_value = Decimal(price_digits) / divider
        return price_value

    @staticmethod
    def normalize_year(year_text):
        year_text = re.sub(
            r"R\$ \d+", "", year_text
        )  # Remove preços precedidos por "R$"
        year_text = re.sub(
            r"\bRS \d+\b", "", year_text
        )  # Remove preços precedidos por "RS"

        # Verifica se existe um ano de 4 dígitos (sem R$ ou RS precedendo)
        year_digits = re.findall(r"\b\d{4}\b", year_text)

        if year_digits:
            return int(year_digits[0])

        short_year = re.findall(r"(?<![R\$])(?<!\$)\b\d{2}/\d{2}\b", year_text)
        two_digits_year = re.findall(r"(?<![R\$])(?<!\$)\b\d{2}\b", year_text)

        if two_digits_year:
            short_year = two_digits_year

        if short_year:
            year_short = int(short_year[0].split("/")[0])

            current_year = datetime.now().year
            current_century = current_year // 100 * 100
            """convenção arbitrária anos menores que 30 estão no séc 21"""
            century = current_century if year_short < 30 else current_century - 100
            return century + year_short

        return None

    @staticmethod
    def normalize_mileage(mileage_text, divider=1):
        mileage_digits = "".join(re.findall(r"\d", mileage_text))

        if not mileage_digits:
            return None

        if len(mileage_digits) > 14:
            return None

        mileage_value = Decimal(mileage_digits) / divider
        return mileage_value

    @staticmethod
    def util_clean_data(data):
        preprocessed_data = data.replace(
            "\n",
            " ").replace(
            "\xa0",
            " ").replace(
            ":",
            "").strip()
        normalized_whitespace_data = " ".join(preprocessed_data.split())
        ascii_converted_data = unicodedata.normalize(
            'NFKD', normalized_whitespace_data).encode(
            'ASCII', 'ignore').decode('ASCII')
        cleaned_data = ascii_converted_data.upper()
        return cleaned_data

    def util_clean_data_all(self, raw_data: dict) -> dict:
        """
        Limpa, sanitiza e padroniza as strings em letras maiúsculas, sem acentuação.

        :param raw_data: Dicionário com os dados brutos da máquina.
        :return: Dicionário com os campos normalizados.
        """
        # Limpa e normaliza os campos necessários, caso estejam no dicionário
        for field in ["description", "title", "model", "brand", "city",
                      "state", "fuel", "gear", "bodywork"]:
            if field in raw_data and raw_data[field]:
                raw_data[field] = self.util_clean_data(raw_data[field])

        return raw_data


class BusinessRules:
    """
    Objetivo: Validar dados já sanitizados, verificando se atendem às regras de negócio

    Processo: Os dados podem ser descartados, inferidos ou mapeados, para atender às regras de negócios.
    """

    FUEL_GROUPS = {
        "FLEX": ["FLEX", "A/G", "AG", "ALCOOL/GASOLINA", "ALCOOL GASOLINA", "F"],
        "ALCOOL": ["ALCOOL", "A"],
        "GASOLINA": ["GASOLINA", "G"],
        "DIESEL": ["DIESEL", "D"],
        "GNV": ["GNV", "GAS NATURAL"],
        "ELETRICO": ["ELETRICO", "ELET", "EV", "E"],
        "HIBRIDO": ["HIBRIDO", "H"],
    }

    GEAR_GROUPS = {
        "AUTOMATICO": ["AUTOMATICO", "AUTO"],
        "MANUAL": ["MANUAL", "MT"],
        "AUTOMATIZADO": ["AUTOMATIZADO"],
        "CVT": ["CVT", "TRANSMISSAO CONTINUAMENTE VARIAVEL"],
        "DUPLA EMBREAGEM": ["DSG", "DUALOGIC", "POWERSHIFT", "AUTOMATIZADO DE DUPLA EMBREAGEM"],
        "TIPTRONIC": ["TIPTRONIC", "AUTOMATICO SEQUENCIAL"],
        "SEMI-AUTOMATICO": ["SEMI-AUTOMATICO", "SEMI AUTOMATICO", "AMT"],
    }

    BODYWORK_GROUPS = {
        "HATCH": ["HATCH", "HATCHBACK"],
        "SEDAN": ["SEDAN", "SALOON", "SEDA"],
        "SUV": ["SUV", "UTILITARIO ESPORTIVO"],
        "PICAPE": ["PICAPE", "PICKUP", "CAMIONETE", "TRUCK"],
        "PICAPE CABINE SIMPLES": ["PICAPE C. SIMPLES", "PICAPE CABINE SIMPLES"],
        "PICAPE CABINE DUPLA": ["PICAPE C. DUPLA", "PICAPE CABINE DUPLA"],
        "CONVERSIVEL": ["CONVERSIVEL", "CABRIOLET", "CABRIO"],
        "COUPE": ["COUPE", "CUPE"],
        "MINIVAN": ["MINIVAN", "VAN"],
        "UTILITARIO": ["UTILITARIO"],
        "PERUA": ["PERUA", "WAGON", "STATION WAGON"],
    }

    @staticmethod
    def standardize_fuel(fuel: str) -> str or None:
        """
        Standardizes the fuel type based on predefined groups.

        :param fuel: A cleaned string representing the fuel type
        :return: Standardized fuel type or None if the input is not mapped
        """
        if not fuel:
            return None

        for standard, synonyms in BusinessRules.FUEL_GROUPS.items():
            if fuel in synonyms:
                return standard
        return None

    @staticmethod
    def standardize_gear(gear: str) -> str or None:
        """
        Standardizes the gear type based on predefined groups.

        :param gear: A cleaned string representing the gear type
        :return: Standardized gear type or None if the input is not mapped
        """
        if not gear:
            return None

        for standard, synonyms in BusinessRules.GEAR_GROUPS.items():
            if gear in synonyms:
                return standard
        return None

    @staticmethod
    def standardize_bodywork(bodywork: str) -> str or None:
        """
        Standardizes the bodywork type based on predefined groups.

        :param bodywork: A cleaned string representing the bodywork type
        :return: Standardized bodywork type or None if the input is not mapped
        """
        if not bodywork:
            return None

        for standard, synonyms in BusinessRules.BODYWORK_GROUPS.items():
            if bodywork in synonyms:
                return standard
        return None

    @staticmethod
    def should_discard(price, model, year_model) -> bool:
        """
        Discards ads that have certain null fields
        """
        return any(field is None for field in [price, model, year_model])

    @staticmethod
    def price_cutoff_value(price):
        if price < Decimal("5000"):
            return None
        return price

    @staticmethod
    def infer_missing_year(year_model, title, description):
        """
        Infers the year_model if it is missing, by extracting it from the title
        or description fields.

        :param year_model: Current value of year_model, possibly None
        :param title: The title string, possibly containing a year
        :param description: The description string, possibly containing a year
        :return: Inferred year_model, or the original year_model if no inference is possible
        """
        if year_model is None:
            if title is not None:
                inferred_year = NormalizeData.normalize_year(title)
                if inferred_year is not None:
                    return inferred_year

            if description is not None:
                inferred_year = NormalizeData.normalize_year(description)
                if inferred_year is not None:
                    return inferred_year

        return year_model

    @staticmethod
    def infer_missing_price(price, description):
        """
        Infers the price if it is missing, by extracting it from the description field.

        :param price: Current value of price, possibly None
        :param description: The description string, possibly containing a price
        :return: Inferred price, or the original price if no inference is possible
        """
        if price is None and description is not None:
            inferred_price = NormalizeData.normalize_price(description)
            if inferred_price is not None:
                return inferred_price

        return price

    @staticmethod
    def infer_missing_model(model, title):
        """
        Sets the model to the title if the model is missing.

        :param model: Current value of model, possibly None
        :param title: The title string, which will be used as the model if the model is None
        :return: The model, which will be set to the title if it was None
        """
        if model is None and title is not None:
            # Se o model for None, define o model com o valor do title
            model = title
        return model
