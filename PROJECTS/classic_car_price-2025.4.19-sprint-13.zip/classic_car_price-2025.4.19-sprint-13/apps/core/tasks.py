import asyncio
import logging
from datetime import datetime

from celery import shared_task, chain, group, chord

from apps.core.utils import _run_async_task
from apps.sites.olx.extract import OlxExtract
from apps.core.db_manager import DatabaseManager
from apps.sites.olx.automation import OlxAutomation
from apps.sites.usados_br.extract import UsadosBRExtract
from apps.sites.usados_br.automation import UsadosBRAutomation
from apps.sites.mercado_livre.extract import MercadoLivreExtract
from apps.calcs.tasks import calculate_averages, generate_report_task
from apps.sites.mercado_livre.automation import MercadoLivreAutomation


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BATCH_SIZE = 25

SITE_MAPPING = {
    "mercado_livre": {
        "automation_class": MercadoLivreAutomation,
        "extraction_class": MercadoLivreExtract,
    },
    "usados_br": {
        "automation_class": UsadosBRAutomation,
        "extraction_class": UsadosBRExtract,
    },
    "olx": {
        "automation_class": OlxAutomation,
        "extraction_class": OlxExtract,
    },
}

SITE_PARAMS = {
    "mercado_livre": {
        "unique_page": None,
        "page_name_param": None,
        "page_number": 1,
    },
    "usados_br": {
        "unique_page": None,
        "page_name_param": "pagina",
        "page_number": 1,
    },
    "olx": {
        "unique_page": None,
        "page_name_param": "o",
        "page_number": 1,
    },
}

MACHINE_SITES = {
    "machine": [
        "mercado_livre",
        "usados_br",
    ],  # removendo olx temporariamente, só porque está sendo bem ineficiente na extração de ads.
}


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def automation_task(self, site, machine, unique_page, page_name_param, page_number):
    try:
        machine_info = SITE_MAPPING[site]
        automation_class = machine_info["automation_class"]
        collect_urls = automation_class(machine)
        collected_urls, metrics = collect_urls.machine_url_all(
            unique_page=unique_page,
            page_name_param=page_name_param,
            page_number=page_number,
        )
        automation_result = {
            "collected_urls": collected_urls,
            "metrics": metrics,
        }
        logging.info(f"AUTOMATION RESULT: {automation_result}")
        return automation_result
    except Exception as e:
        logging.error(f"Error in automation_task: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def extract_task(self, result, site, machine):
    try:
        machine_info = SITE_MAPPING[site]
        extraction_class = machine_info["extraction_class"]
        collected_urls = result["collected_urls"]
        extraction = extraction_class(machine, collected_urls)
        extraction.set_machine(machine)
        data, extract_failure_analysis, discard_announcements = extraction.extract()

        metrics = result["metrics"] if "metrics" in result else []

        extract_result = {
            "data": data,
            "extract_failure_analysis": extract_failure_analysis,
            "discard_announcements": discard_announcements,
            "collected_urls": collected_urls,
            "metrics": metrics,
        }
        logging.info(f"EXTRACT RESULT: {extract_result}")
        return extract_result
    except Exception as e:
        logging.error(f"Error in extract_task: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def save_data_task(self, result, machine):
    try:
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        db_manager = DatabaseManager(machine, loop)
        data = result["data"]

        new_records_count = db_manager.save_data_and_get_new_record_count(data)
        records_with_null_model_code = db_manager.count_records_with_null_model_code()

        save_data_result = {
            "new_records_count": new_records_count,
            "records_with_null_model_code": records_with_null_model_code,
            "collected_urls": result["collected_urls"],
            "metrics": result["metrics"],
            "extract_failure_analysis": result["extract_failure_analysis"],
            "discard_announcements": result["discard_announcements"],
        }

        return save_data_result

    except Exception as e:
        logging.error(f"Error in save_data_task: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def aggregate_results_task(self, results):
    try:
        aggregated_result = {
            "collected_urls": 0,
            "metrics": [],
            "extract_failure_analysis": [],
            "discard_announcements": [],
            "new_records_count": 0,
            "records_with_null_model_code": 0,
        }

        metrics_by_page = {}
        max_records_with_null_model_code = 0

        for result in results:
            if "collected_urls" in result:
                aggregated_result["collected_urls"] += len(result["collected_urls"])
            if "metrics" in result:
                for metric in result["metrics"]:
                    page_number = metric.get("page_number")
                    if page_number is not None:
                        metrics_by_page[page_number] = metric
            if "extract_failure_analysis" in result:
                aggregated_result["extract_failure_analysis"].extend(
                    result["extract_failure_analysis"]
                )
            if "discard_announcements" in result:
                aggregated_result["discard_announcements"].extend(
                    result["discard_announcements"]
                )

            if "new_records_count" in result:
                aggregated_result["new_records_count"] += result["new_records_count"]
            if "records_with_null_model_code" in result:
                max_records_with_null_model_code = max(
                    max_records_with_null_model_code,
                    result["records_with_null_model_code"],
                )

        aggregated_result["metrics"] = list(metrics_by_page.values())
        aggregated_result["records_with_null_model_code"] = (
            max_records_with_null_model_code
        )

        logging.info(f"AGGREGATED RESULT: {aggregated_result}")
        return aggregated_result
    except Exception as e:
        logging.error(f"Error in aggregate_results_task: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def process_crawler(self, machine, site):
    try:
        start_time = datetime.now()

        # Armazenar resultados de todos os sites processados
        all_results = []

        logging.info(f"Starting processing for site: {site}")

        # Obtendo parâmetros específicos do site
        params = SITE_PARAMS.get(site)
        unique_page = params["unique_page"]
        page_name_param = params["page_name_param"]
        page_number = params["page_number"] if params["page_number"] else 0

        # Executando a automação e coletando os dados
        result = automation_task(
            site, machine, unique_page, page_name_param, page_number
        )
        collected_urls = result["collected_urls"]
        batches = [
            collected_urls[i : i + BATCH_SIZE]
            for i in range(0, len(collected_urls), BATCH_SIZE)
        ]

        # Configura o grupo de tarefas (task_group) para extrair e salvar dados
        task_group = group(
            chain(
                extract_task.s(
                    {"collected_urls": batch, "metrics": result["metrics"]},
                    site,
                    machine,
                ),
                save_data_task.s(machine),  # Passando a máquina como argumento
            )
            for batch in batches
        )

        # Executa o grupo de tarefas
        task_group_result = task_group.apply_async()

        # Armazenando o resultado do processo para cada site
        all_results.append(task_group_result.id)

        logging.info(f"Processing completed for site: {site}")

        # Finaliza o tempo de execução e calcula a duração
        end_time = datetime.now()
        execution_time = end_time - start_time
        execution_time_str = str(execution_time).split(".")[0]

        return {
            "result_ids": all_results,  # Lista de task_ids para todos os sites processados
            "execution_time": execution_time_str,
        }

    except Exception as e:
        logging.error(f"Error in process_crawler: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def full_process_orchestration(
    self, machine, site, year_reference=None, month_reference=None
):
    try:
        start_time = datetime.now()

        # Armazenar resultados de todos os sites processados
        all_results = []

        logging.info(f"Starting processing for site: {site}")

        # Obtendo parâmetros específicos do site
        params = SITE_PARAMS.get(site)
        unique_page = params["unique_page"]
        page_name_param = params["page_name_param"]
        page_number = params["page_number"] if params["page_number"] else 0

        # Executando a automação e coletando os dados
        result = automation_task(
            site, machine, unique_page, page_name_param, page_number
        )
        collected_urls = result["collected_urls"]
        batches = [
            collected_urls[i : i + BATCH_SIZE]
            for i in range(0, len(collected_urls), BATCH_SIZE)
        ]

        # Configura o grupo de tarefas (task_group) para extrair e salvar dados
        task_group = group(
            chain(
                extract_task.s(
                    {"collected_urls": batch, "metrics": result["metrics"]},
                    site,
                    machine,
                ),
                save_data_task.s(machine),  # Passando a máquina como argumento
            )
            for batch in batches
        )

        # Configura os callbacks
        callbacks = chain(
            assign_code_model_task.si(machine),
            calculate_averages.si(machine),
            generate_report_task.si(
                machine, year_reference, month_reference
            ),  # Passando parâmetros
        )

        # Criando o chord para agrupar os batches e chamar os callbacks
        final_chord = chord(task_group)(callbacks)

        # Armazenando o resultado do processo para cada site
        all_results.append(final_chord.id)

        logging.info(f"Processing completed for site: {site}")

        # Finaliza o tempo de execução e calcula a duração
        end_time = datetime.now()
        execution_time = end_time - start_time
        execution_time_str = str(execution_time).split(".")[0]

        return {
            "result_ids": all_results,  # Lista de task_ids para todos os sites processados
            "execution_time": execution_time_str,
        }

    except Exception as e:
        logging.error(f"Error in process_batch: {e}. Retrying...")
        raise self.retry(exc=e)


@shared_task(bind=True)
def assign_code_model_task(self, machine: str):
    try:
        # Obtém o loop de eventos associado ao worker
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop = asyncio.get_event_loop()

        # Inicializa o DatabaseManager com o loop atual
        db_manager = DatabaseManager(machine, loop)

        # Executa a corrotina usando o loop e await
        return loop.run_until_complete(_run_async_task(db_manager))

    except Exception as e:
        return f"An error occurred: {str(e)}"
