from apps.records.tasks import (
    fetch_records_task,
    duplicate_records_task,
    deactivate_records_task,
)
from apps.core.tasks import (
    automation_task,
    extract_task,
    save_data_task,
    aggregate_results_task,
    process_crawler,
    full_process_orchestration,
)
from apps.calcs.tasks import calculate_averages
import os
import logging
import asyncio

from celery import Celery
from dotenv import load_dotenv
from tortoise import Tortoise
from celery.signals import worker_process_init


logger = logging.getLogger(__name__)

load_dotenv()

celery_app = Celery(
    "tasks",
    broker=f"redis://{os.getenv('REDIS_HOST')}:{os.getenv('REDIS_PORT')}/0",
    backend=f"redis://{os.getenv('REDIS_HOST')}:{os.getenv('REDIS_PORT')}/0",
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="America/Sao_Paulo",
    enable_utc=True,
    result_expires=3600,
)


@worker_process_init.connect
def init_db(*args, **kwargs):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    loop.run_until_complete(
        Tortoise.init(
            db_url=os.getenv("DATABASE_URL"),
            modules={"models": ["apps.core.models", "apps.calcs.models"]},
        )
    )
    celery_app.autodiscover_tasks(["tasks"])
    logging.info(f"Discovered tasks: {celery_app.tasks.keys()}")
