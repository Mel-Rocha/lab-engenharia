#!/bin/bash

echo "Apply files migration"
aerich upgrade

echo "Start application"
exec uvicorn main:app --host 0.0.0.0 --port 8000
