from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS "machinetable" (
    "id" UUID NOT NULL  PRIMARY KEY,
    "created_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "is_active" BOOL NOT NULL  DEFAULT True,
    "price" DECIMAL(18,2),
    "brand" VARCHAR(255),
    "url" VARCHAR(255) NOT NULL,
    "crawl_date" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "year_reference" INT,
    "month_reference" INT,
    "description" VARCHAR(600),
    "code_model" VARCHAR(50),
    "model" VARCHAR(255),
    "year_fabrication" INT,
    "year_model" INT,
    "title" VARCHAR(255),
    "mileage" DECIMAL(18,3)
);
CREATE INDEX IF NOT EXISTS "idx_machinetabl_url_85e965" ON "machinetable" ("url");
CREATE TABLE IF NOT EXISTS "machinetableaverage" (
    "id" UUID NOT NULL  PRIMARY KEY,
    "created_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "is_active" BOOL NOT NULL  DEFAULT True,
    "code_model" VARCHAR(50) NOT NULL,
    "year_model" INT NOT NULL,
    "average" DECIMAL(18,2) NOT NULL,
    "reference_year" INT NOT NULL,
    "reference_month" INT NOT NULL,
    "ad_count" INT NOT NULL
);
CREATE TABLE IF NOT EXISTS "machine_table_average_ad_link" (
    "id" UUID NOT NULL  PRIMARY KEY,
    "created_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ NOT NULL  DEFAULT CURRENT_TIMESTAMP,
    "is_active" BOOL NOT NULL  DEFAULT True,
    "core_table_id" UUID NOT NULL REFERENCES "machinetable" ("id") ON DELETE CASCADE,
    "core_table_average_id" UUID NOT NULL REFERENCES "machinetableaverage" ("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "aerich" (
    "id" SERIAL NOT NULL PRIMARY KEY,
    "version" VARCHAR(255) NOT NULL,
    "app" VARCHAR(100) NOT NULL,
    "content" JSONB NOT NULL
);"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        """
