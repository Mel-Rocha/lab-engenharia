from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        ALTER TABLE "machinetable" ADD "gear" VARCHAR(50);
        ALTER TABLE "machinetable" ADD "fuel" VARCHAR(50);
        ALTER TABLE "machinetable" ADD "bodywork" VARCHAR(50);
        ALTER TABLE "machinetable" ADD "city" VARCHAR(50);
        ALTER TABLE "machinetable" ADD "state" VARCHAR(6);"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        ALTER TABLE "machinetable" DROP COLUMN "gear";
        ALTER TABLE "machinetable" DROP COLUMN "fuel";
        ALTER TABLE "machinetable" DROP COLUMN "bodywork";
        ALTER TABLE "machinetable" DROP COLUMN "city";
        ALTER TABLE "machinetable" DROP COLUMN "state";"""
